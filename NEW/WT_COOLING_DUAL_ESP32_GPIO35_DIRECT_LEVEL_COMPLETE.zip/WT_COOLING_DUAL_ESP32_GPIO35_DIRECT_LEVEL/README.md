# Water Tank Cooling System — Direct GPIO35 water level

Updated from the last simple-level project. The **only firmware behavior change** is the GPIO35-to-logical-water-level polarity inside `inputs()`:

```cpp
void inputs() {
  // Direct GPIO35 reading: 0 = LOW tank, 1 = FULL tank.
  const int8_t previousLevel = waterlevel;
  waterlevel = digitalRead(WATER_LEVEL_PIN);
  waterlevelsp = waterlevel;

  // Redraw existing tank/pump indicators on changes; no sensor filtering.
  if (uiBuilt && waterlevel != previousLevel) {
    refreshTemperaturePage();
    refreshPumpPage();
  }
}
```

| GPIO35 digital signal | `waterlevel` | Dashboard/PUMP pages | Pump (AUTO, system ON) | MQTT `waterlevel` |
|---|---|---|---|---|
| LOW / 0 | 0 | LOW | ON (fill) | `"0"` |
| HIGH / 1 | 1 | FULL | OFF (stop filling) | `"1"` |

This contains no water-level `.h` module, debounce, software inversion, filtering, state confirmation, restart delay, or qualification logic. The existing 50ms GPIO polling and redraw-on-change logic remain in the main source. Do not confuse this with an analog/percentage sensor: it is a 2-state indication.

## Hardware: GPIO35

GPIO35 is **input-only and has no internal pull-up or pull-down**. A powered sensor should provide safe, definite 0V or 3.3V signals. Never apply 5V to GPIO35. If using an unpowered dry-contact float which must read 1 when FULL, connect a switch that **closes to 3.3V when FULL**, with a 10kΩ external pull-down from GPIO35 to GND:

```
3.3V --- [float switch closes at FULL] ---+--- GPIO35
                                          |
                                         10kΩ
                                          |
                                         GND
```

If the installed float switch closes to GND rather than 3.3V, this direct software mapping will NOT yield HIGH=FULL without changing the wiring/contact orientation or adding proper signal conditioning. Remove any previously fitted pull-up if rewiring for this pull-down topology; otherwise the input could remain HIGH while the switch is open. Test the raw GPIO level with the pump disconnected before enabling AUTO. Always provide independent overflow protection.

## Display ESP32 pinout

| Signal | GPIO |
|---|---|
| FAN relay (active HIGH) | 22 |
| PUMP relay (active HIGH) | 21 |
| Water level raw digital input | 35 |
| DS18B20 1-Wire | 4 |
| UART RX2 (from Ethernet board GPIO17 TX2) | 16 |
| UART TX2 (to Ethernet board GPIO16 RX2) | 17 |

## Ethernet ESP32 / W5500

Second ESP32 unchanged: W5500 SCK=18, MISO=19, MOSI=23, CS=5. The cross-connected UART and common GND remain the same. The Ethernet firmware is included unchanged only for convenience.

## Build and upload (PlatformIO)

Open `01_DISPLAY_CONTROLLER` in VS Code/PlatformIO (it contains `platformio.ini`). Run:

```
pio run -e jc2432w328
pio run -e jc2432w328 -t upload
```

Only the **display** ESP32 needs flashing. After uploading, verify on hardware with the pump disconnected: 0V/LOW at GPIO35 shows LOW and sends `"0"`; 3.3V/HIGH shows FULL and sends `"1"`. Then test pump AUTO separately.

## Verification scope

The source code and UART host protocol tests were checked in this environment; they do **not** constitute successful ESP32 cross-compilation or an actual electrical/functional bench test. Full PlatformIO build and real-hardware validation must be performed on the user's setup.
