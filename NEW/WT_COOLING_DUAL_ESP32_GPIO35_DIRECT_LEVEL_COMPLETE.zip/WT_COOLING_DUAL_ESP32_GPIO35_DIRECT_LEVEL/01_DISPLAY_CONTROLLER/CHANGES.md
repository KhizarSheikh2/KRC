# Direct water-level GPIO reading

- Only water-level firmware behavior changed: `waterlevel = digitalRead(WATER_LEVEL_PIN)`; `waterlevelsp = waterlevel`.
- LOW/0 = tank LOW; HIGH/1 = tank FULL. No inversion, debounce, timers, extra water-level `.h` files.
- LVGL dashboard and pump page refresh only when level changes; they do not filter the input.
- Pump AUTO logic remains: 0 starts fill, 1 stops fill.
- Pin assignments, Wi-Fi/Ethernet MQTT and W5500 companion firmware unchanged.
