# 2026-10-14 — Display PlatformIO build fix

**Build error fixed**: `publishJson()` in `include/wifithread.h` used
`ethernetLink` and `nextTelemetrySeq` before they were declared.
`#include "wifithread.h"` now follows the UART bridge global definitions in
`src/main.cpp`. This is a declaration-order fix only; UART protocol,
telemetry, UI, relay logic, Wi-Fi handling, and pin mapping are unchanged.

**Compiler warning fixed**: `switch(is_wifi_connected)` acted on a boolean
in the Wi-Fi provisioning response; the code now assigns 0 or 1 directly.

**Informational TFT_eSPI warning**: `TOUCH_CS pin not defined` is expected
because the display uses an external I2C capacitive touch chip, not the
SPI resistive touch driver inside TFT_eSPI. Do not define a fake TOUCH_CS
just to hide the warning.

Verify locally:

```bash
pio run -e jc2432w328
pio run -e jc2432w328 -t upload
```

The code has been subjected to static inspection and the host UART codec
tests, not a complete PlatformIO compilation in this environment.
