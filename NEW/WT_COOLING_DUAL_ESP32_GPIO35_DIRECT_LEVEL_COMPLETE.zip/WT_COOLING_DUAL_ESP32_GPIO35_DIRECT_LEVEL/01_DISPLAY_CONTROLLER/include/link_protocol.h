#pragma once
#include <Arduino.h>

// Shared binary UART protocol, version 1. NOT a network service.
// 0xA5 0x5A | version | type | seq LE16 | len LE16 | data | CRC16 CCITT LE16
// CRC is calculated over version through data (initial 0xFFFF, poly 0x1021).
namespace WTCLink {
static constexpr uint8_t VERSION = 1;
static constexpr uint8_t STATUS = 1;    // bridge -> main: JSON link/mqtt status + epoch
static constexpr uint8_t TELEMETRY = 2; // main -> bridge: unchanged MQTT publish JSON
static constexpr uint8_t COMMAND = 3;   // bridge -> main: unchanged subscribed JSON
static constexpr uint8_t ACK = 4;       // main -> bridge: command sequence accepted
static constexpr uint8_t TIME_HINT = 5; // main -> bridge: UTC from WiFi if wired NTP blocked
static constexpr uint16_t MAX_DATA = 1536;
static constexpr uint32_t BAUD = 460800;

inline uint16_t crcStep(uint16_t crc, uint8_t b) {
  crc ^= static_cast<uint16_t>(b) << 8;
  for (uint8_t i = 0; i < 8; ++i)
    crc = (crc & 0x8000) ? static_cast<uint16_t>((crc << 1) ^ 0x1021) : static_cast<uint16_t>(crc << 1);
  return crc;
}

class Codec {
public:
  explicit Codec(HardwareSerial& serial) : port_(serial) {}

  bool send(uint8_t type, uint16_t seq, const char* payload, uint16_t len) {
    if (len > MAX_DATA || (len && !payload)) return false;
    uint8_t header[] = {VERSION, type, static_cast<uint8_t>(seq), static_cast<uint8_t>(seq >> 8),
                        static_cast<uint8_t>(len), static_cast<uint8_t>(len >> 8)};
    uint16_t crc = 0xFFFF;
    for (uint8_t b : header) crc = crcStep(crc, b);
    for (uint16_t i = 0; i < len; ++i) crc = crcStep(crc, static_cast<uint8_t>(payload[i]));
    const uint8_t preamble[] = {0xA5, 0x5A};
    port_.write(preamble, sizeof(preamble));
    port_.write(header, sizeof(header));
    if (len) port_.write(reinterpret_cast<const uint8_t*>(payload), len);
    const uint8_t checksum[] = {static_cast<uint8_t>(crc), static_cast<uint8_t>(crc >> 8)};
    port_.write(checksum, sizeof(checksum));
    return true;
  }

  // Poll often; one complete verified frame max per invocation, further bytes
  // remain buffered until next poll. No dynamic memory allocation in parser.
  bool poll(uint8_t& type, uint16_t& seq, const char*& payload, uint16_t& len) {
    if (state_ && millis() - lastByte_ > 250) reset();
    while (port_.available()) {
      uint8_t b = static_cast<uint8_t>(port_.read());
      lastByte_ = millis();
      switch (state_) {
        case 0: state_ = (b == 0xA5) ? 1 : 0; break;
        case 1: state_ = (b == 0x5A) ? 2 : (b == 0xA5 ? 1 : 0); index_ = 0; crc_ = 0xFFFF; break;
        case 2:
          hdr_[index_++] = b;
          crc_ = crcStep(crc_, b);
          if (index_ == sizeof(hdr_)) {
            expected_ = static_cast<uint16_t>(hdr_[4]) | (static_cast<uint16_t>(hdr_[5]) << 8);
            if (hdr_[0] != VERSION || expected_ > MAX_DATA) { reset(); break; }
            index_ = 0;
            state_ = expected_ ? 3 : 4;
          }
          break;
        case 3:
          data_[index_++] = static_cast<char>(b);
          crc_ = crcStep(crc_, b);
          if (index_ == expected_) { index_ = 0; state_ = 4; }
          break;
        case 4: lowCrc_ = b; state_ = 5; break;
        case 5: {
          const uint16_t received = static_cast<uint16_t>(lowCrc_) | (static_cast<uint16_t>(b) << 8);
          if (received == crc_) {
            type = hdr_[1];
            seq = static_cast<uint16_t>(hdr_[2]) | (static_cast<uint16_t>(hdr_[3]) << 8);
            len = expected_;
            data_[len] = '\0';
            payload = data_;
            reset();
            return true;
          }
          reset();
          break;
        }
      }
    }
    return false;
  }

private:
  void reset() { state_ = 0; index_ = 0; expected_ = 0; }
  HardwareSerial& port_;
  uint8_t state_ = 0, hdr_[6] = {}, lowCrc_ = 0;
  uint16_t index_ = 0, expected_ = 0, crc_ = 0xFFFF;
  uint32_t lastByte_ = 0;
  char data_[MAX_DATA + 1] = {};
};
} // namespace WTCLink
