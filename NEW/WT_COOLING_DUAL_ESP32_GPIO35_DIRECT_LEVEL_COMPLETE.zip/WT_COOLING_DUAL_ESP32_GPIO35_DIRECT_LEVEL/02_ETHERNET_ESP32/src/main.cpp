/* Water Tank Cooling / dedicated wired AWS IoT coprocessor.
 * Controller ESP32 owns ALL safety I/O, scheduler, UI, app credentials.
 * This board owns W5500, Ethernet DHCP, NTP, AWS IoT mTLS/MQTT and UART2.
 * The primary stays operational over WiFi if this board loses link or power.
 */
#include <Arduino.h>
#include <SPI.h>
#include <Ethernet.h>
#include <EthernetUdp.h>
#include <Dns.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <time.h>
#include <esp_system.h>
#include <sys/time.h>

#define SSL_CLIENT_BUFFER_SIZE 2048
#include <SSLClient.h>
#include "certificates.h"
#include "link_protocol.h"

static constexpr int W5500_SCK = 18;
static constexpr int W5500_MISO = 19;
static constexpr int W5500_MOSI = 23;
static constexpr int W5500_CS = 5;
static constexpr int W5500_RESET = 27; // Optional W5500 RESET wire; set -1 if tied high.
static constexpr int ENTROPY_PIN = 34;  // Unconnected analog input for SSLClient.
static constexpr int UART_RX = 16;      // bridge RX2 <- display TX GPIO17
static constexpr int UART_TX = 17;      // bridge TX2 -> display RX GPIO16

static constexpr char DEVICE_NAME[] = "WTC-AAA001";
static constexpr char MQTT_HOST[] = "a31qubhv0f0qec-ats.iot.eu-north-1.amazonaws.com";
static constexpr uint16_t MQTT_PORT = 8883;
static constexpr char PUBLISH_TOPIC[] = "/KRC/WTC-AAA001";
static constexpr char SUBSCRIBE_TOPIC[] = "/test/WTC-AAA001/1";

// User's previous static fallback, only used when DHCP is unreachable.
// Change these for the installation's actual LAN or set ALLOW_STATIC_FALLBACK false.
static constexpr bool ALLOW_STATIC_FALLBACK = true;
static const IPAddress STATIC_IP(192,168,0,117);
static const IPAddress STATIC_DNS(8,8,8,8);
static const IPAddress STATIC_GW(192,168,0,1);
static const IPAddress STATIC_MASK(255,255,255,0);

HardwareSerial uart(2);
WTCLink::Codec bridge(uart);
EthernetClient ethernetClient;
SSLClient secureEthernet(ethernetClient, TAs, (size_t)TAs_NUM, ENTROPY_PIN);
PubSubClient mqtt(secureEthernet);
EthernetUDP udp;

static uint8_t ethernetMac[6];
static bool hardwarePresent = false;
static bool ipConfigured = false;
static bool dhcpEnabled = false;
static bool lastCableUp = false;
static uint32_t lastIpAttempt = 0;
static uint32_t lastMqttAttempt = 0;
static uint32_t lastNtpAttempt = 0;
static uint32_t lastStatus = 0;
static uint32_t lastDhcpMaintenance = 0;
static uint32_t lastControllerTelemetry = 0;
static uint16_t nextCommandSeq = 0;
static uint32_t thisBootId = 0;
static bool mqttSubscribed = false;

struct PendingCommand {
  uint16_t sequence = 0;
  uint16_t length = 0;
  char payload[WTCLink::MAX_DATA + 1] = {};
  uint32_t lastSentAt = 0;
  uint8_t transmissions = 0;
};
static PendingCommand pending[8];
static uint8_t queued = 0;

static bool cableUp() {
  return hardwarePresent && Ethernet.linkStatus() == LinkON;
}

static bool clockValid() { return time(nullptr) > 1700000000; }

static void generateMac() {
  const uint64_t chip = ESP.getEfuseMac();
  // Locally administered UNICAST address. Original 0x11 was multicast.
  ethernetMac[0] = 0x02;
  for (int i = 1; i < 6; ++i) ethernetMac[i] = (chip >> ((i-1)*8)) & 0xFF;
  Serial.printf("[ETH] MAC %02X:%02X:%02X:%02X:%02X:%02X\n",
    ethernetMac[0], ethernetMac[1], ethernetMac[2], ethernetMac[3], ethernetMac[4], ethernetMac[5]);
}

static void resetW5500() {
  if (W5500_RESET < 0) return;
  pinMode(W5500_RESET, OUTPUT);
  digitalWrite(W5500_RESET, LOW);
  delay(30);
  digitalWrite(W5500_RESET, HIGH);
  delay(180);
}

static bool acquireAddress() {
  if (!cableUp()) return false;
  lastIpAttempt = millis();
  Serial.println("[ETH] DHCP requested");
  int success = Ethernet.begin(ethernetMac, 5000UL, 1500UL);
  if (success == 1 && Ethernet.localIP() != IPAddress(0,0,0,0) && cableUp()) {
    dhcpEnabled = true;
    ipConfigured = true;
    Serial.print("[ETH] DHCP address: "); Serial.println(Ethernet.localIP());
    return true;
  }
  dhcpEnabled = false;
  if (ALLOW_STATIC_FALLBACK) {
    Ethernet.begin(ethernetMac, STATIC_IP, STATIC_DNS, STATIC_GW, STATIC_MASK);
    ipConfigured = cableUp();
    if (ipConfigured) {
      Serial.print("[ETH] Static fallback (NOT an internet test): ");
      Serial.println(Ethernet.localIP());
    }
  } else {
    ipConfigured = false;
    Serial.println("[ETH] No DHCP, no static fallback");
  }
  return ipConfigured;
}

static bool syncNtp() {
  if (!ipConfigured || !cableUp()) return false;
  lastNtpAttempt = millis();
  IPAddress ntpIP;
  // DNS first, then a static well-known service (only as a fallback).
  DNSClient dns;
  dns.begin(Ethernet.dnsServerIP());
  if (dns.getHostByName("time.google.com", ntpIP) != 1)
    ntpIP = IPAddress(129,6,15,28);
  uint8_t packet[48] = {};
  packet[0] = 0x1B; // NTP client, mode 3
  if (!udp.begin(2390)) return false;
  if (!udp.beginPacket(ntpIP, 123)) { udp.stop(); return false; }
  udp.write(packet, sizeof(packet));
  udp.endPacket();
  uint32_t beginAt = millis();
  while (millis() - beginAt < 2500) {
    int count = udp.parsePacket();
    if (count >= 48) {
      udp.read(packet, sizeof(packet));
      // Check mode (server mode 4), sane stratum and unix timestamp.
      const uint8_t mode = packet[0] & 7;
      const uint32_t ntpSeconds = (uint32_t(packet[40])<<24) | (uint32_t(packet[41])<<16) |
                                  (uint32_t(packet[42])<<8) | uint32_t(packet[43]);
      if (mode == 4 && packet[1] >= 1 && packet[1] <= 15 && ntpSeconds > 3908988800UL) {
        const uint32_t epoch = ntpSeconds - 2208988800UL;
        if (epoch > 1700000000UL) {
          timeval now = {};
          now.tv_sec = epoch;
          settimeofday(&now, nullptr);
          Serial.printf("[TIME] Ethernet NTP UTC %lu\n", (unsigned long)epoch);
          udp.stop();
          return true;
        }
      }
    }
    delay(5);
  }
  udp.stop();
  Serial.println("[TIME] Ethernet NTP timed out, retry later");
  return false;
}

static void onMqttMessage(char* topic, byte* payload, unsigned int length) {
  if (strcmp(topic, SUBSCRIBE_TOPIC) != 0 || length == 0 || length > WTCLink::MAX_DATA) return;
  if (queued >= sizeof(pending) / sizeof(pending[0])) {
    Serial.println("[UART] command queue full - can't deliver this MQTT QoS0 command");
    return;
  }
  PendingCommand& slot = pending[queued++];
  slot.sequence = ++nextCommandSeq;
  slot.length = static_cast<uint16_t>(length);
  memcpy(slot.payload, payload, length);
  slot.payload[length] = '\0';
  slot.lastSentAt = 0;
  slot.transmissions = 0;
}

static void dropAcknowledged(uint16_t seq) {
  for (uint8_t i = 0; i < queued; ++i) {
    if (pending[i].sequence != seq) continue;
    // Copy a small bounded array (no dynamic allocations).
    for (uint8_t j = i + 1; j < queued; ++j) pending[j-1] = pending[j];
    --queued;
    return;
  }
}

static void pollController() {
  uint8_t type;
  uint16_t seq, len;
  const char* data;
  uint8_t count = 0;
  while (count++ < 4 && bridge.poll(type, seq, data, len)) {
    if (type == WTCLink::ACK && len == 0) {
      dropAcknowledged(seq);
    } else if (type == WTCLink::TIME_HINT && len >= 10 && len <= 12) {
      const uint32_t epoch = strtoul(data, nullptr, 10);
      if (epoch > 1700000000UL && !clockValid()) {
        timeval now = {};
        now.tv_sec = epoch;
        settimeofday(&now, nullptr);
        Serial.println("[TIME] received trusted UART WiFi-time hint");
      }
    } else if (type == WTCLink::TELEMETRY && len > 0) {
      lastControllerTelemetry = millis();
      // The primary already creates the *original* app JSON; never rewrite it.
      // Discard when broker offline; primary publishes over WiFi instead.
      if (ipConfigured && cableUp() && mqtt.connected()) {
        bool ok = mqtt.publish(PUBLISH_TOPIC, reinterpret_cast<const uint8_t*>(data), len, true);
        if (!ok) Serial.println("[MQTT] failed to publish Ethernet telemetry");
      }
    }
  }
}

static void serviceCommandQueue() {
  if (queued == 0) return;
  PendingCommand& cmd = pending[0];
  if (cmd.transmissions && millis() - cmd.lastSentAt < 750UL) return;
  // Link retries are bounded; a lost controller must never freeze this ESP32.
  if (cmd.transmissions >= 12) {
    Serial.println("[UART] no ACK for command after retries, dropping");
    dropAcknowledged(cmd.sequence);
    return;
  }
  bridge.send(WTCLink::COMMAND, cmd.sequence, cmd.payload, cmd.length);
  cmd.transmissions++;
  cmd.lastSentAt = millis();
}

static void sendStatus() {
  StaticJsonDocument<256> status;
  status["link"] = cableUp();
  status["mqtt"] = cableUp() && ipConfigured && mqtt.connected() && mqttSubscribed;
  status["boot"] = thisBootId;
  status["ip"] = ipConfigured && cableUp() ? Ethernet.localIP().toString() : "";
  status["epoch"] = clockValid() ? static_cast<uint32_t>(time(nullptr)) : 0;
  char data[256];
  size_t len = serializeJson(status, data);
  bridge.send(WTCLink::STATUS, 0, data, static_cast<uint16_t>(len));
}

static void connectMqtt() {
  if (!ipConfigured || !cableUp() || !clockValid() || mqtt.connected()) return;
  if (millis() - lastMqttAttempt < 12000UL) return;
  lastMqttAttempt = millis();
  Serial.println("[MQTT] Connecting AWS IoT by Ethernet mTLS");
  if (mqtt.connect("WTC-AAA001-eth")) {
    bool sub = mqtt.subscribe(SUBSCRIBE_TOPIC);
    mqttSubscribed = sub;
    Serial.printf("[MQTT] Ethernet connected, subscribed=%d\n", sub ? 1 : 0);
    if (!sub) {
      mqtt.disconnect();
      Serial.println("[MQTT] subscription failed, keeping WiFi as primary");
    }
    // Main ESP32's next 3-second sample gets immediately delivered here.
  } else {
    Serial.printf("[MQTT] connect error %d; WiFi should remain active on main\n", mqtt.state());
  }
}

void setup() {
  Serial.begin(115200);
  uart.setRxBufferSize(4096);
  uart.begin(WTCLink::BAUD, SERIAL_8N1, UART_RX, UART_TX);
  Serial.println("[BOOT] WTC Ethernet ESP32 - W5500 coprocessor");
  generateMac();
  thisBootId = esp_random();
  resetW5500();
  SPI.begin(W5500_SCK, W5500_MISO, W5500_MOSI, W5500_CS);
  Ethernet.init(W5500_CS);
  // A static begin initializes W5500 registers so hardware/link status can
  // be read even if it booted WITHOUT a network cable.
  Ethernet.begin(ethernetMac, STATIC_IP, STATIC_DNS, STATIC_GW, STATIC_MASK);
  hardwarePresent = Ethernet.hardwareStatus() == EthernetW5500;
  Serial.printf("[ETH] W5500 hardware=%s\n", hardwarePresent ? "FOUND" : "MISSING");
  ipConfigured = false; // register initialization != network configuration
  lastCableUp = cableUp();
  if (lastCableUp) acquireAddress();

  pinMode(ENTROPY_PIN, INPUT);
  secureEthernet.setMutualAuthParams(mTLS);
  secureEthernet.setTimeout(10000);
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(onMqttMessage);
  mqtt.setBufferSize(2048);
  mqtt.setKeepAlive(15); // detect silent WAN outages faster than original 60s
  mqtt.setSocketTimeout(5);
  if (ipConfigured) syncNtp();
  lastMqttAttempt = millis() - 12000UL;
  sendStatus();
}

void loop() {
  // UART is polled on EVERY iteration (no LVGL/rendering on this MCU).
  pollController();
  serviceCommandQueue();

  static uint32_t lastLinkScan = 0;
  if (millis() - lastLinkScan >= 1000UL) {
    lastLinkScan = millis();
    if (!mqtt.connected()) mqttSubscribed = false;
    bool present = cableUp();
    if (present != lastCableUp) {
      lastCableUp = present;
      if (!present) {
        Serial.println("[ETH] unplugged - dropping authenticated MQTT path");
        if (mqtt.connected()) mqtt.disconnect();
        mqttSubscribed = false;
        ethernetClient.stop();
        ipConfigured = false;
        dhcpEnabled = false;
      } else {
        Serial.println("[ETH] cable plugged in - requesting address");
        acquireAddress();
      }
    }
    if (present && !ipConfigured && millis() - lastIpAttempt > 15000UL)
      acquireAddress();
  }

  if (ipConfigured && cableUp()) {
    if (dhcpEnabled && millis() - lastDhcpMaintenance > 30000UL) {
      lastDhcpMaintenance = millis();
      int result = Ethernet.maintain();
      if (result == 1 || result == 3) {
        // DHCP renewal/rebind failed: invalidate IP and retry.
        if (mqtt.connected()) mqtt.disconnect();
        mqttSubscribed = false;
        ethernetClient.stop();
        ipConfigured = false;
        Serial.println("[ETH] DHCP lease failed; renewing configuration");
      }
    }
    if (ipConfigured && (( !clockValid() && millis() - lastNtpAttempt > 30000UL) ||
                         (clockValid() && millis() - lastNtpAttempt > 3600000UL))) syncNtp();
    connectMqtt();
    if (mqtt.connected()) mqtt.loop();
  }

  if (millis() - lastStatus >= 1000UL) {
    lastStatus = millis();
    sendStatus();
  }
  delay(2);
}
