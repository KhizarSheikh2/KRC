# Ethernet ESP32 companion firmware

Flash onto a distinct classic ESP32-WROOM DevKit (GPIO16/17 must be available).
W5500: SCK18 MISO19 MOSI23 CS5; optional RESET27.
UART2: RX16 <- main TX17, TX17 -> main RX16, GND common.
Baud: 460800, 8N1.

Handles Ethernet DHCP and fallback IPv4, NTP, TLS client certificate auth,
AWS IoT MQTT, command delivery and telemetry publishing. It does NOT operate
any relays or sensors. The display/main ESP32 remains the only controller.

Build: `pio run -e ethernet_esp32`
Full wiring, security and verification limitations: ../README.md
