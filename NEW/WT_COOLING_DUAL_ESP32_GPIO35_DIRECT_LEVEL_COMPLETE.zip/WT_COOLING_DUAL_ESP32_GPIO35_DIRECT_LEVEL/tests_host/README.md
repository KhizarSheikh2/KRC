# Host-only UART protocol test

Run from this directory:

```
g++ -std=c++17 -Wall -Wextra -Werror -I . -I ../01_DISPLAY_CONTROLLER/include test.cpp -o test_codec && ./test_codec
```

The original water-level mapping is coded directly in `01_DISPLAY_CONTROLLER/src/main.cpp::inputs()` with no extra test-only water-level logic file. Host tests are not a substitute for full PlatformIO compilation and on-board testing.
