#pragma once
#include <cstdint>
#include <cstddef>
#include <deque>
#include <cstring>
extern uint32_t fake_time;
inline uint32_t millis() { return fake_time; }
class HardwareSerial {
public:
 std::deque<uint8_t> queue;
 size_t write(const uint8_t* b, size_t n) { for(size_t i=0;i<n;i++)queue.push_back(b[i]);return n;}
 size_t write(uint8_t v) { queue.push_back(v);return 1; }
 int available() {return int(queue.size());}
 int read() {if(queue.empty())return -1; int x=queue.front();queue.pop_front();return x;}
};
