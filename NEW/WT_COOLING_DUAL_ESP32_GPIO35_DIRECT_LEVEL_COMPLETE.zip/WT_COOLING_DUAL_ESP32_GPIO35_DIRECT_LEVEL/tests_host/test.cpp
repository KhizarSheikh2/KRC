#include <cassert>
#include <string>
#include <iostream>
#include "link_protocol.h"
uint32_t fake_time = 0;
int main(){
 HardwareSerial port;
 WTCLink::Codec tx(port), rx(port);
 uint8_t type=0; uint16_t seq=0,len=0; const char*payload=nullptr;
 assert(tx.send(WTCLink::STATUS,0,"hello",5));
 assert(rx.poll(type,seq,payload,len));
 assert(type==WTCLink::STATUS && seq==0 && len==5 && std::string(payload,len)=="hello");
 std::string text(1100,'A'); text[400]='\0';
 assert(tx.send(WTCLink::COMMAND,500,(const char*)text.data(),(uint16_t)text.size()));
 assert(rx.poll(type,seq,payload,len));
 assert(seq==500 && len==1100 && memcmp(payload,text.data(),1100)==0);
 assert(!tx.send(WTCLink::TELEMETRY,55,text.data(),1537));
 assert(tx.send(WTCLink::TELEMETRY,42,"CHECK",5));
 port.queue[11] ^= 0x01; // deliberately corrupt payload
 assert(!rx.poll(type,seq,payload,len));
 assert(tx.send(WTCLink::STATUS,7,"recovered",9));
 assert(rx.poll(type,seq,payload,len));
 assert(seq==7 && std::string(payload,len)=="recovered");
 assert(tx.send(WTCLink::ACK,65535,nullptr,0));
 assert(rx.poll(type,seq,payload,len));
 assert(seq==65535 && len==0);
 // Test half-frame timeout before fresh preamble.
 assert(tx.send(WTCLink::COMMAND,17,"abc",3));
 for(int i=0;i<7;i++)port.queue.pop_back();
 assert(!rx.poll(type,seq,payload,len));
 fake_time += 400;
 port.queue.clear();
 assert(tx.send(WTCLink::STATUS,1,"OK",2));
 assert(rx.poll(type,seq,payload,len));
 std::cout<<"PASS CRC16, framing, max-length, null-byte, resynchronization, timeouts and sequence\n";
}
