# AM3 JC2432W328 Display - Enhanced UI V4

Complete **display-side only** PlatformIO firmware for the JC2432W328 2.8-inch HMI.
The AM3 hardware/control firmware is not included and is not modified.

## Stack

- ESP32 / Arduino framework via PlatformIO
- TFT_eSPI 2.5.43 (ST7789 transport)
- LVGL 8.3.11 (UI)
- ArduinoJson 6.21.5
- CST820 capacitive touch over I2C

## Display / touch mapping

| Function | GPIO |
|---|---:|
| TFT MISO | 12 |
| TFT MOSI | 13 |
| TFT SCLK | 14 |
| TFT CS | 15 |
| TFT DC | 2 |
| TFT RESET | -1 |
| Backlight | 27, active HIGH |
| CST820 SDA | 33 |
| CST820 SCL | 32 |
| CST820 RESET | 25 |

Native panel: 240 x 320. Logical LVGL UI: **320 x 240 landscape** with rotation 1.

## AM3 display link - unchanged

- SSID: `AM3-AAA001`
- Password: `bitahomes`
- Host: `192.168.4.1`
- Display IP: `192.168.4.50`
- TCP port: `5050`

Existing hardware JSON fields and `start`, `stop`, `reset` commands remain unchanged.

## Enhanced V4 UI

### Overview
Industrial machine-state hero, suction/discharge pressure cards, enlarged START/STOP
controls, and a dedicated command acknowledgement card.

### Temperatures
Five temperature tiles (Return, Suction, Discharge, Supply, Oil) plus an automatic
Sensor Health tile showing live/not-set/fault channel status.

### Status / Safeties
HPS/LPS/OPS, RUN, ALARM, SHUTDOWN, MQTT, INTERNET and RESET. Abnormal conditions
receive stronger state-aware red highlighting while normal states remain restrained.

## Responsiveness / memory safeguards

- LVGL fixed heap remains 48 KiB.
- TFT draw buffer remains 12 scanlines (7680 bytes).
- No image/canvas/chart/meter widgets are used.
- Theme grow/transition animations are disabled.
- Values update in-place; screens are not continuously rebuilt.
- Dynamic text is clipped to fixed regions to prevent overlap.

## Clean build / upload

Use a clean build after replacing an older revision:

```text
C:\Users\as\.platformio\penv\Scripts\platformio.exe run --target clean
C:\Users\as\.platformio\penv\Scripts\platformio.exe run --target upload
```

Serial monitor: 115200 baud.

## Included verification material

- `UI_ENHANCEMENT_V4.txt`
- `UI_LAYOUT_AUDIT.txt`
- `VALIDATION_REPORT.txt`
- `ui_preview/overview.png`
- `ui_preview/temperatures.png`
- `ui_preview/status.png`
- `ui_preview/combined.png`
