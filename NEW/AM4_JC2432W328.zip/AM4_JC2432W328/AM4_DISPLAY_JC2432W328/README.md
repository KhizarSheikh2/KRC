# AM4 Display - JC2432W328 2.8 inch - AM3 V4 Style Enhanced UI

This PlatformIO project replaces **only the AM4 display firmware**. The AM4 hardware-host firmware is not modified.

## Target

- Board: JC2432W328 2.8 inch
- MCU: ESP32
- Display controller: ST7789
- Native panel: 240 x 320
- UI orientation: 320 x 240 landscape
- Graphics transport: TFT_eSPI 2.5.43
- UI framework: LVGL 8.3.11
- Touch: CST820/CST816-compatible capacitive controller over I2C
- PlatformIO: espressif32 6.9.0 / Arduino

## UI design

The interface now follows the same visual system as the approved **AM3 Enhanced UI V4**:

- graphite/near-black background
- compact 32 px industrial header
- cyan system accent with green/amber/red safety states
- strong bordered cards without gradients or expensive shadows
- large pressure readouts
- three dedicated pages instead of hiding/showing many containers on one screen
- fixed 29 px bottom navigation: **OVERVIEW / TEMPS / STATUS**
- 900 ms splash screen before the main HMI appears
- in-place state refresh at 250 ms; LVGL touch service continues every loop

### AM4 pages

1. **Overview** - compressor state, suction/discharge pressure, START/STOP and command feedback.
2. **Temperatures** - six AM4 temperature channels in a balanced 2 x 3 card grid: Return, Suction, Discharge, Supply, Oil and Other Sensor.
3. **Status / Safeties** - HPS, LPS, OPS, run output, alarm, shutdown, MQTT, internet and RESET.

The dynamic borders and colors show LIVE / NOT SET / FAULT states without redrawing the complete screen.

## Integrated display pins

- TFT MISO: GPIO12
- TFT MOSI: GPIO13
- TFT SCLK: GPIO14
- TFT CS: GPIO15
- TFT DC: GPIO2
- TFT RST: -1
- Backlight: GPIO27
- Touch SDA: GPIO33
- Touch SCL: GPIO32
- Touch RST: GPIO25

## Display-to-hardware link

The original AM4 communication protocol remains intact:

- SSID: `AM4-AAA001`
- Password: `bitahomes`
- Hardware host: `192.168.4.1:5050`
- Display static IP: `192.168.4.50`
- Commands: `start`, `stop`, `reset`

## Build

Open this folder in VS Code + PlatformIO and build environment:

`am4_jc2432w328`

The `ui_preview` folder contains layout previews. Values in preview images are illustrative; runtime values come from the AM4 hardware host.
