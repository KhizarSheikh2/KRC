#!/usr/bin/env python3
"""Static geometry audit for AM4 AM3-style 320x240 LVGL UI."""
from dataclasses import dataclass

SCREEN_W, SCREEN_H = 320, 240

@dataclass(frozen=True)
class Rect:
    name: str
    x: int
    y: int
    w: int
    h: int
    @property
    def x2(self): return self.x + self.w
    @property
    def y2(self): return self.y + self.h
    def inside(self, p): return self.x >= p.x and self.y >= p.y and self.x2 <= p.x2 and self.y2 <= p.y2
    def overlaps(self, o): return not (self.x2 <= o.x or o.x2 <= self.x or self.y2 <= o.y or o.y2 <= self.y)

screen = Rect("screen", 0, 0, SCREEN_W, SCREEN_H)
header = Rect("header", 4, 4, 312, 32)
nav = Rect("bottom-nav", 4, 207, 312, 29)

screens = {
    "overview": [
        Rect("state",4,40,312,45),
        Rect("suction",4,90,153,63), Rect("discharge",163,90,153,63),
        Rect("start",4,158,98,43), Rect("stop",108,158,98,43), Rect("control",212,158,104,43),
    ],
    "temperatures": [
        Rect("return",4,40,153,48), Rect("suction",163,40,153,48),
        Rect("discharge",4,93,153,48), Rect("supply",163,93,153,48),
        Rect("oil",4,146,153,55), Rect("other",163,146,153,55),
    ],
    "status": [
        Rect("hps",4,40,100,47), Rect("lps",110,40,100,47), Rect("ops",216,40,100,47),
        Rect("run",4,92,100,47), Rect("alarm",110,92,100,47), Rect("shutdown",216,92,100,47),
        Rect("mqtt",4,144,100,47), Rect("internet",110,144,100,47), Rect("reset",216,144,100,47),
        Rect("message-band",4,192,312,15),
    ],
}

fail=[]
def need(ok,msg):
    if not ok: fail.append(msg)

need(header.inside(screen), "header outside screen")
need(nav.inside(screen), "nav outside screen")
need(not header.overlaps(nav), "header overlaps nav")

for page, rects in screens.items():
    for r in rects:
        need(r.inside(screen), f"{page}: {r.name} outside screen")
        need(not r.overlaps(header), f"{page}: {r.name} overlaps header")
        # message-band intentionally touches nav at y=207 but does not overlap.
        need(not r.overlaps(nav), f"{page}: {r.name} overlaps nav")
    for i,a in enumerate(rects):
        for b in rects[i+1:]:
            need(not a.overlaps(b), f"{page}: {a.name} overlaps {b.name}")

# Minimum touch target checks for actual buttons.
for name,w,h in [("start",98,43),("stop",98,43),("reset",100,47),("nav",100,25)]:
    need(w >= 44 and h >= 24, f"touch target too small: {name}")

if fail:
    print("LAYOUT VALIDATION: FAIL")
    for item in fail: print(" -", item)
    raise SystemExit(1)

print("LAYOUT VALIDATION: PASS")
print("320x240 landscape: header, all content cards, status message band and bottom nav fit without overlap.")
print("AM4 temperature screen contains six cards in a 2x3 grid; command/navigation touch targets meet the audit minimum.")
