AM4 JC2432W328 CONVERSION
========================

1. AM4_HARDWARE_HOST is copied unchanged from the uploaded working project.
2. Upload only AM4_DISPLAY_JC2432W328 to the JC2432W328 TFT board.
3. Open AM4_DISPLAY_JC2432W328 as the PlatformIO project folder.
4. Build environment: am4_jc2432w328
5. TFT_eSPI is used for display transport; LVGL is used for the complete UI.
6. The UI is 320x240 landscape and uses the board's integrated CST820 capacitive touch.
7. See VALIDATION_REPORT.txt for the completed integrity, syntax, protocol and layout checks.
