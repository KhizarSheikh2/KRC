# AM2 JC2432W328 — JSON Sync + Responsive UI Final

This project is based on the commissioned AM2 single-controller build and keeps the original AM2 control/safety behavior while fixing the display responsiveness problem seen during SAFE/CTRL/SET navigation.

## Important responsiveness changes

- Navigation uses touch-down (`LV_EVENT_PRESSED`) instead of waiting for touch release.
- CT/current Modbus polling is non-blocking; an absent CT module no longer occupies the main loop for ~1.3 s per pass.
- LVGL/CST820 service is bounded instead of being called at ~1 kHz during cooperative waits.
- Main, temperature-config and pressure-config MQTT publishes are staggered instead of sent as one TLS burst.
- Temperature-config JSON publishes cached sensor samples, so app and TFT use the same reading cycle.

## MQTT contract

Outgoing retained topics:

1. `/KRC/AM2-444051` — original 31-field main JSON
2. `/KRC/AM2-444051/temperature_config_AM2-444` — four DS18B20 configuration JSON
3. `/KRC/AM2-444051/pressure_config` — original 22-field pressure/system configuration JSON

Incoming topics remain `/test/AM2-444051/1`, `/2`, `/3`.

## Hardware mapping retained

- DS18B20 x4: GPIO4
- RS485 CT: RX16 / TX17, auto-direction
- External I2C: SDA21 / SCL22
- PCF8574: P0 START, P1 STOP, P2 RUN, P3 ALARM, P4 HPS, P5 LPS, P6 OPS, P7 COMP_FB
- `RELAY_ACTIVE_LOW=false` => HIGH=ON, LOW=OFF
- CST820 touch: SDA33 / SCL32 / RST25

See `docs/JSON_UI_STABILITY_AUDIT.md` for the JSON findings from the user's captured state.
