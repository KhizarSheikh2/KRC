#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <Preferences.h>
#include "esp_task_wdt.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include <cstring>
#include <cstdio>
#include <cmath>

#include "BoardConfig.h"
#include "AM2UiBridge.h"
#include "UI.h"

// External AM2 hardware uses I2C controller 1. Built-in touch uses Wire/I2C0.
TwoWire AM2Wire(1);

#include "Def.h"
#include "aws_cred.h"
#include "ads1115.h"
#include "ModbusRTU.h"
#include "temp.h"
#include "MQTT.h"
#include "WifiThread.h"   // copied unchanged from the original AM2 project
#include "IO.h"

static QueueHandle_t uiCommandQueue = nullptr;


// -----------------------------------------------------------------------------
// Non-blocking CT/Modbus reader
// -----------------------------------------------------------------------------
// The original firmware called a blocking FC03 transaction on every loop pass.
// With currentsw=1 and a missing/slow CT module that could consume ~1.3 seconds
// repeatedly. The AM2 control values and Modbus register contract are unchanged;
// only the transport is serviced as a state machine so TFT/touch never has to wait.
namespace {
constexpr uint32_t CT_POLL_INTERVAL_MS = 250;
constexpr uint32_t CT_RESPONSE_TIMEOUT_MS = 1000;
constexpr size_t CT_RESPONSE_LEN = 11; // addr + fn + bytecount + 6 data + CRC
bool ctAwaitingResponse = false;
uint32_t ctRequestStartedMs = 0;
uint32_t ctLastCompletedMs = 0;
uint8_t ctResponse[CT_RESPONSE_LEN] = {0};
size_t ctResponseIndex = 0;

void setCtInvalid() {
  AMP1 = 888;
  AMP2 = 888;
  AMP3 = 888;
}

void startCtRequest() {
  while (RS485Serial.available()) (void)RS485Serial.read();

  uint8_t request[8];
  request[0] = MODBUS_SLAVE_ID;
  request[1] = MODBUS_FUNCTION_READ_HOLDING_REGISTERS;
  request[2] = static_cast<uint8_t>(CT_REGISTER_ADDRESS >> 8);
  request[3] = static_cast<uint8_t>(CT_REGISTER_ADDRESS & 0xFF);
  request[4] = 0x00;
  request[5] = 0x03;
  const uint16_t crc = calculateCRC(request, 6);
  request[6] = static_cast<uint8_t>(crc & 0xFF);
  request[7] = static_cast<uint8_t>(crc >> 8);

  RS485Serial.write(request, sizeof(request));
  ctResponseIndex = 0;
  ctRequestStartedMs = millis();
  ctAwaitingResponse = true;
}

void serviceAmpReader() {
  if (CTmodulesw != 1) {
    ctAwaitingResponse = false;
    ctResponseIndex = 0;
    return;
  }

  const uint32_t now = millis();
  if (!ctAwaitingResponse) {
    if (ctLastCompletedMs == 0 || now - ctLastCompletedMs >= CT_POLL_INTERVAL_MS) {
      startCtRequest();
    }
    return;
  }

  while (RS485Serial.available() && ctResponseIndex < CT_RESPONSE_LEN) {
    ctResponse[ctResponseIndex++] = static_cast<uint8_t>(RS485Serial.read());
  }

  if (ctResponseIndex >= CT_RESPONSE_LEN) {
    const uint16_t rxCrc = static_cast<uint16_t>(ctResponse[CT_RESPONSE_LEN - 2]) |
                           (static_cast<uint16_t>(ctResponse[CT_RESPONSE_LEN - 1]) << 8);
    const bool headerOk = ctResponse[0] == MODBUS_SLAVE_ID &&
                          ctResponse[1] == MODBUS_FUNCTION_READ_HOLDING_REGISTERS &&
                          ctResponse[2] == 6;
    const bool crcOk = calculateCRC(ctResponse, CT_RESPONSE_LEN - 2) == rxCrc;

    if (headerOk && crcOk) {
      const uint16_t r1 = (static_cast<uint16_t>(ctResponse[3]) << 8) | ctResponse[4];
      const uint16_t r2 = (static_cast<uint16_t>(ctResponse[5]) << 8) | ctResponse[6];
      const uint16_t r3 = (static_cast<uint16_t>(ctResponse[7]) << 8) | ctResponse[8];
      AMP1 = static_cast<int>(r1 / 100U);
      AMP2 = static_cast<int>(r2 / 100U);
      AMP3 = static_cast<int>(r3 / 100U);
    } else {
      setCtInvalid();
      static uint32_t lastCtErrorPrint = 0;
      if (now - lastCtErrorPrint >= 2000UL) {
        Serial.printf("[CT] Invalid Modbus response (header=%s crc=%s)\n",
                      headerOk ? "OK" : "BAD", crcOk ? "OK" : "BAD");
        lastCtErrorPrint = now;
      }
    }

    ctAwaitingResponse = false;
    ctResponseIndex = 0;
    ctLastCompletedMs = now;
    return;
  }

  if (now - ctRequestStartedMs >= CT_RESPONSE_TIMEOUT_MS) {
    setCtInvalid();
    ctAwaitingResponse = false;
    ctResponseIndex = 0;
    ctLastCompletedMs = now;
    static uint32_t lastCtTimeoutPrint = 0;
    if (now - lastCtTimeoutPrint >= 2000UL) {
      Serial.println("[CT] Modbus timeout - current values set to 888");
      lastCtTimeoutPrint = now;
    }
  }
}

// Publish one MQTT topic at a time. Three back-to-back TLS writes caused short
// UI stalls every sync cycle on this single ESP32.
bool mqttPublishCycleActive = false;
uint8_t mqttPublishStage = 0;
uint32_t mqttPublishPartMs = 0;
constexpr uint32_t MQTT_PUBLISH_PART_GAP_MS = 8;

void startMqttPublishCycle() {
  mqttPublishCycleActive = true;
  mqttPublishStage = 0;
  mqttPublishPartMs = 0;
  // Clear only the request that started this cycle. A new app/TFT change that
  // occurs while publishing will set mqttStateDirty again and trigger another cycle.
  mqttStateDirty = false;
}

void serviceMqttPublishCycle() {
  if (!mqttPublishCycleActive || WiFi.status() != WL_CONNECTED || !client.connected()) return;
  const uint32_t now = millis();
  if (mqttPublishPartMs != 0 && now - mqttPublishPartMs < MQTT_PUBLISH_PART_GAP_MS) return;

  uiService();
  switch (mqttPublishStage) {
    case 0: publishJson(); break;
    case 1: temp_sensor_select_publish(); break;
    case 2: publish_pressure_selection(); break;
    default: break;
  }
  uiService();
  mqttPublishPartMs = millis();
  ++mqttPublishStage;

  if (mqttPublishStage >= 3) {
    mqttPublishCycleActive = false;
    mqttPublishStage = 0;
    wait_time = millis();
    message_received = false;
    message_received_config = false;
    message_received_pressure_config = false;
  }
}
} // namespace

int convertToFahrenheit(float temp) {
  return ((temp * 9) / 5) + 32;
}

void scanAlarms() {
  inputs = readInputs(AM2_PCF8574_ADDR);

  // Fail-safe: if the PCF8574 cannot be read, the controller cannot trust HPS/LPS/OPS/COMP_FB.
  // Trip/hold the machine rather than treating an I/O communication failure as healthy.
  if (pcfCommFault) {
    Machine_Shutdown = 1;
    Switches_alarm = 1;
    static unsigned long lastPcfFaultPrint = 0;
    if (millis() - lastPcfFaultPrint >= 2000UL) {
      Serial.printf("[SAFETY] PCF8574 communication fault - fail-safe trip (read errors=%lu, write errors=%lu)\n",
                    pcfReadErrorCount, pcfWriteErrorCount);
      lastPcfFaultPrint = millis();
    }
    return;
  }

  if (bitRead(inputs, HIGH_PRE) == 1 && HPS_SW == 1) {
    dis_alarm = true;
    HPS = "HIGH";
    if (startup_flag == 1 || modesw == 0) comp_Status = HPS_ALARM;
  } else {
    dis_alarm = false;
    HPS = "LOW";
  }

  if (bitRead(inputs, LOW_PRE) == 1 && LPS_SW == 1) {
    suction_alarm = true;
    LPS = "LOW";
    if (startup_flag == 1 || modesw == 0) comp_Status = LPS_ALARM;
  } else {
    suction_alarm = false;
    LPS = "HIGH";
  }

  if (bitRead(inputs, OIL_SW) == 1 && OPS_SW == 1) {
    OPS = "LOW";
    oil_alarm = true;
    if (startup_flag == 1 || modesw == 0) comp_Status = OPS_ALARM;
  } else {
    oil_alarm = false;
    OPS = "HIGH";
  }

  if (modesw == 1 && comp_Status == 1 && bitRead(inputs, COMP_PIN) == 1 && millis() - COMP_START_TIME > 2500) {
    comp_alarm = true;
    Serial.println("Compressor Feedback Error!");
    if (startup_flag == 1) comp_Status = COMP_FAIL_TO_RUN;
  }

  if (suction_alarm == 1 || dis_alarm == 1 || oil_alarm == 1 || comp_alarm == 1) {
    if (!Switches_alarm) {
      SWITCH_ALARM_HOLD_TIME = millis();
      Switches_alarm = 1;
    }
    return;
  } else {
    Switches_alarm = 0;
  }

  Machine_Shutdown = 0;

  if (CTmodulesw == 1) {
    if (AMP1 > amps_limit || AMP2 > amps_limit || AMP3 > amps_limit) {
      Machine_Shutdown = 1;
      if (startup_flag == 1 || modesw == 0) comp_Status = AMPS_HIGH;
      return;
    }
  }

  if ((ReturnTempC > ReturnAlertSp || ReturnTempC > 100.0) && ReturnTempC < 888) {
    Machine_Shutdown = 1;
    if (startup_flag == 1 || modesw == 0) comp_Status = RETURN_TEMP_ALERT;
    return;
  }
  if (ReturnTempC >= 888) {
    Machine_Shutdown = 1;
    if (startup_flag == 1 || modesw == 0) comp_Status = TEMP_SENSOR_ERROR;
    return;
  }

  if ((SuctionTempC < suctionAlertSp || SuctionTempC > 100.0) && SuctionTempC < 888) {
    Machine_Shutdown = 1;
    if (startup_flag == 1 || modesw == 0) comp_Status = SUCTION_TEMP_ALERT;
    return;
  }
  if (SuctionTempC >= 888) {
    Machine_Shutdown = 1;
    if (startup_flag == 1 || modesw == 0) comp_Status = TEMP_SENSOR_ERROR;
    return;
  }

  if (dischargeTempC > dischargeAlertSp && dischargeTempC < 888) {
    Machine_Shutdown = 1;
    if (startup_flag == 1 || modesw == 0) comp_Status = DISCHARGE_TEMP_ALERT;
    return;
  }
  if (dischargeTempC >= 888) {
    Machine_Shutdown = 1;
    if (startup_flag == 1 || modesw == 0) comp_Status = TEMP_SENSOR_ERROR;
    return;
  }

  if ((suctionPressure <= suctionPsiSp || suctionPressure == 888) && sucpressuresw == 1) {
    Machine_Shutdown = 1;
    if (startup_flag == 1 || modesw == 0) comp_Status = SUCTION_PSI_ALERT;
    return;
  }
  if ((dischargePressure >= dischargePsiSp || dischargePressure == 888) && dispressuresw == 1) {
    Machine_Shutdown = 1;
    if (startup_flag == 1 || modesw == 0) comp_Status = DISCHARGE_PSI_ALERT;
    return;
  }
  if ((OilPressure <= oilPsiSp || OilPressure == 888) && oilpressuresw == 1) {
    Machine_Shutdown = 1;
    if (startup_flag == 1 || modesw == 0) comp_Status = OIL_PSI_ALERT;
    return;
  }
}

// ---------------- UI bridge: display changes use the SAME variables/NVS keys as the app ----------------
bool am2UiSendCommand(const AM2UiCommand& cmd) {
  if (!uiCommandQueue) return false;
  return xQueueSend(uiCommandQueue, &cmd, 0) == pdTRUE;
}

static int16_t tempTo10(float v) {
  if (v >= 887.0f) return 8880;
  return static_cast<int16_t>(lroundf(v * 10.0f));
}

void am2UiGetSnapshot(AM2UiSnapshot& out) {
  std::memset(&out, 0, sizeof(out));
  std::snprintf(out.deviceId, sizeof(out.deviceId), "%s", devicename.c_str());
  out.returnTemp10 = tempTo10(ReturnTempC);
  out.supplyTemp10 = tempTo10(SupplyTempC);
  out.suctionTemp10 = tempTo10(SuctionTempC);
  out.dischargeTemp10 = tempTo10(dischargeTempC);

  out.sensorCount = static_cast<uint8_t>(numberOfDevices > MAX_SENSORS ? MAX_SENSORS : numberOfDevices);
  for (uint8_t i = 0; i < out.sensorCount; ++i) {
    std::memcpy(out.sensorAddress[i], tempSensorAddresses[i], 8);
    out.rawSensorTemp10[i] = tempTo10(detectedSensorTemps[i]);
    if (temp1Assigned && compareAddresses(tempSensorAddresses[i], temp1Address)) out.sensorRole[i] = 1;
    else if (temp2Assigned && compareAddresses(tempSensorAddresses[i], temp2Address)) out.sensorRole[i] = 2;
    else if (temp3Assigned && compareAddresses(tempSensorAddresses[i], temp3Address)) out.sensorRole[i] = 3;
    else if (temp4Assigned && compareAddresses(tempSensorAddresses[i], temp4Address)) out.sensorRole[i] = 4;
    else out.sensorRole[i] = 0;
  }
  for (uint8_t i = out.sensorCount; i < 4; ++i) out.rawSensorTemp10[i] = 8880;

  out.returnSp = ReturnSp;
  out.returnAlertSp = ReturnAlertSp;
  out.suctionAlertSp = suctionAlertSp;
  out.dischargeAlertSp = dischargeAlertSp;
  out.suctionPsiSp = suctionPsiSp;
  out.dischargePsiSp = dischargePsiSp;
  out.oilPsiSp = oilPsiSp;
  out.ampsLimit = amps_limit;

  out.suctionPressure = suctionPressure;
  out.dischargePressure = dischargePressure;
  out.oilPressure = OilPressure;
  out.amp1 = AMP1;
  out.amp2 = AMP2;
  out.amp3 = AMP3;

  out.compStatus = static_cast<uint8_t>(comp_Status);
  out.runRelayOn = runRelayState;
  out.alarmRelayOn = alarmRelayState;
  out.hpsActive = bitRead(inputs, HIGH_PRE) == 1;
  out.lpsActive = bitRead(inputs, LOW_PRE) == 1;
  out.opsActive = bitRead(inputs, OIL_SW) == 1;
  out.compFeedback = bitRead(inputs, COMP_PIN) == LOW; // PC817 inverts field feedback: LOW at PCF = compressor feedback present

  out.mode = modesw;
  out.autoReset = autoReset;
  out.ctEnable = CTmodulesw;
  out.suctionPressureEnable = sucpressuresw;
  out.dischargePressureEnable = dispressuresw;
  out.oilPressureEnable = oilpressuresw;
  out.lpsEnable = LPS_SW;
  out.hpsEnable = HPS_SW;
  out.opsEnable = OPS_SW;
  out.restartDelay = Comp_restart_delay;
}

static bool saveIntSetting(const char* key, int& variable, int value) {
  if (variable == value) return false;
  variable = value;
  preferences.begin("values", false);
  preferences.putInt(key, variable);
  preferences.end();
  mqttStateDirty = true;
  return true;
}

void processUiCommands() {
  if (!uiCommandQueue) return;
  AM2UiCommand cmd{};
  while (xQueueReceive(uiCommandQueue, &cmd, 0) == pdTRUE) {
    switch (cmd.type) {
      case UI_CMD_START:
        // Original AM2: START/STOP control exists only in CONTROL mode.
        if (modesw == 1) startSW = 1;
        break;
      case UI_CMD_STOP:
        if (modesw == 1) stopSW = 1;
        break;
      case UI_CMD_RETURN_SP: saveIntSetting("temp1set_HIGH", ReturnSp, cmd.value); break;
      case UI_CMD_RETURN_ALERT: saveIntSetting("temp1set_LOW", ReturnAlertSp, cmd.value); break;
      case UI_CMD_SUCTION_ALERT: saveIntSetting("temp3set_HIGH", suctionAlertSp, cmd.value); break;
      case UI_CMD_DISCHARGE_ALERT: saveIntSetting("temp4set_LOW", dischargeAlertSp, cmd.value); break;
      case UI_CMD_MODE: saveIntSetting("mode", modesw, cmd.value); break;
      case UI_CMD_AUTO_RESET: saveIntSetting("autoSwitch", autoReset, cmd.value); break;
      case UI_CMD_CT_ENABLE: saveIntSetting("currentsw", CTmodulesw, cmd.value); break;
      case UI_CMD_SUCTION_PRESSURE_ENABLE: saveIntSetting("sucpressure", sucpressuresw, cmd.value); break;
      case UI_CMD_DISCHARGE_PRESSURE_ENABLE: saveIntSetting("dispressure", dispressuresw, cmd.value); break;
      case UI_CMD_OIL_PRESSURE_ENABLE: saveIntSetting("oilpressure", oilpressuresw, cmd.value); break;
      case UI_CMD_LPS_ENABLE: saveIntSetting("suctionsw", LPS_SW, cmd.value); break;
      case UI_CMD_HPS_ENABLE: saveIntSetting("dischargesw", HPS_SW, cmd.value); break;
      case UI_CMD_OPS_ENABLE: saveIntSetting("oilsw", OPS_SW, cmd.value); break;
      case UI_CMD_RESTART_DELAY:
        saveIntSetting("restartdelay", Comp_restart_delay, cmd.value);
        Comp_restart_delay_ms = Comp_restart_delay * 1000;
        break;
      case UI_CMD_SUCTION_PSI_SP: saveIntSetting("psig1set_HIGH", suctionPsiSp, cmd.value); break;
      case UI_CMD_DISCHARGE_PSI_SP: saveIntSetting("psig2set_LOW", dischargePsiSp, cmd.value); break;
      case UI_CMD_OIL_PSI_SP: saveIntSetting("psig3set_HIGH", oilPsiSp, cmd.value); break;
      case UI_CMD_AMPS_LIMIT: saveIntSetting("AMP1_LOW", amps_limit, cmd.value); break;
      case UI_CMD_SENSOR_ASSIGN:
        if (cmd.sensorIndex < numberOfDevices && cmd.sensorIndex < MAX_SENSORS && cmd.value >= 0 && cmd.value <= 4) {
          assignSensor(static_cast<int>(cmd.value), tempSensorAddresses[cmd.sensorIndex]);
          mqttStateDirty = true;
        }
        break;
      default: break;
    }
  }
}


void printPcfDiagnostics() {
#if AM2_IO_DIAGNOSTICS
  static unsigned long lastPcfDiag = 0;
  if (millis() - lastPcfDiag < 2000UL) return;
  lastPcfDiag = millis();
  const uint8_t raw = readInputs(AM2_PCF8574_ADDR);
  Serial.printf("[PCF] %s raw=0x%02X START=%u STOP=%u RUN_OUT=%u ALARM_OUT=%u HPS=%u LPS=%u OPS=%u COMP_FB=%u | RUN_CMD=%s ALARM_CMD=%s\n",
                pcfCommFault ? "READ_FAIL" : "OK", raw,
                bitRead(raw, AM2_PCF_START_BIT), bitRead(raw, AM2_PCF_STOP_BIT),
                bitRead(raw, AM2_PCF_RUN_RELAY_BIT), bitRead(raw, AM2_PCF_ALARM_RELAY_BIT),
                bitRead(raw, AM2_PCF_HPS_BIT), bitRead(raw, AM2_PCF_LPS_BIT),
                bitRead(raw, AM2_PCF_OPS_BIT), bitRead(raw, AM2_PCF_COMP_FB_BIT),
                runRelayState ? "ON" : "OFF", alarmRelayState ? "ON" : "OFF");
#endif
}

void printOneWireDiagnostics(bool verbose) {
  static unsigned long lastDiagMs = 0;
  if (!verbose && millis() - lastDiagMs < 10000UL) return;
  lastDiagMs = millis();

  Serial.printf("[1WIRE] GPIO%d idle level: %s\n", DS18B20_PIN,
                digitalRead(DS18B20_PIN) ? "HIGH" : "LOW");

  uint8_t rom[8];
  uint8_t found = 0;
  oneWire.reset_search();
  while (found < MAX_SENSORS && oneWire.search(rom)) {
    if (OneWire::crc8(rom, 7) != rom[7]) {
      Serial.println("[1WIRE] ROM found but CRC is invalid");
      continue;
    }
    Serial.printf("[1WIRE] Device %u ROM: ", static_cast<unsigned>(found + 1));
    for (uint8_t i = 0; i < 8; ++i) {
      if (rom[i] < 0x10) Serial.print('0');
      Serial.print(rom[i], HEX);
    }
    Serial.println();
    ++found;
  }
  oneWire.reset_search();

  if (found == 0) {
    Serial.println("[1WIRE] NO ROM/PRESENCE detected on GPIO4.");
    Serial.println("[1WIRE] This occurs before app sensor assignment: check DATA wiring, 4.7k pull-up, sensor power, and GPIO4 onboard RGB-LED loading.");
  } else {
    Serial.printf("[1WIRE] Raw devices detected: %u\n", static_cast<unsigned>(found));
  }
}

void setup() {
  esp_task_wdt_init(10, true);  // original 10s watchdog
  Serial.begin(115200);

  uiCommandQueue = xQueueCreate(8, sizeof(AM2UiCommand));
  if (!uiBegin()) Serial.println("UI initialization failed!");

  // External AM2 I2C on GPIO21/22; touch has its own Wire bus on GPIO33/32.
  initInputs();

  sensors.begin();
  printOneWireDiagnostics(true);
  sensors.setWaitForConversion(false);
  sensors.requestTemperatures();
  sensors.setWaitForConversion(true);

  Serial.println("\n\n booting up device....\n\n.");
  Serial.print("Device Name: ");
  Serial.println(devicename);
  Serial.println("");

  RS485Serial.begin(9600, SERIAL_8N1, RS485_RX_PIN, RS485_TX_PIN);
  setRunRelay(false);
  setAlarmRelay(false);

  DEVICE_INIT();

  // ORIGINAL AM2 WI-FI/AP FLOW - unchanged.
  macaddress = WiFi.macAddress();
  if (loadCredentials(ssid, password)) {
    Serial.println("Loaded Wi-Fi credentials from memory.");
    connectToWiFi(ssid.c_str(), password.c_str());
  } else {
    Serial.println("No Wi-Fi credentials found. Starting in AP mode.");
    startAccessPoint();
  }
  server_setup();

  // Display splash remains visible until the original AM2 hardware/app setup is complete.
  uiSetSystemReady();
}

void loop() {
  // Same single-task LVGL servicing model as the proven WT_COOLING_CYD reference.
  uiService();
  serviceWifiHandover();
  processUiCommands();
  pollStartStopSwitches();
  printPcfDiagnostics();

  ///////////////////////////////////////////////////////////
  // Periodic sensor read - original AM2 flow, now all 4 sensors use GPIO4.
  if (millis() - pmillis >= SENSOR_READ_INTERVAL) {
    scanADC();
    sensors.begin();
    sensors.setWaitForConversion(false);
    sensors.requestTemperatures();
    sensors.setWaitForConversion(true);

    numberOfDevices = sensors.getDeviceCount();
    if (numberOfDevices > MAX_SENSORS) numberOfDevices = MAX_SENSORS;

    SuctionTempC = SENSOR_DISCONNECTED;
    dischargeTempC = SENSOR_DISCONNECTED;
    SupplyTempC = SENSOR_DISCONNECTED;
    ReturnTempC = SENSOR_DISCONNECTED;

    SuctionTemp = SENSOR_DISCONNECTED;
    dischargeTemp = SENSOR_DISCONNECTED;
    SupplyTemp = SENSOR_DISCONNECTED;
    ReturnTemp = SENSOR_DISCONNECTED;

    for (int i = 0; i < MAX_SENSORS; ++i) detectedSensorTemps[i] = SENSOR_DISCONNECTED;

    for (int i = 0; i < numberOfDevices; i++) {
      if (!sensors.getAddress(tempSensorAddresses[i], i)) {
        Serial.println("Unable to find address for Device " + String(i));
        continue;
      }

      float temperature = sensors.getTempC(tempSensorAddresses[i]);
      detectedSensorTemps[i] = temperature;
      if (temperature < 0) continue;  // original AM2 behavior preserved

      if (temp1Assigned && compareAddresses(tempSensorAddresses[i], temp1Address)) {
        SuctionTempC = temperature + suction_temp_offset;
        SuctionTemp = convertToFahrenheit(SuctionTempC);
      } else if (temp2Assigned && compareAddresses(tempSensorAddresses[i], temp2Address)) {
        dischargeTempC = temperature + discharge_temp_offset;
        dischargeTemp = convertToFahrenheit(dischargeTempC);
      } else if (temp3Assigned && compareAddresses(tempSensorAddresses[i], temp3Address)) {
        SupplyTempC = temperature + supply_temp_offset;
        SupplyTemp = convertToFahrenheit(SupplyTempC);
      } else if (temp4Assigned && compareAddresses(tempSensorAddresses[i], temp4Address)) {
        // CHANGE #1: sensor 4 is always Return. BECA selection is removed.
        ReturnTempC = temperature + return_air_temp_offset;
        ReturnTemp = convertToFahrenheit(ReturnTempC);
      }
    }

    if (numberOfDevices == 0) {
      Serial.println("No Sensor Found!");
      printOneWireDiagnostics(false);
    }
    pmillis = millis();
  }

  serviceAmpReader();

  // ---------------- ORIGINAL MONITORING + CONTROL LOGIC ----------------
  if (modesw == 1) {
    if (!startup_flag && !alarmFlag) {
      if (startSW == 1) {
        startSW = stopSW = 0;
        startup_flag = true;
        Serial.println("External Start SW");
      }
      else if (AutoAlarmReset == 1 && millis() - RESTART_TIME > Comp_restart_delay_ms) {
        startup_flag = true;
        AutoAlarmReset = 0;
        Serial.println("Auto Startup!");
      }
    }

    bool MahineStatus = (Machine_Shutdown == 0 && Switches_alarm == 0 && ReturnTempC != 888);
    if (MahineStatus) {
      if (stopSW == 1) {
        startSW = stopSW = alarmFlag = startup_flag = false;
        Serial.println("Machine STOP");
        setAlarmRelay(false);
        setRunRelay(false);
        comp_Status = 0;
        uiDelay(150);
      }

      if (autoReset == 1 && alarmFlag && (millis() - COMP_TRIP_HOLD_TIME > 20000)) {
        Serial.println("RESTARTING");
        setAlarmRelay(false);
        AutoAlarmReset = 1;
        alarmFlag = false;
        comp_Status = RESTARTING;
        RESTART_TIME = millis();
      }
    }

    scanAlarms();

    if (startup_flag) {
      if (Machine_Shutdown == 1 || (Switches_alarm == 1 && millis() - SWITCH_ALARM_HOLD_TIME > 500) || comp_alarm == 1 || ReturnTempC == 888) {
        Serial.println("Machine Tripped!");
        setRunRelay(false);
        setAlarmRelay(true);
        startup_flag = false;
        alarmFlag = true;
        comp_alarm = 0;
        COMP_TRIP_HOLD_TIME = millis();
        return;
      }
      if (comp_Status != 1 && ReturnTempC > ReturnSp && !Switches_alarm) {
        Serial.println("Machine Started!");
        setRunRelay(true);
        comp_Status = 1;
        COMP_START_TIME = millis();
      }
      if (ReturnTempC < ReturnSp && comp_Status != 2) {
        Serial.println("Machine_AUTO_STOPPED");
        setRunRelay(false);
        comp_Status = 2;
      }
    }
  }
  else if (modesw == 0) {
    scanAlarms();

    bool shutdown = (Machine_Shutdown == 1 || (Switches_alarm == 1 && millis() - SWITCH_ALARM_HOLD_TIME > 500) || ReturnTempC == 888);
    if (shutdown && !alarmFlag) {
      Serial.println("Machine TRIPPED");
      setAlarmRelay(true);
      comp_alarm = 0;
      alarmFlag = true;
    } else if (!shutdown && alarmFlag) {
      setAlarmRelay(false);
      alarmFlag = false;
    }

    if (!alarmFlag) {
      // PC817 inversion confirmed on the user's hardware:
      // compressor field feedback HIGH -> PC817 ON -> PCF P7 LOW = RUNNING.
      comp_Status = (bitRead(inputs, COMP_PIN) == LOW) ? RUNNING : STOPPED;
    }
  }

  ///////////////////////////////////////////////////////////
  // MQTT/app/display synchronization. Process incoming commands first.
  // Reconnect attempts are throttled, and the three retained JSONs are sent
  // one per loop pass instead of as one blocking TLS burst.
  static uint32_t lastMqttReconnectAttempt = 0;
  if (!client.connected()) {
    if (WiFi.status() == WL_CONNECTED && millis() - lastMqttReconnectAttempt >= 5000UL) {
      lastMqttReconnectAttempt = millis();
      reconnect();
    }
  } else {
    client.loop();
  }

  const bool mqttPeriodicDue = (millis() - wait_time >= MQTT_INTERVAL);
  if (WiFi.status() == WL_CONNECTED && client.connected() &&
      !mqttPublishCycleActive && (mqttStateDirty || mqttPeriodicDue)) {
    startMqttPublishCycle();
  }
  serviceMqttPublishCycle();

  // Keep touch/UI responsive even when no controller state changed.
  uiService();
  delay(2);
}
