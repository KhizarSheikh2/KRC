#include "UI.h"
#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include <lvgl.h>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include "esp_heap_caps.h"
#include "BoardConfig.h"
#include "CST820Touch.h"
#include "AM2UiBridge.h"

namespace {

TFT_eSPI tft;
CST820Touch touch;
lv_disp_draw_buf_t drawBuf;
lv_color_t* drawPixels = nullptr;
lv_disp_drv_t dispDrv;
lv_indev_drv_t indevDrv;

bool touchDetected = false;
volatile bool systemReady = false;
bool mainBuilt = false;
volatile bool forceRefresh = false;
uint32_t lastTickMs = 0;
uint32_t lastHandlerMs = 0;
uint32_t bootMs = 0;

static constexpr uint16_t DRAW_ROWS_PREFERRED = 20;
static constexpr uint32_t UI_MODEL_REFRESH_MS = 250;
static constexpr uint32_t UI_HANDLER_MIN_MS = 5;  // prevent 1 kHz LVGL/touch polling inside cooperative waits
static constexpr uint32_t SPLASH_MIN_MS = 900;

lv_point_t lastPoint = {AM2_SCREEN_W / 2, AM2_SCREEN_H / 2};

// Dark industrial palette: high contrast, no gradients or shadows.
constexpr uint32_t C_BG       = 0x040A10;
constexpr uint32_t C_HEADER   = 0x081521;
constexpr uint32_t C_PANEL    = 0x0B1824;
constexpr uint32_t C_PANEL2   = 0x102535;
constexpr uint32_t C_BORDER   = 0x22445A;
constexpr uint32_t C_TEXT     = 0xF2F7FA;
constexpr uint32_t C_MUTED    = 0x8EA5B4;
constexpr uint32_t C_CYAN     = 0x2BC9F2;
constexpr uint32_t C_GREEN    = 0x2DD692;
constexpr uint32_t C_AMBER    = 0xF0B54D;
constexpr uint32_t C_RED      = 0xF45B6A;
constexpr uint32_t C_ACTIVE   = 0x15384B;

// 320x240 layout. Every top-level object stays inside these bounds.
constexpr int HEADER_X = 6;
constexpr int HEADER_Y = 4;
constexpr int HEADER_W = 308;
constexpr int HEADER_H = 34;
constexpr int PAGE_X = 4;
constexpr int PAGE_Y = 42;
constexpr int PAGE_W = 312;
constexpr int PAGE_H = 153;
constexpr int NAV_Y = 198;
constexpr int NAV_BTN_W = 60;
constexpr int NAV_BTN_H = 38;
constexpr int NAV_GAP = 3;

lv_obj_t* splash = nullptr;
lv_obj_t* splashStatus = nullptr;
lv_obj_t* mainScreen = nullptr;
lv_obj_t* headerId = nullptr;
lv_obj_t* pages[5] = {};
lv_obj_t* nav[5] = {};
int activePage = 0;

lv_obj_t* homeTemps[4] = {};
lv_obj_t* homeStatus = nullptr;
lv_obj_t* homeRun = nullptr;
lv_obj_t* homeSp = nullptr;
lv_obj_t* homeSpTitle = nullptr;
lv_obj_t* homeMode = nullptr;
lv_obj_t* startStopBtn = nullptr;
lv_obj_t* startStopLabel = nullptr;
lv_obj_t* monitorOnlyLabel = nullptr;

lv_obj_t* controlValues[4] = {};
lv_obj_t* safetyPressure[3] = {};
lv_obj_t* safetyAmps[3] = {};
lv_obj_t* safetySwitches[4] = {};

lv_obj_t* sensorCount = nullptr;
lv_obj_t* sensorAddr[4] = {};
lv_obj_t* sensorTemp[4] = {};
lv_obj_t* sensorRoleBtn[4] = {};
lv_obj_t* sensorRoleLabel[4] = {};

lv_obj_t* setupValue[14] = {};

lv_obj_t* editOverlay = nullptr;
lv_obj_t* editValueLabel = nullptr;
int32_t editValue = 0;
int32_t editMin = 0;
int32_t editMax = 0;
int32_t editStep = 1;
uint8_t editCommand = UI_CMD_NONE;
char editUnit[10] = {0};

lv_obj_t* sensorOverlay = nullptr;
uint8_t selectedSensor = 0;
AM2UiSnapshot snap{};

lv_color_t col(uint32_t c) { return lv_color_hex(c); }

void noScroll(lv_obj_t* o) {
  lv_obj_clear_flag(o, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_outline_width(o, 0, LV_PART_MAIN);
}

void styleBox(lv_obj_t* o, uint32_t bg = C_PANEL, int radius = 8) {
  lv_obj_set_style_bg_color(o, col(bg), LV_PART_MAIN);
  lv_obj_set_style_bg_opa(o, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_border_width(o, 1, LV_PART_MAIN);
  lv_obj_set_style_border_color(o, col(C_BORDER), LV_PART_MAIN);
  lv_obj_set_style_radius(o, radius, LV_PART_MAIN);
  lv_obj_set_style_pad_all(o, 0, LV_PART_MAIN);
  lv_obj_set_style_shadow_width(o, 0, LV_PART_MAIN);
  lv_obj_set_style_outline_width(o, 0, LV_PART_MAIN);
}

lv_obj_t* label(lv_obj_t* p, const char* text, int x, int y,
                const lv_font_t* font = &lv_font_montserrat_12,
                uint32_t color = C_TEXT) {
  lv_obj_t* l = lv_label_create(p);
  lv_label_set_text(l, text);
  lv_obj_set_pos(l, x, y);
  lv_obj_set_style_text_font(l, font, LV_PART_MAIN);
  lv_obj_set_style_text_color(l, col(color), LV_PART_MAIN);
  return l;
}

void setLabelBox(lv_obj_t* l, int w, int h, lv_text_align_t align = LV_TEXT_ALIGN_LEFT) {
  lv_obj_set_size(l, w, h);
  lv_obj_set_style_text_align(l, align, LV_PART_MAIN);
  lv_label_set_long_mode(l, LV_LABEL_LONG_WRAP);
}

lv_obj_t* bareButton(lv_obj_t* p, int x, int y, int w, int h, uint32_t bg = C_PANEL2) {
  lv_obj_t* b = lv_btn_create(p);
  lv_obj_set_pos(b, x, y);
  lv_obj_set_size(b, w, h);
  styleBox(b, bg, 7);
  lv_obj_set_style_bg_color(b, col(C_ACTIVE), LV_PART_MAIN | LV_STATE_PRESSED);
  lv_obj_set_style_border_color(b, col(C_CYAN), LV_PART_MAIN | LV_STATE_PRESSED);
  return b;
}

lv_obj_t* button(lv_obj_t* p, int x, int y, int w, int h, const char* text,
                 const lv_font_t* font = &lv_font_montserrat_12) {
  lv_obj_t* b = bareButton(p, x, y, w, h);
  lv_obj_t* l = lv_label_create(b);
  lv_label_set_text(l, text);
  lv_obj_set_style_text_font(l, font, LV_PART_MAIN);
  lv_obj_set_style_text_color(l, col(C_TEXT), LV_PART_MAIN);
  lv_obj_center(l);
  return b;
}

void setText(lv_obj_t* l, const char* text) {
  if (!l) return;
  const char* old = lv_label_get_text(l);
  if (!old || std::strcmp(old, text) != 0) lv_label_set_text(l, text);
}

const char* statusText(uint8_t s) {
  switch (s) {
    case 0: return "STOPPED";
    case 1: return "RUNNING";
    case 2: return "AUTO STOP";
    case 4: return "RESTARTING";
    case 5: return "RETURN TEMP HIGH";
    case 6: return "SUCTION TEMP LOW";
    case 7: return "DISCH TEMP HIGH";
    case 8: return "SUCTION PSI LOW";
    case 9: return "DISCH PSI HIGH";
    case 10: return "OIL PSI LOW";
    case 11: return "HIGH CURRENT";
    case 12: return "LOW PRESSURE";
    case 13: return "HIGH PRESSURE";
    case 14: return "OIL PRESSURE";
    case 15: return "COMPRESSOR FAIL";
    case 16: return "TEMP SENSOR ERROR";
    case 17: return "MC STUCK";
    default: return "UNKNOWN";
  }
}

uint32_t statusColor(uint8_t s) {
  if (s == 1) return C_GREEN;
  if (s == 2) return C_CYAN;
  if (s == 4) return C_AMBER;
  if (s >= 5) return C_RED;
  return C_MUTED;
}

const char* roleText(uint8_t role) {
  switch (role) {
    case 1: return "SUCTION";
    case 2: return "DISCH.";
    case 3: return "SUPPLY";
    case 4: return "RETURN";
    default: return "NONE";
  }
}

void formatTemp(char* out, size_t n, int16_t t10) {
  if (t10 >= 8870) std::snprintf(out, n, "--.- C");
  else std::snprintf(out, n, "%.1f C", t10 / 10.0f);
}

void formatIntOrDash(char* out, size_t n, int value, const char* unit = "") {
  if (value >= 887) std::snprintf(out, n, "--%s", unit);
  else std::snprintf(out, n, "%d%s", value, unit);
}

void shortAddress(char* out, size_t n, const uint8_t a[8]) {
  bool any = false;
  for (int i = 0; i < 8; ++i) any |= (a[i] != 0);
  if (!any) { std::snprintf(out, n, "--"); return; }
  std::snprintf(out, n, "%02X%02X%02X..%02X%02X", a[0], a[1], a[2], a[6], a[7]);
}

void send(uint8_t type, int32_t value = 0, uint8_t sensor = 0) {
  AM2UiCommand c{type, value, sensor};
  (void)am2UiSendCommand(c);
}

void showPage(int index) {
  if (index < 0 || index > 4) return;
  // Navigation is intentionally handled on LV_EVENT_PRESSED so the page changes
  // as soon as the finger touches the button, matching the responsive WT reference.
  if (mainBuilt && index == activePage) return;
  activePage = index;
  for (int i = 0; i < 5; ++i) {
    if (i == index) lv_obj_clear_flag(pages[i], LV_OBJ_FLAG_HIDDEN);
    else lv_obj_add_flag(pages[i], LV_OBJ_FLAG_HIDDEN);
    lv_obj_set_style_border_color(nav[i], col(i == index ? C_CYAN : C_BORDER), LV_PART_MAIN);
    lv_obj_set_style_bg_color(nav[i], col(i == index ? C_ACTIVE : C_PANEL), LV_PART_MAIN);
  }
  forceRefresh = true;
}

void navEvent(lv_event_t* e) {
  intptr_t i = reinterpret_cast<intptr_t>(lv_event_get_user_data(e));
  showPage(static_cast<int>(i));
}

void startStopEvent(lv_event_t*) {
  // Original AM2 behavior: START/STOP belongs to CONTROL mode only.
  // MONITOR mode is observation/protection only and must never issue RUN commands.
  if (snap.mode != 1) return;
  if (snap.runRelayOn || snap.compStatus == 1 || snap.compStatus == 2 || snap.compStatus == 4) send(UI_CMD_STOP);
  else send(UI_CMD_START);
}

struct EditAction {
  uint8_t cmd;
  const char* title;
  const char* unit;
  int minV;
  int maxV;
  int step;
  bool toggle;
};

const EditAction actions[] = {
  {UI_CMD_RETURN_SP, "RETURN SETPOINT", " C", 5, 40, 1, false},
  {UI_CMD_RETURN_ALERT, "RETURN HIGH LIMIT", " C", 5, 100, 1, false},
  {UI_CMD_SUCTION_ALERT, "SUCTION LOW LIMIT", " C", -40, 40, 1, false},
  {UI_CMD_DISCHARGE_ALERT, "DISCHARGE HIGH LIMIT", " C", 10, 150, 1, false},
  {UI_CMD_MODE, "OPERATING MODE", "", 0, 1, 1, true},
  {UI_CMD_AUTO_RESET, "AUTO RESET", "", 0, 1, 1, true},
  {UI_CMD_CT_ENABLE, "CURRENT MODULE", "", 0, 1, 1, true},
  {UI_CMD_SUCTION_PRESSURE_ENABLE, "SUCTION PRESSURE", "", 0, 1, 1, true},
  {UI_CMD_DISCHARGE_PRESSURE_ENABLE, "DISCHARGE PRESSURE", "", 0, 1, 1, true},
  {UI_CMD_OIL_PRESSURE_ENABLE, "OIL PRESSURE", "", 0, 1, 1, true},
  {UI_CMD_LPS_ENABLE, "LPS PROTECTION", "", 0, 1, 1, true},
  {UI_CMD_HPS_ENABLE, "HPS PROTECTION", "", 0, 1, 1, true},
  {UI_CMD_OPS_ENABLE, "OPS PROTECTION", "", 0, 1, 1, true},
  {UI_CMD_RESTART_DELAY, "RESTART DELAY", " s", 0, 600, 5, false},
  {UI_CMD_SUCTION_PSI_SP, "SUCTION PSI LIMIT", " psi", 0, 1000, 1, false},
  {UI_CMD_DISCHARGE_PSI_SP, "DISCHARGE PSI LIMIT", " psi", 0, 1500, 5, false},
  {UI_CMD_OIL_PSI_SP, "OIL PSI LIMIT", " psi", 0, 1000, 1, false},
  {UI_CMD_AMPS_LIMIT, "MAX CURRENT", " A", 0, 200, 1, false},
};

int currentValueForCommand(uint8_t cmd) {
  switch (cmd) {
    case UI_CMD_RETURN_SP: return snap.returnSp;
    case UI_CMD_RETURN_ALERT: return snap.returnAlertSp;
    case UI_CMD_SUCTION_ALERT: return snap.suctionAlertSp;
    case UI_CMD_DISCHARGE_ALERT: return snap.dischargeAlertSp;
    case UI_CMD_MODE: return snap.mode;
    case UI_CMD_AUTO_RESET: return snap.autoReset;
    case UI_CMD_CT_ENABLE: return snap.ctEnable;
    case UI_CMD_SUCTION_PRESSURE_ENABLE: return snap.suctionPressureEnable;
    case UI_CMD_DISCHARGE_PRESSURE_ENABLE: return snap.dischargePressureEnable;
    case UI_CMD_OIL_PRESSURE_ENABLE: return snap.oilPressureEnable;
    case UI_CMD_LPS_ENABLE: return snap.lpsEnable;
    case UI_CMD_HPS_ENABLE: return snap.hpsEnable;
    case UI_CMD_OPS_ENABLE: return snap.opsEnable;
    case UI_CMD_RESTART_DELAY: return snap.restartDelay;
    case UI_CMD_SUCTION_PSI_SP: return snap.suctionPsiSp;
    case UI_CMD_DISCHARGE_PSI_SP: return snap.dischargePsiSp;
    case UI_CMD_OIL_PSI_SP: return snap.oilPsiSp;
    case UI_CMD_AMPS_LIMIT: return snap.ampsLimit;
    default: return 0;
  }
}

void closeEditor() {
  if (editOverlay) {
    lv_obj_del(editOverlay);
    editOverlay = nullptr;
    editValueLabel = nullptr;
  }
}

void editorRefresh() {
  if (!editValueLabel) return;
  char b[32];
  std::snprintf(b, sizeof(b), "%ld%s", static_cast<long>(editValue), editUnit);
  setText(editValueLabel, b);
}

void editorMinus(lv_event_t*) { editValue = std::max<int32_t>(editMin, editValue - editStep); editorRefresh(); }
void editorPlus(lv_event_t*)  { editValue = std::min<int32_t>(editMax, editValue + editStep); editorRefresh(); }
void editorCancel(lv_event_t*) { closeEditor(); }
void editorSave(lv_event_t*) { send(editCommand, editValue); closeEditor(); forceRefresh = true; }

void openEditor(const EditAction& a) {
  if (a.toggle) {
    send(a.cmd, currentValueForCommand(a.cmd) ? 0 : 1);
    forceRefresh = true;
    return;
  }

  closeEditor();
  editCommand = a.cmd;
  editValue = currentValueForCommand(a.cmd);
  editMin = a.minV;
  editMax = a.maxV;
  editStep = a.step;
  std::strncpy(editUnit, a.unit, sizeof(editUnit) - 1);
  editUnit[sizeof(editUnit)-1] = 0;

  editOverlay = lv_obj_create(lv_layer_top());
  lv_obj_set_pos(editOverlay, 32, 37);
  lv_obj_set_size(editOverlay, 256, 166);
  styleBox(editOverlay, 0x07121D, 12);
  lv_obj_set_style_border_color(editOverlay, col(C_CYAN), LV_PART_MAIN);
  noScroll(editOverlay);

  lv_obj_t* title = label(editOverlay, a.title, 14, 12, &lv_font_montserrat_14, C_CYAN);
  setLabelBox(title, 228, 20, LV_TEXT_ALIGN_CENTER);

  lv_obj_t* minus = button(editOverlay, 16, 49, 58, 50, "-", &lv_font_montserrat_20);
  lv_obj_add_event_cb(minus, editorMinus, LV_EVENT_CLICKED, nullptr);

  editValueLabel = label(editOverlay, "", 83, 63, &lv_font_montserrat_20, C_TEXT);
  setLabelBox(editValueLabel, 90, 30, LV_TEXT_ALIGN_CENTER);

  lv_obj_t* plus = button(editOverlay, 182, 49, 58, 50, "+", &lv_font_montserrat_20);
  lv_obj_add_event_cb(plus, editorPlus, LV_EVENT_CLICKED, nullptr);

  lv_obj_t* cancel = button(editOverlay, 16, 116, 104, 36, "CANCEL", &lv_font_montserrat_12);
  lv_obj_add_event_cb(cancel, editorCancel, LV_EVENT_CLICKED, nullptr);
  lv_obj_t* save = button(editOverlay, 136, 116, 104, 36, "SAVE", &lv_font_montserrat_12);
  lv_obj_set_style_border_color(save, col(C_GREEN), LV_PART_MAIN);
  lv_obj_add_event_cb(save, editorSave, LV_EVENT_CLICKED, nullptr);
  editorRefresh();
}

void actionEvent(lv_event_t* e) {
  intptr_t idx = reinterpret_cast<intptr_t>(lv_event_get_user_data(e));
  if (idx < 0 || idx >= static_cast<intptr_t>(sizeof(actions)/sizeof(actions[0]))) return;
  openEditor(actions[idx]);
}

void closeSensorOverlay() {
  if (sensorOverlay) { lv_obj_del(sensorOverlay); sensorOverlay = nullptr; }
}
void sensorCancel(lv_event_t*) { closeSensorOverlay(); }
void sensorChoice(lv_event_t* e) {
  uint8_t role = static_cast<uint8_t>(reinterpret_cast<intptr_t>(lv_event_get_user_data(e)));
  send(UI_CMD_SENSOR_ASSIGN, role, selectedSensor);
  closeSensorOverlay();
  forceRefresh = true;
}

void openSensorOverlay(uint8_t index) {
  selectedSensor = index;
  closeSensorOverlay();
  sensorOverlay = lv_obj_create(lv_layer_top());
  lv_obj_set_pos(sensorOverlay, 24, 34);
  lv_obj_set_size(sensorOverlay, 272, 172);
  styleBox(sensorOverlay, 0x07121D, 12);
  lv_obj_set_style_border_color(sensorOverlay, col(C_CYAN), LV_PART_MAIN);
  noScroll(sensorOverlay);

  lv_obj_t* title = label(sensorOverlay, "ASSIGN SENSOR", 14, 10, &lv_font_montserrat_14, C_CYAN);
  setLabelBox(title, 244, 20, LV_TEXT_ALIGN_CENTER);

  const char* names[5] = {"NONE", "SUCTION", "DISCHARGE", "SUPPLY", "RETURN"};
  for (int i = 0; i < 5; ++i) {
    int x = 12 + (i % 2) * 124;
    int y = 39 + (i / 2) * 39;
    lv_obj_t* b = button(sensorOverlay, x, y, 112, 34, names[i], &lv_font_montserrat_12);
    lv_obj_add_event_cb(b, sensorChoice, LV_EVENT_CLICKED, reinterpret_cast<void*>(static_cast<intptr_t>(i)));
  }
  lv_obj_t* c = button(sensorOverlay, 136, 117, 112, 34, "CANCEL", &lv_font_montserrat_12);
  lv_obj_add_event_cb(c, sensorCancel, LV_EVENT_CLICKED, nullptr);
}

void sensorRowEvent(lv_event_t* e) {
  intptr_t idx = reinterpret_cast<intptr_t>(lv_event_get_user_data(e));
  if (idx >= 0 && idx < 4 && idx < snap.sensorCount) openSensorOverlay(static_cast<uint8_t>(idx));
}

lv_obj_t* newPage() {
  lv_obj_t* p = lv_obj_create(mainScreen);
  lv_obj_set_pos(p, PAGE_X, PAGE_Y);
  lv_obj_set_size(p, PAGE_W, PAGE_H);
  lv_obj_set_style_bg_opa(p, LV_OPA_TRANSP, LV_PART_MAIN);
  lv_obj_set_style_border_width(p, 0, LV_PART_MAIN);
  lv_obj_set_style_pad_all(p, 0, LV_PART_MAIN);
  noScroll(p);
  return p;
}

void buildHeaderAndNav() {
  lv_obj_t* h = lv_obj_create(mainScreen);
  lv_obj_set_pos(h, HEADER_X, HEADER_Y);
  lv_obj_set_size(h, HEADER_W, HEADER_H);
  styleBox(h, C_HEADER, 9);
  noScroll(h);

  label(h, "AM2", 12, 5, &lv_font_montserrat_20, C_TEXT);
  headerId = label(h, "AM2-444051", 156, 8, &lv_font_montserrat_14, C_CYAN);
  setLabelBox(headerId, 138, 20, LV_TEXT_ALIGN_RIGHT);

  const char* names[5] = {"HOME", "CTRL", "SAFE", "SENS", "SET"};
  for (int i = 0; i < 5; ++i) {
    const int x = 4 + i * (NAV_BTN_W + NAV_GAP);
    nav[i] = button(mainScreen, x, NAV_Y, NAV_BTN_W, NAV_BTN_H, names[i], &lv_font_montserrat_14);
    lv_obj_add_event_cb(nav[i], navEvent, LV_EVENT_PRESSED,
                        reinterpret_cast<void*>(static_cast<intptr_t>(i)));
  }
}

void buildHome() {
  pages[0] = newPage();
  const char* names[4] = {"RETURN", "SUPPLY", "SUCTION", "DISCH."};
  for (int i = 0; i < 4; ++i) {
    lv_obj_t* c = lv_obj_create(pages[0]);
    lv_obj_set_pos(c, i * 78, 0);
    lv_obj_set_size(c, 74, 52);
    styleBox(c, C_PANEL, 8);
    noScroll(c);

    lv_obj_t* n = label(c, names[i], 0, 6, &lv_font_montserrat_10, C_MUTED);
    setLabelBox(n, 74, 14, LV_TEXT_ALIGN_CENTER);
    homeTemps[i] = label(c, "--.- C", 0, 25, &lv_font_montserrat_16, C_TEXT);
    setLabelBox(homeTemps[i], 74, 22, LV_TEXT_ALIGN_CENTER);
  }

  lv_obj_t* statusCard = lv_obj_create(pages[0]);
  lv_obj_set_pos(statusCard, 0, 57);
  lv_obj_set_size(statusCard, 153, 94);
  styleBox(statusCard, C_PANEL, 8);
  noScroll(statusCard);

  label(statusCard, "STATUS", 10, 7, &lv_font_montserrat_10, C_MUTED);
  homeStatus = label(statusCard, "STOPPED", 10, 26, &lv_font_montserrat_14, C_TEXT);
  setLabelBox(homeStatus, 133, 35, LV_TEXT_ALIGN_LEFT);
  homeRun = label(statusCard, "RUN RELAY: OFF", 10, 73, &lv_font_montserrat_10, C_MUTED);
  setLabelBox(homeRun, 133, 15, LV_TEXT_ALIGN_LEFT);

  lv_obj_t* controlCard = lv_obj_create(pages[0]);
  lv_obj_set_pos(controlCard, 157, 57);
  lv_obj_set_size(controlCard, 155, 94);
  styleBox(controlCard, C_PANEL, 8);
  noScroll(controlCard);

  label(controlCard, "MODE", 10, 7, &lv_font_montserrat_10, C_MUTED);
  homeMode = label(controlCard, "MONITOR", 83, 7, &lv_font_montserrat_10, C_CYAN);
  setLabelBox(homeMode, 62, 14, LV_TEXT_ALIGN_RIGHT);
  homeSpTitle = label(controlCard, "SETPOINT", 10, 30, &lv_font_montserrat_10, C_MUTED);
  homeSp = label(controlCard, "0 C", 70, 24, &lv_font_montserrat_20, C_TEXT);
  setLabelBox(homeSp, 72, 26, LV_TEXT_ALIGN_RIGHT);

  startStopBtn = button(controlCard, 10, 58, 135, 29, "START SYSTEM", &lv_font_montserrat_12);
  startStopLabel = lv_obj_get_child(startStopBtn, 0);
  lv_obj_add_event_cb(startStopBtn, startStopEvent, LV_EVENT_CLICKED, nullptr);

  monitorOnlyLabel = label(controlCard, "MONITORING ONLY", 10, 64, &lv_font_montserrat_12, C_GREEN);
  setLabelBox(monitorOnlyLabel, 135, 18, LV_TEXT_ALIGN_CENTER);
  lv_obj_add_flag(monitorOnlyLabel, LV_OBJ_FLAG_HIDDEN);
}

void buildControl() {
  pages[1] = newPage();
  label(pages[1], "TEMPERATURE CONTROL", 2, 1, &lv_font_montserrat_14, C_CYAN);
  const char* names[4] = {"Return Setpoint", "Return High", "Suction Low", "Discharge High"};

  for (int i = 0; i < 4; ++i) {
    lv_obj_t* r = bareButton(pages[1], 0, 24 + i * 31, 312, 28, C_PANEL);
    label(r, names[i], 10, 6, &lv_font_montserrat_12, C_TEXT);
    controlValues[i] = label(r, "0 C", 232, 6, &lv_font_montserrat_12, C_CYAN);
    setLabelBox(controlValues[i], 68, 18, LV_TEXT_ALIGN_RIGHT);
    lv_obj_add_event_cb(r, actionEvent, LV_EVENT_CLICKED,
                        reinterpret_cast<void*>(static_cast<intptr_t>(i)));
  }
}

void buildSafety() {
  pages[2] = newPage();
  label(pages[2], "SAFETY MONITOR", 2, 1, &lv_font_montserrat_14, C_CYAN);
  const char* pnames[3] = {"SUCT PSI", "DISCH PSI", "OIL PSI"};
  const char* anames[3] = {"AMP 1", "AMP 2", "AMP 3"};

  for (int i = 0; i < 3; ++i) {
    lv_obj_t* p = lv_obj_create(pages[2]);
    lv_obj_set_pos(p, i * 104, 24);
    lv_obj_set_size(p, 100, 44);
    styleBox(p, C_PANEL, 8);
    noScroll(p);
    lv_obj_t* pn = label(p, pnames[i], 0, 5, &lv_font_montserrat_10, C_MUTED);
    setLabelBox(pn, 100, 14, LV_TEXT_ALIGN_CENTER);
    safetyPressure[i] = label(p, "--", 0, 21, &lv_font_montserrat_14, C_TEXT);
    setLabelBox(safetyPressure[i], 100, 20, LV_TEXT_ALIGN_CENTER);

    lv_obj_t* a = lv_obj_create(pages[2]);
    lv_obj_set_pos(a, i * 104, 72);
    lv_obj_set_size(a, 100, 39);
    styleBox(a, C_PANEL, 8);
    noScroll(a);
    lv_obj_t* an = label(a, anames[i], 0, 4, &lv_font_montserrat_10, C_MUTED);
    setLabelBox(an, 100, 14, LV_TEXT_ALIGN_CENTER);
    safetyAmps[i] = label(a, "--", 0, 19, &lv_font_montserrat_14, C_TEXT);
    setLabelBox(safetyAmps[i], 100, 18, LV_TEXT_ALIGN_CENTER);
  }

  for (int i = 0; i < 4; ++i) {
    lv_obj_t* pill = lv_obj_create(pages[2]);
    lv_obj_set_pos(pill, i * 78, 118);
    lv_obj_set_size(pill, 74, 27);
    styleBox(pill, C_PANEL2, 7);
    noScroll(pill);
    safetySwitches[i] = label(pill, "--", 0, 7, &lv_font_montserrat_10, C_MUTED);
    setLabelBox(safetySwitches[i], 74, 14, LV_TEXT_ALIGN_CENTER);
  }
}

void buildSensors() {
  pages[3] = newPage();
  label(pages[3], "TEMPERATURE SENSORS", 2, 1, &lv_font_montserrat_14, C_CYAN);
  sensorCount = label(pages[3], "0 / 4", 252, 2, &lv_font_montserrat_12, C_MUTED);
  setLabelBox(sensorCount, 56, 18, LV_TEXT_ALIGN_RIGHT);

  for (int i = 0; i < 4; ++i) {
    lv_obj_t* row = bareButton(pages[3], 0, 24 + i * 31, 312, 28, C_PANEL);
    lv_obj_add_event_cb(row, sensorRowEvent, LV_EVENT_CLICKED,
                        reinterpret_cast<void*>(static_cast<intptr_t>(i)));

    char s[4];
    std::snprintf(s, sizeof(s), "S%d", i + 1);
    label(row, s, 7, 6, &lv_font_montserrat_10, C_MUTED);
    sensorAddr[i] = label(row, "--", 31, 6, &lv_font_montserrat_10, C_TEXT);
    sensorTemp[i] = label(row, "--.- C", 145, 6, &lv_font_montserrat_10, C_TEXT);
    sensorRoleLabel[i] = label(row, "NONE", 220, 6, &lv_font_montserrat_10, C_CYAN);
    setLabelBox(sensorRoleLabel[i], 82, 16, LV_TEXT_ALIGN_RIGHT);
    sensorRoleBtn[i] = row;
  }
}

void buildSettings() {
  pages[4] = newPage();
  label(pages[4], "SYSTEM SETTINGS", 2, 1, &lv_font_montserrat_14, C_CYAN);

  lv_obj_t* list = lv_obj_create(pages[4]);
  lv_obj_set_pos(list, 0, 24);
  lv_obj_set_size(list, 312, 125);
  lv_obj_set_style_bg_opa(list, LV_OPA_TRANSP, LV_PART_MAIN);
  lv_obj_set_style_border_width(list, 0, LV_PART_MAIN);
  lv_obj_set_style_pad_all(list, 0, LV_PART_MAIN);
  lv_obj_set_scroll_dir(list, LV_DIR_VER);
  lv_obj_set_scrollbar_mode(list, LV_SCROLLBAR_MODE_AUTO);
  lv_obj_set_style_width(list, 3, LV_PART_SCROLLBAR);
  lv_obj_set_style_bg_color(list, col(C_CYAN), LV_PART_SCROLLBAR);
  lv_obj_set_style_bg_opa(list, LV_OPA_50, LV_PART_SCROLLBAR);

  const int actionIndex[14] = {4,5,6,7,8,9,10,11,12,13,14,15,16,17};
  const char* names[14] = {
    "Operating Mode", "Auto Reset", "Current Module", "Suction Pressure",
    "Discharge Pressure", "Oil Pressure", "LPS Protection", "HPS Protection",
    "OPS Protection", "Restart Delay", "Suction PSI Limit", "Discharge PSI Limit",
    "Oil PSI Limit", "Max Current"
  };

  for (int i = 0; i < 14; ++i) {
    lv_obj_t* r = bareButton(list, 0, i * 31, 304, 29, C_PANEL);
    label(r, names[i], 9, 6, &lv_font_montserrat_10, C_TEXT);
    setupValue[i] = label(r, "--", 216, 6, &lv_font_montserrat_10, C_CYAN);
    setLabelBox(setupValue[i], 78, 16, LV_TEXT_ALIGN_RIGHT);
    lv_obj_add_event_cb(r, actionEvent, LV_EVENT_CLICKED,
                        reinterpret_cast<void*>(static_cast<intptr_t>(actionIndex[i])));
  }
}

void buildMain() {
  am2UiGetSnapshot(snap);

  mainScreen = lv_obj_create(nullptr);
  lv_obj_set_style_bg_color(mainScreen, col(C_BG), LV_PART_MAIN);
  lv_obj_set_style_bg_opa(mainScreen, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_pad_all(mainScreen, 0, LV_PART_MAIN);
  noScroll(mainScreen);

  buildHeaderAndNav();
  buildHome();
  buildControl();
  buildSafety();
  buildSensors();
  buildSettings();

  setText(headerId, snap.deviceId);
  showPage(0);
  lv_scr_load(mainScreen);
  mainBuilt = true;
  forceRefresh = true;
}

void buildSplash() {
  splash = lv_obj_create(nullptr);
  lv_obj_set_style_bg_color(splash, col(C_BG), LV_PART_MAIN);
  lv_obj_set_style_bg_opa(splash, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_pad_all(splash, 0, LV_PART_MAIN);
  noScroll(splash);

  lv_obj_t* card = lv_obj_create(splash);
  lv_obj_set_pos(card, 36, 34);
  lv_obj_set_size(card, 248, 166);
  styleBox(card, C_HEADER, 14);
  lv_obj_set_style_border_color(card, col(C_BORDER), LV_PART_MAIN);
  noScroll(card);

  lv_obj_t* accent = lv_obj_create(card);
  lv_obj_set_pos(accent, 32, 8);
  lv_obj_set_size(accent, 184, 2);
  lv_obj_set_style_bg_color(accent, col(C_CYAN), LV_PART_MAIN);
  lv_obj_set_style_bg_opa(accent, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_border_width(accent, 0, LV_PART_MAIN);
  lv_obj_set_style_radius(accent, 1, LV_PART_MAIN);
  noScroll(accent);

  lv_obj_t* a = label(card, "AM2", 0, 25, &lv_font_montserrat_28, C_CYAN);
  setLabelBox(a, 248, 38, LV_TEXT_ALIGN_CENTER);
  lv_obj_t* b = label(card, "CONTROL SYSTEM", 0, 70, &lv_font_montserrat_14, C_TEXT);
  setLabelBox(b, 248, 22, LV_TEXT_ALIGN_CENTER);
  lv_obj_t* c = label(card, "AM2-444051", 0, 101, &lv_font_montserrat_12, C_CYAN);
  setLabelBox(c, 248, 20, LV_TEXT_ALIGN_CENTER);
  splashStatus = label(card, "INITIALIZING SYSTEM...", 0, 136, &lv_font_montserrat_10, C_MUTED);
  setLabelBox(splashStatus, 248, 16, LV_TEXT_ALIGN_CENTER);

  lv_scr_load(splash);
  bootMs = millis();
}

void refreshHome() {
  char b[48];
  const int16_t temps[4] = {snap.returnTemp10, snap.supplyTemp10, snap.suctionTemp10, snap.dischargeTemp10};
  for (int i = 0; i < 4; ++i) {
    formatTemp(b, sizeof(b), temps[i]);
    setText(homeTemps[i], b);
  }

  setText(homeStatus, statusText(snap.compStatus));
  lv_obj_set_style_text_color(homeStatus, col(statusColor(snap.compStatus)), LV_PART_MAIN);

  if (snap.mode == 0) {
    std::snprintf(b, sizeof(b), "COMP: %s", snap.compFeedback ? "RUNNING" : "STOPPED");
    setText(homeRun, b);
    lv_obj_set_style_text_color(homeRun, col(snap.compFeedback ? C_GREEN : C_MUTED), LV_PART_MAIN);
  } else {
    std::snprintf(b, sizeof(b), "RUN RELAY: %s", snap.runRelayOn ? "ON" : "OFF");
    setText(homeRun, b);
    lv_obj_set_style_text_color(homeRun, col(snap.runRelayOn ? C_GREEN : C_MUTED), LV_PART_MAIN);
  }

  std::snprintf(b, sizeof(b), "%d C", snap.returnSp);
  setText(homeSp, b);
  setText(homeMode, snap.mode ? "CONTROL" : "MONITOR");

  if (snap.mode == 0) {
    // MONITOR mode mirrors the mobile app: observation/protection only.
    lv_obj_add_flag(startStopBtn, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(homeSpTitle, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(homeSp, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(monitorOnlyLabel, LV_OBJ_FLAG_HIDDEN);
  } else {
    lv_obj_clear_flag(startStopBtn, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(homeSpTitle, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(homeSp, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(monitorOnlyLabel, LV_OBJ_FLAG_HIDDEN);
    const bool stopAction = snap.runRelayOn || snap.compStatus == 1 || snap.compStatus == 2 || snap.compStatus == 4;
    setText(startStopLabel, stopAction ? "STOP SYSTEM" : "START SYSTEM");
    lv_obj_set_style_border_color(startStopBtn, col(stopAction ? C_RED : C_GREEN), LV_PART_MAIN);
  }
}

void refreshControl() {
  char b[24];
  const int values[4] = {snap.returnSp, snap.returnAlertSp, snap.suctionAlertSp, snap.dischargeAlertSp};
  for (int i = 0; i < 4; ++i) {
    std::snprintf(b, sizeof(b), "%d C", values[i]);
    setText(controlValues[i], b);
  }
}

void refreshSafety() {
  char b[32];
  const int p[3] = {snap.suctionPressure, snap.dischargePressure, snap.oilPressure};
  const int a[3] = {snap.amp1, snap.amp2, snap.amp3};
  for (int i = 0; i < 3; ++i) {
    formatIntOrDash(b, sizeof(b), p[i]);
    setText(safetyPressure[i], b);
    formatIntOrDash(b, sizeof(b), a[i], " A");
    setText(safetyAmps[i], b);
  }

  const bool trips[3] = {snap.lpsActive, snap.hpsActive, snap.opsActive};
  const char* names[3] = {"LPS", "HPS", "OPS"};
  for (int i = 0; i < 3; ++i) {
    std::snprintf(b, sizeof(b), "%s %s", names[i], trips[i] ? "TRIP" : "OK");
    setText(safetySwitches[i], b);
    lv_obj_set_style_text_color(safetySwitches[i], col(trips[i] ? C_RED : C_GREEN), LV_PART_MAIN);
  }

  std::snprintf(b, sizeof(b), "COMP %s", snap.compFeedback ? "RUN" : "STOP");
  setText(safetySwitches[3], b);
  lv_obj_set_style_text_color(safetySwitches[3], col(snap.compFeedback ? C_GREEN : C_MUTED), LV_PART_MAIN);
}

void refreshSensors() {
  char b[48];
  std::snprintf(b, sizeof(b), "%u / 4", snap.sensorCount);
  setText(sensorCount, b);

  for (int i = 0; i < 4; ++i) {
    if (i < snap.sensorCount) {
      shortAddress(b, sizeof(b), snap.sensorAddress[i]);
      setText(sensorAddr[i], b);
      formatTemp(b, sizeof(b), snap.rawSensorTemp10[i]);
      setText(sensorTemp[i], b);
      setText(sensorRoleLabel[i], roleText(snap.sensorRole[i]));
      lv_obj_clear_state(sensorRoleBtn[i], LV_STATE_DISABLED);
    } else {
      setText(sensorAddr[i], "--");
      setText(sensorTemp[i], "--.- C");
      setText(sensorRoleLabel[i], "NONE");
      lv_obj_add_state(sensorRoleBtn[i], LV_STATE_DISABLED);
    }
  }
}

void refreshSettings() {
  char b[32];
  const char* onoff[2] = {"OFF", "ON"};
  setText(setupValue[0], snap.mode ? "CONTROL" : "MONITOR");
  setText(setupValue[1], onoff[snap.autoReset ? 1 : 0]);
  setText(setupValue[2], onoff[snap.ctEnable ? 1 : 0]);
  setText(setupValue[3], onoff[snap.suctionPressureEnable ? 1 : 0]);
  setText(setupValue[4], onoff[snap.dischargePressureEnable ? 1 : 0]);
  setText(setupValue[5], onoff[snap.oilPressureEnable ? 1 : 0]);
  setText(setupValue[6], onoff[snap.lpsEnable ? 1 : 0]);
  setText(setupValue[7], onoff[snap.hpsEnable ? 1 : 0]);
  setText(setupValue[8], onoff[snap.opsEnable ? 1 : 0]);
  std::snprintf(b, sizeof(b), "%d s", snap.restartDelay); setText(setupValue[9], b);
  std::snprintf(b, sizeof(b), "%d psi", snap.suctionPsiSp); setText(setupValue[10], b);
  std::snprintf(b, sizeof(b), "%d psi", snap.dischargePsiSp); setText(setupValue[11], b);
  std::snprintf(b, sizeof(b), "%d psi", snap.oilPsiSp); setText(setupValue[12], b);
  std::snprintf(b, sizeof(b), "%d A", snap.ampsLimit); setText(setupValue[13], b);
}

void refreshActivePage() {
  am2UiGetSnapshot(snap);
  setText(headerId, snap.deviceId);

  switch (activePage) {
    case 0: refreshHome(); break;
    case 1: refreshControl(); break;
    case 2: refreshSafety(); break;
    case 3: refreshSensors(); break;
    case 4: refreshSettings(); break;
    default: break;
  }
}

void flushCb(lv_disp_drv_t* d, const lv_area_t* a, lv_color_t* p) {
  const uint32_t w = a->x2 - a->x1 + 1;
  const uint32_t h = a->y2 - a->y1 + 1;
  tft.startWrite();
  tft.setAddrWindow(a->x1, a->y1, w, h);
  tft.pushColors(reinterpret_cast<uint16_t*>(&p->full), w * h, true);
  tft.endWrite();
  lv_disp_flush_ready(d);
}

void touchCb(lv_indev_drv_t*, lv_indev_data_t* data) {
  uint16_t x = 0;
  uint16_t y = 0;
  if (touchDetected && touch.read(x, y)) {
    lastPoint.x = x;
    lastPoint.y = y;
    data->state = LV_INDEV_STATE_PR;
  } else {
    data->state = LV_INDEV_STATE_REL;
  }
  data->point = lastPoint;
}

bool allocateDrawBuffer() {
  const uint16_t attempts[] = {DRAW_ROWS_PREFERRED, 12, 8, 4};
  for (uint16_t rows : attempts) {
    drawPixels = static_cast<lv_color_t*>(
        heap_caps_malloc(AM2_SCREEN_W * rows * sizeof(lv_color_t), MALLOC_CAP_8BIT));
    if (drawPixels) {
      lv_disp_draw_buf_init(&drawBuf, drawPixels, nullptr, AM2_SCREEN_W * rows);
      Serial.printf("[UI] LVGL draw buffer: %u rows (%u bytes)\n",
                    rows, static_cast<unsigned>(AM2_SCREEN_W * rows * sizeof(lv_color_t)));
      return true;
    }
  }
  return false;
}


} // namespace

bool uiBegin() {
  pinMode(AM2_TFT_BL_PIN, OUTPUT);
  digitalWrite(AM2_TFT_BL_PIN, LOW);

  tft.begin();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);

  touchDetected = touch.begin();
  lv_init();
  if (!allocateDrawBuffer()) return false;

  lv_disp_drv_init(&dispDrv);
  dispDrv.hor_res = AM2_SCREEN_W;
  dispDrv.ver_res = AM2_SCREEN_H;
  dispDrv.flush_cb = flushCb;
  dispDrv.draw_buf = &drawBuf;
  lv_disp_drv_register(&dispDrv);

  lv_indev_drv_init(&indevDrv);
  indevDrv.type = LV_INDEV_TYPE_POINTER;
  indevDrv.read_cb = touchCb;
  lv_indev_drv_register(&indevDrv);

  buildSplash();
  lastTickMs = millis();
  digitalWrite(AM2_TFT_BL_PIN, HIGH);

  // Same execution model as the user's proven WT_COOLING_CYD project:
  // LVGL and CST820 are serviced from the Arduino application task only.
  // This avoids cross-core LVGL access and keeps touch deterministic.
  lv_timer_handler();
  lastHandlerMs = millis();
  lv_refr_now(nullptr);
  return true;
}

void uiSetSystemReady() {
  systemReady = true;
  forceRefresh = true;
}

void uiService() {
  static uint32_t lastRefresh = 0;
  if (!splash && !mainScreen) return;

  const uint32_t now = millis();
  if (lastTickMs == 0) lastTickMs = now;
  const uint32_t elapsed = now - lastTickMs;
  if (elapsed > 0) {
    lv_tick_inc(elapsed);
    lastTickMs = now;
  }

  if (!mainBuilt && systemReady && now - bootMs >= SPLASH_MIN_MS) {
    setText(splashStatus, "SYSTEM READY");
    buildMain();
    forceRefresh = true;
  }

  if (mainBuilt && (forceRefresh || now - lastRefresh >= UI_MODEL_REFRESH_MS)) {
    refreshActivePage();
    forceRefresh = false;
    lastRefresh = now;
  }

  // uiDelay() may call uiService() every 1 ms while hardware waits are in progress.
  // Running LVGL/touch I2C at that rate can overload the CST820 bus and makes touch
  // feel erratic. Keep the UI service fast but bounded; LVGL input itself is 20 ms.
  if (lastHandlerMs == 0 || now - lastHandlerMs >= UI_HANDLER_MIN_MS) {
    lv_timer_handler();
    lastHandlerMs = now;
  }
}

void uiDelay(uint32_t durationMs) {
  const uint32_t start = millis();
  while (millis() - start < durationMs) {
    uiService();
    delay(1);
  }
}
