#include "CST820Touch.h"

namespace {
// Exact landscape transform used by the supplied WT_COOLING_CYD reference.
constexpr bool TOUCH_SWAP_XY = true;
constexpr bool TOUCH_INVERT_X = false;
constexpr bool TOUCH_INVERT_Y = true;
}

bool CST820Touch::writeReg(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(static_cast<uint8_t>(AM2_TOUCH_ADDR));
  Wire.write(reg);
  Wire.write(value);
  return Wire.endTransmission(true) == 0;
}

bool CST820Touch::readRegs(uint8_t reg, uint8_t* data, size_t len) {
  Wire.beginTransmission(static_cast<uint8_t>(AM2_TOUCH_ADDR));
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;

  const uint8_t got = Wire.requestFrom(static_cast<uint8_t>(AM2_TOUCH_ADDR),
                                       static_cast<uint8_t>(len),
                                       static_cast<uint8_t>(true));
  if (got != len) {
    while (Wire.available()) (void)Wire.read();
    return false;
  }

  for (size_t i = 0; i < len; ++i) data[i] = static_cast<uint8_t>(Wire.read());
  return true;
}

bool CST820Touch::begin() {
  // Same reset and bus initialization as the user's proven WT_COOLING_CYD project.
  pinMode(AM2_TOUCH_RST, OUTPUT);
  digitalWrite(AM2_TOUCH_RST, HIGH);
  delay(5);
  digitalWrite(AM2_TOUCH_RST, LOW);
  delay(10);
  digitalWrite(AM2_TOUCH_RST, HIGH);
  delay(60);

  Wire.begin(AM2_TOUCH_SDA, AM2_TOUCH_SCL, 400000);
  Wire.setTimeOut(20);
  Wire.beginTransmission(static_cast<uint8_t>(AM2_TOUCH_ADDR));
  detected_ = (Wire.endTransmission() == 0);

  Serial.printf("[TOUCH] CST controller at 0x%02X: %s\n",
                AM2_TOUCH_ADDR, detected_ ? "detected" : "not detected");
  if (detected_) {
    uint8_t chipId = 0;
    if (readRegs(0xA7, &chipId, 1)) {
      Serial.printf("[TOUCH] Chip ID: 0x%02X%s\n",
                    chipId, chipId == 0xB7 ? " (CST820)" : "");
    }
    // WT reference polls I2C instead of using INT, so keep CST820 awake.
    (void)writeReg(0xFE, 0xFF);
  }
  return detected_;
}

bool CST820Touch::readRaw(uint16_t& rawX, uint16_t& rawY) {
  if (!detected_) return false;

  uint8_t data[5] = {0};
  if (!readRegs(0x02, data, sizeof(data))) return false;
  if ((data[0] & 0x0F) == 0) return false;

  rawX = static_cast<uint16_t>(((data[1] & 0x0F) << 8) | data[2]);
  rawY = static_cast<uint16_t>(((data[3] & 0x0F) << 8) | data[4]);
  return true;
}

bool CST820Touch::read(uint16_t& x, uint16_t& y) {
  uint16_t rawX = 0;
  uint16_t rawY = 0;
  if (!readRaw(rawX, rawY)) return false;

  int32_t tx = rawX;
  int32_t ty = rawY;

  if (TOUCH_SWAP_XY) {
    const int32_t t = tx;
    tx = ty;
    ty = t;
  }

  const int32_t maxX = TOUCH_SWAP_XY ? 319 : 239;
  const int32_t maxY = TOUCH_SWAP_XY ? 239 : 319;

  if (TOUCH_INVERT_X) tx = maxX - tx;
  if (TOUCH_INVERT_Y) ty = maxY - ty;

  tx = constrain(tx, 0, static_cast<int32_t>(AM2_SCREEN_W) - 1);
  ty = constrain(ty, 0, static_cast<int32_t>(AM2_SCREEN_H) - 1);

  x = static_cast<uint16_t>(tx);
  y = static_cast<uint16_t>(ty);
  return true;
}
