#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]

def txt(rel):
    return (ROOT / rel).read_text(errors='ignore')

def func_section(text, name):
    m = re.search(r'void\s+' + re.escape(name) + r'\s*\([^)]*\)\s*\{', text)
    if not m:
        return ''
    start = m.start()
    depth = 0
    seen = False
    for i in range(m.end()-1, len(text)):
        if text[i] == '{':
            depth += 1; seen = True
        elif text[i] == '}':
            depth -= 1
            if seen and depth == 0:
                return text[start:i+1]
    return text[start:]

def json_keys(section, var):
    return re.findall(rf'{re.escape(var)}\["([^"]+)"\]\s*=', section)

mqtt = txt('include/MQTT.h')
defh = txt('include/Def.h')
main = txt('src/main.cpp')
cfg = txt('include/BoardConfig.h')
io = txt('include/IO.h')
ui = txt('src/UI.cpp')
runtime = '\n'.join((p.read_text(errors='ignore') for p in list((ROOT/'include').glob('*.h')) + list((ROOT/'src').glob('*.cpp'))))

expected_main = [
 'value0','value8','value9','value1','value2','value3','value4','value1F','value2F','value3F','value4F',
 'value5','value6','value7','value5F','value6F','value7F','value23','value13','value10','value21','value17',
 'value15','value25','value27','value30','value31','value32','value33','mac_address','ip_address'
]
expected_pressure = [
 'ftoC','psiTobar','returnTempSelection','restartdelay','sucpressure','dispressure','oilpressure','oilsw',
 'suctionsw','dischargesw','autoSwitch','mode','currentsw','pressure_type','pressure_unit','pressure_range',
 'pressure_type2','pressure_unit2','pressure_range2','pressure_type3','pressure_unit3','pressure_range3'
]
main_keys = json_keys(func_section(mqtt,'publishJson'),'doc')
pressure_keys = json_keys(func_section(mqtt,'publish_pressure_selection'),'json_doc')

def check(name, ok):
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
    return bool(ok)

checks = []
checks += [check('Main JSON has original 31 keys/order', main_keys == expected_main)]
checks += [check('Pressure JSON has original 22 keys/order', pressure_keys == expected_pressure)]
checks += [check('Exactly three MQTT publish calls', len(re.findall(r'\bclient\.publish\s*\(', runtime)) == 3)]
checks += [check('Main topic present', 'client.publish(device_topic_p.c_str()' in mqtt)]
checks += [check('Temperature config topic present', '/temperature_config_AM2-444' in mqtt)]
checks += [check('Pressure config topic restored', 'device_topic_pressure_config' in defh and '/pressure_config' in defh and 'client.publish(device_topic_pressure_config.c_str()' in mqtt)]
checks += [check('Incoming /1 /2 /3 topics present', all(f'device_topic_s_{i}' in defh for i in (1,2,3)))]
checks += [check('Old receive-flag publish suppression removed', '!message_received && !message_received_config' not in main)]
checks += [check('Dirty state sync exists', 'mqttStateDirty = true;' in mqtt and 'mqttStateDirty = true;' in main and '(mqttStateDirty || mqttPeriodicDue)' in main)]
checks += [check('MQTT callback serviced before publish decision', main.find('client.loop();', main.find('// MQTT/app/display synchronization')) < main.find('publishJson();', main.find('// MQTT/app/display synchronization')))]
checks += [check('All three JSONs published together', all(x in main for x in ['publishJson();','temp_sensor_select_publish();','publish_pressure_selection();']))]
checks += [check('BECA control not restored', all(x not in runtime for x in ['BECA_SLAVE_ID','scanBeca','beca_Status','thermostat_selection']))]
checks += [check('returnTempSelection compatibility field fixed to 0', 'json_doc["returnTempSelection"] = 0;' in mqtt)]
checks += [check('Sensor 4 remains Return role', 'json_doc[addressString] = 4;  // Return' in mqtt)]
checks += [check('All four sensors remain GPIO4 OneWire', '#define AM2_ONEWIRE_PIN 4' in cfg)]
checks += [check('RS485 remains RX16/TX17', '#define AM2_RS485_RX_PIN 16' in cfg and '#define AM2_RS485_TX_PIN 17' in cfg)]
checks += [check('PCF mapping P2/P3 relays, P4-P7 safety/feedback', all(x in cfg for x in [
 '#define AM2_PCF_RUN_RELAY_BIT 2','#define AM2_PCF_ALARM_RELAY_BIT 3','#define AM2_PCF_HPS_BIT 4',
 '#define AM2_PCF_LPS_BIT 5','#define AM2_PCF_OPS_BIT 6','#define AM2_PCF_COMP_FB_BIT 7']))]
checks += [check('RELAY_ACTIVE_LOW remains false', '#define RELAY_ACTIVE_LOW false' in cfg)]
checks += [check('Relay levels derived from RELAY_ACTIVE_LOW', 'AM2_RELAY_ON_LEVEL  (RELAY_ACTIVE_LOW ? LOW : HIGH)' in cfg and 'AM2_RELAY_OFF_LEVEL (RELAY_ACTIVE_LOW ? HIGH : LOW)' in cfg)]
checks += [check('Monitor compressor feedback inversion retained', 'comp_Status = (bitRead(inputs, COMP_PIN) == LOW) ? RUNNING : STOPPED;' in main)]
checks += [check('Monitor UI has no START/STOP control', 'lv_obj_add_flag(startStopBtn, LV_OBJ_FLAG_HIDDEN);' in ui)]
checks += [check('Pressure ftoC/psiTobar writes occur inside Preferences session', mqtt.find('preferences.begin("values", false);', mqtt.find('void Extract_pressure_config')) < mqtt.find('update_values_from_json("ftoC"', mqtt.find('void Extract_pressure_config')))]
checks += [check('ftoC/psiTobar restored from NVS after reboot', 'ftoC = preferences.getInt("ftoC", 1);' in mqtt and 'psiTobar = preferences.getInt("psiTobar", 1);' in mqtt)]

passed=sum(checks)
print(f'\nChecks: {passed}/{len(checks)} passed')
sys.exit(0 if passed == len(checks) else 1)
