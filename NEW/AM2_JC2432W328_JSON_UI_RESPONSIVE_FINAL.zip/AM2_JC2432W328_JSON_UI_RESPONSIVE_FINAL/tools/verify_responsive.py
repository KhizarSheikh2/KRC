from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
ui=(root/'src/UI.cpp').read_text()
main=(root/'src/main.cpp').read_text()
mq=(root/'include/MQTT.h').read_text()
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
ck('nav changes on touch-down', 'lv_obj_add_event_cb(nav[i], navEvent, LV_EVENT_PRESSED' in ui)
ck('LVGL service bounded', 'UI_HANDLER_MIN_MS = 5' in ui)
ck('nonblocking CT service enabled', 'serviceAmpReader();' in main and 'readHoldingRegisters(' not in main)
ck('staged MQTT publish enabled', 'serviceMqttPublishCycle();' in main)
ck('cached sensor temp publish', 'temperature_read = detectedSensorTemps[i];' in mq)
# Main JSON schema
p0=mq.index('void publishJson()')
p1=mq.index('void update_values_from_json',p0)
mainkeys=re.findall(r'doc\["([^"]+)"\]',mq[p0:p1])
ck('main JSON has 31 fields', len(mainkeys)==31)
# pressure config schema
p0=mq.index('void publish_pressure_selection()')
p1=mq.index('void temp_sensor_select_publish()',p0)
presskeys=re.findall(r'json_doc\["([^"]+)"\]',mq[p0:p1])
ck('pressure JSON has 22 fields', len(presskeys)==22)
ck('all 3 outgoing publishers present', all(x in main+mq for x in ['publishJson();','temp_sensor_select_publish();','publish_pressure_selection();']))
failed=[n for n,v in checks if not v]
for n,v in checks: print(('PASS' if v else 'FAIL'), '-', n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
