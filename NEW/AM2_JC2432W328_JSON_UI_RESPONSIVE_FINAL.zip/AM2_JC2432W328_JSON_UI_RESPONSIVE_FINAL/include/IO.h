#pragma once

// Logical AM2 safety/feedback names mapped to the user's actual PCF8574 PCB.
// The original AM2 alarm logic remains ACTIVE-HIGH at the logical input level.
#define LOW_PRE  AM2_PCF_LPS_BIT
#define HIGH_PRE AM2_PCF_HPS_BIT
#define OIL_SW   AM2_PCF_OPS_BIT
#define COMP_PIN AM2_PCF_COMP_FB_BIT

// User's actual PCF8574 wiring:
// P0 START, P1 STOP, P2 RUN relay, P3 ALARM relay,
// P4 HPS, P5 LPS, P6 OPS, P7 compressor feedback.
extern TwoWire AM2Wire;

uint8_t pcfOutputLatch = 0xFF; // final boot-safe relay levels are applied in initInputs().
bool runRelayState = false;
bool alarmRelayState = false;
bool previousStartPressed = false;
bool previousStopPressed = false;
bool pcfCommFault = false;
unsigned long pcfReadErrorCount = 0;
unsigned long pcfWriteErrorCount = 0;

bool initialize_PCF8574(const uint16_t addresses[], int count) {
  for (int i = 0; i < count; i++) {
    AM2Wire.beginTransmission(addresses[i]);
    if (AM2Wire.endTransmission() == 0) return true;
  }
  return false;
}

bool writePCF8574Latch() {
  AM2Wire.beginTransmission(AM2_PCF8574_ADDR);
  AM2Wire.write(pcfOutputLatch);
  const uint8_t err = AM2Wire.endTransmission();
  if (err != 0) {
    pcfCommFault = true;
    ++pcfWriteErrorCount;
    return false;
  }
  return true;
}

bool setPcfBitLevel(uint8_t bit, uint8_t level) {
  const uint8_t previousLatch = pcfOutputLatch;
  if (level) bitSet(pcfOutputLatch, bit);
  else bitClear(pcfOutputLatch, bit);
  if (!writePCF8574Latch()) {
    // Keep the software latch aligned with the last value known to have been written.
    pcfOutputLatch = previousLatch;
    return false;
  }
  return true;
}

void setRunRelay(bool on) {
  const uint8_t level = on ? AM2_RELAY_ON_LEVEL : AM2_RELAY_OFF_LEVEL;
  if (setPcfBitLevel(AM2_PCF_RUN_RELAY_BIT, level)) runRelayState = on;
}

void setAlarmRelay(bool on) {
  const uint8_t level = on ? AM2_RELAY_ON_LEVEL : AM2_RELAY_OFF_LEVEL;
  if (setPcfBitLevel(AM2_PCF_ALARM_RELAY_BIT, level)) alarmRelayState = on;
}

void initInputs() {
  if (!AM2Wire.begin(AM2_HW_I2C_SDA, AM2_HW_I2C_SCL, AM2_HW_I2C_HZ)) {
    Serial.println("I2C Bus Initialization Failed!");
    return;
  }
  // Keep a missing/noisy PCF8574 from blocking the UI/control loop for long periods.
  AM2Wire.setTimeOut(20);
  Serial.println("I2C Bus Initialized Successfully!");

  uint16_t addresses[] = { AM2_PCF8574_ADDR };
  if (!initialize_PCF8574(addresses, 1)) {
    Serial.println("IO PCF8574 Initialization Failed!");
    return;
  }
  Serial.println("IO PCF8574 Initialized Successfully!");

  // PCF8574 input pins must be written HIGH so they remain released as inputs.
  // P2/P3 are explicitly forced to the relay OFF level. With RELAY_ACTIVE_LOW=false
  // this produces 0xF3: P0/P1/P4..P7 HIGH, P2/P3 LOW.
  pcfOutputLatch = 0xFF;
  bitWrite(pcfOutputLatch, AM2_PCF_RUN_RELAY_BIT, AM2_RELAY_OFF_LEVEL);
  bitWrite(pcfOutputLatch, AM2_PCF_ALARM_RELAY_BIT, AM2_RELAY_OFF_LEVEL);
  if (!writePCF8574Latch()) {
    Serial.println("IO PCF8574 safe-state write failed!");
    return;
  }
  runRelayState = false;
  alarmRelayState = false;
  pcfCommFault = false;
}

uint8_t pcfFailSafeReadValue() {
  // Never turn a communication failure into a false HEALTHY reading:
  // P0/P1 HIGH = no START/STOP press; P4..P7 HIGH = safety fault/no compressor feedback.
  // Preserve the currently commanded P2/P3 output bits for diagnostics.
  return static_cast<uint8_t>((pcfOutputLatch & 0x0C) | 0xF3);
}

uint8_t readInputs(uint16_t Address) {
  const uint8_t received = AM2Wire.requestFrom(static_cast<uint8_t>(Address), static_cast<uint8_t>(1));
  if (received == 1 && AM2Wire.available()) {
    const uint8_t data = AM2Wire.read();
    pcfCommFault = false;
    return data;
  }

  while (AM2Wire.available()) (void)AM2Wire.read();
  pcfCommFault = true;
  ++pcfReadErrorCount;
  return pcfFailSafeReadValue();
}

// START/STOP were direct GPIO interrupts on the old ESP32. On the JC2432W328
// they are P0/P1 of the same PCF8574. We edge-detect them and feed the exact
// original startSW/stopSW flags, so the machine-control logic below is unchanged.
void pollStartStopSwitches() {
  const uint8_t now = readInputs(AM2_PCF8574_ADDR);
  if (pcfCommFault) {
    // A failed PCF read must never create a phantom START or STOP edge.
    previousStartPressed = false;
    previousStopPressed = false;
    return;
  }

  const bool startPressed = (bitRead(now, AM2_PCF_START_BIT) == 0);
  const bool stopPressed  = (bitRead(now, AM2_PCF_STOP_BIT) == 0);

  if (startPressed && !previousStartPressed) startSW = 1;
  if (stopPressed && !previousStopPressed) stopSW = 1;

  previousStartPressed = startPressed;
  previousStopPressed = stopPressed;
}
