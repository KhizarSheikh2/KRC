#pragma once

// Original AM2 MQTT/app contract restored with all three outgoing JSONs.
// BECA thermostat control remains removed. The pressure_config JSON keeps
// returnTempSelection=0 only for mobile-app schema compatibility.
//
// Published:
//   /KRC/AM2-444051
//   /KRC/AM2-444051/temperature_config_AM2-444
//   /KRC/AM2-444051/pressure_config
// Incoming app commands remain /test/AM2-444051/1, /2 and /3.

void publishJson() {
  // Serial.println("JSON message publishing");
  StaticJsonDocument<2048> doc;

  doc["value0"] = String(AMP1);
  doc["value8"] = String(AMP2);
  doc["value9"] = String(AMP3);

  doc["value1"] = String(ReturnTempC, 1);
  doc["value2"] = String(SupplyTempC, 1);
  doc["value3"] = String(SuctionTempC, 1);
  doc["value4"] = String(dischargeTempC, 1);

  doc["value1F"] = String(ReturnTemp);
  doc["value2F"] = String(SupplyTemp);
  doc["value3F"] = String(SuctionTemp);
  doc["value4F"] = String(dischargeTemp);

  doc["value5"] = String(suctionPressure);
  doc["value6"] = String(dischargePressure);
  doc["value7"] = String(OilPressure);

  doc["value5F"] = String(suctionPressureB);
  doc["value6F"] = String(dischargePressureB);
  doc["value7F"] = String(OilPressureB);

  doc["value23"] = String(suctionAlertSp);
  doc["value13"] = String(dischargeAlertSp);
  doc["value10"] = String(ReturnAlertSp);
  doc["value21"] = String(ReturnSp);

  doc["value17"] = String(amps_limit);
  doc["value15"] = String(dischargePsiSp);
  doc["value25"] = String(suctionPsiSp);
  doc["value27"] = String(oilPsiSp);

  doc["value30"] = String(comp_Status);

  doc["value31"] = LPS;
  doc["value32"] = HPS;
  doc["value33"] = OPS;

  doc["mac_address"] = macaddress;
  doc["ip_address"] = myIP;

  char jsonBuffer[2048];
  size_t n = serializeJson(doc, jsonBuffer);
  client.publish(device_topic_p.c_str(), jsonBuffer, true);
}

void update_values_from_json(String key, int& value_variable) {
  if (received_doc.containsKey(key)) {
    if (received_doc[key].as<int>() != value_variable) {
      value_variable = received_doc[key].as<int>();
      preferences.putInt(key.c_str(), value_variable);
    }
  }
}

void Extract_by_json(String incomingMessage) {
  DeserializationError error = deserializeJson(received_doc, incomingMessage);
  if (error) {
    Serial.print("JSON deserialization failed: ");
    Serial.println(error.c_str());
    return;
  }
  // Serial.println(incomingMessage);

  preferences.begin("values", false);
  update_values_from_json("temp1set_LOW", ReturnAlertSp);     // RETURN ALERT
  update_values_from_json("temp4set_LOW", dischargeAlertSp);  // DISCHARGE
  update_values_from_json("temp1set_HIGH", ReturnSp);         // RETURN SP
  update_values_from_json("temp3set_HIGH", suctionAlertSp);   // SUCTION TEMP
  update_values_from_json("psig2set_LOW", dischargePsiSp);    // DISCHARGE
  update_values_from_json("psig1set_HIGH", suctionPsiSp);     // SUCTION
  update_values_from_json("psig3set_HIGH", oilPsiSp);         // OIL
  update_values_from_json("AMP1_LOW", amps_limit);            // CURRENT SETTING FROM APP

  preferences.end();

  message_received = true;
  mqttStateDirty = true;
}

void Extract_pressure_config(String incoming_message) {
  DeserializationError error = deserializeJson(received_doc, incoming_message);
  if (error) {
    Serial.print("JSON deserialization failed: ");
    Serial.println(error.c_str());
    return;
  }

  preferences.begin("values", false);
  update_values_from_json("ftoC", ftoC);
  update_values_from_json("psiTobar", psiTobar);
  update_values_from_json("currentsw", CTmodulesw);
  update_values_from_json("mode", modesw);
  update_values_from_json("autoSwitch", autoReset);

  update_values_from_json("sucpressure", sucpressuresw);
  update_values_from_json("dispressure", dispressuresw);
  update_values_from_json("oilpressure", oilpressuresw);
  update_values_from_json("oilsw", OPS_SW);
  update_values_from_json("suctionsw", LPS_SW);
  update_values_from_json("dischargesw", HPS_SW);

  update_values_from_json("restartdelay", Comp_restart_delay);
  Comp_restart_delay_ms = Comp_restart_delay * 1000;


  update_values_from_json("pressure_type", pressure_output_signal_type);
  update_values_from_json("pressure_unit", pressure_unit_selection);
  update_values_from_json("pressure_range", pressure_range);

  update_values_from_json("pressure_type2", pressure_output_signal_type2);
  update_values_from_json("pressure_unit2", pressure_unit_selection2);
  update_values_from_json("pressure_range2", pressure_range2);

  update_values_from_json("pressure_type3", pressure_output_signal_type3);  // 0-5v = 1 , 4-20mA = 2
  update_values_from_json("pressure_unit3", pressure_unit_selection3);      // bar = 0 , PSI = 1
  update_values_from_json("pressure_range3", pressure_range3);
  preferences.end();

  if (pressure_unit_selection) {          // psi
    sensorMax = pressure_range;           // max 0-725psi
  } else {                                // bar
    float range = pressure_range * 14.7;  // max 0-50 bar
    sensorMax = (int)range;
  }

  if (pressure_unit_selection2) {          // psi
    sensorMax2 = pressure_range2;          // max 0-725psi
  } else {                                 // bar
    float range = pressure_range2 * 14.7;  // max 0-50 bar
    sensorMax2 = (int)range;
  }

  if (pressure_unit_selection3) {          // psi
    sensorMax3 = pressure_range3;          // max 0-725psi
  } else {                                 // bar
    float range = pressure_range3 * 14.7;  // max 0-50 bar
    sensorMax3 = (int)range;
  }

  mqttStateDirty = true;
}


void publish_pressure_selection() {
  // Original AM2 pressure/system configuration JSON.
  // BECA is removed, so Return always comes from DS18B20 role 4 and the
  // legacy returnTempSelection field is fixed at 0 for app compatibility.
  StaticJsonDocument<768> json_doc;

  json_doc["ftoC"] = ftoC;
  json_doc["psiTobar"] = psiTobar;
  json_doc["returnTempSelection"] = 0;
  json_doc["restartdelay"] = Comp_restart_delay;
  json_doc["sucpressure"] = sucpressuresw;
  json_doc["dispressure"] = dispressuresw;
  json_doc["oilpressure"] = oilpressuresw;
  json_doc["oilsw"] = OPS_SW;
  json_doc["suctionsw"] = LPS_SW;
  json_doc["dischargesw"] = HPS_SW;
  json_doc["autoSwitch"] = autoReset;
  json_doc["mode"] = modesw;
  json_doc["currentsw"] = CTmodulesw;

  json_doc["pressure_type"] = pressure_output_signal_type;
  json_doc["pressure_unit"] = pressure_unit_selection;
  json_doc["pressure_range"] = pressure_range;
  json_doc["pressure_type2"] = pressure_output_signal_type2;
  json_doc["pressure_unit2"] = pressure_unit_selection2;
  json_doc["pressure_range2"] = pressure_range2;
  json_doc["pressure_type3"] = pressure_output_signal_type3;
  json_doc["pressure_unit3"] = pressure_unit_selection3;
  json_doc["pressure_range3"] = pressure_range3;

  char doc[768];
  const size_t n = serializeJson(json_doc, doc, sizeof(doc));
  if (n == 0 || n >= sizeof(doc)) {
    Serial.println("[MQTT] pressure_config serialization failed");
    return;
  }
  client.publish(device_topic_pressure_config.c_str(), doc, true);
}

void temp_sensor_select_publish() {
  // Publish the already sampled temperatures. Do not start four additional
  // 1-Wire conversions during an MQTT burst; this keeps app sync lightweight
  // and ensures the app sees the same sample currently shown on the TFT.
  StaticJsonDocument<1024> json_doc;

  float temperature_read;
  String addressString;

  for (int i = 0; i < numberOfDevices; i++) {
    temperature_read = detectedSensorTemps[i];
    if (temperature_read < -100.0f || temperature_read >= 887.0f) temperature_read = SENSOR_DISCONNECTED;
    addressString = getAddressString(tempSensorAddresses[i]);
    switch (i) {
      case 0:
        json_doc["address1"] = addressString;
        json_doc["temp1"] = temperature_read;
        break;
      case 1:
        json_doc["address2"] = addressString;
        json_doc["temp2"] = temperature_read;
        break;
      case 2:
        json_doc["address3"] = addressString;
        json_doc["temp3"] = temperature_read;
        break;
      case 3:
        json_doc["address4"] = addressString;
        json_doc["temp4"] = temperature_read;
        break;
      default:
        break;
    }
    json_doc[addressString] = 0;
    if (temp1Assigned && compareAddresses(tempSensorAddresses[i], temp1Address)) {
      json_doc[addressString] = 1;  // Suction
    }
    if (temp2Assigned && compareAddresses(tempSensorAddresses[i], temp2Address)) {
      json_doc[addressString] = 2;  // Discharge
    }
    if (temp3Assigned && compareAddresses(tempSensorAddresses[i], temp3Address)) {
      json_doc[addressString] = 3;  // Supply
    }
    if (temp4Assigned && compareAddresses(tempSensorAddresses[i], temp4Address)) {
      json_doc[addressString] = 4;  // Return
    }
  }
  // json_doc["offset1"] = discharge_temp_offset;
  // json_doc["offset2"] = supply_temp_offset;
  // json_doc["offset3"] = return_air_temp_offset;

  json_doc["offset1"] = offset1;
  json_doc["offset2"] = offset2;
  json_doc["offset3"] = offset3;
  json_doc["offset4"] = offset4;

  char doc[768];
  const size_t n = serializeJson(json_doc, doc, sizeof(doc));
  if (n == 0 || n >= sizeof(doc)) {
    Serial.println("[MQTT] temperature_config serialization failed");
    return;
  }
  String device_topic_temp_config = device_topic_p + "/temperature_config_AM2-444";
  client.publish(device_topic_temp_config.c_str(), doc, true);
}

void Extract_temp_config(String incoming_message) {
  DeserializationError error = deserializeJson(received_doc, incoming_message);
  if (error) {
    Serial.print("JSON deserialization failed: ");
    Serial.println(error.c_str());
    return;
  }

  String addressString;
  int8_t sensor_selected;
  for (int i = 0; i < numberOfDevices; i++) {
    addressString = getAddressString(tempSensorAddresses[i]);
    if (received_doc.containsKey(addressString)) {
      sensor_selected = received_doc[addressString].as<int>();
      Serial.print("addressString: ");
      Serial.println(addressString);
      Serial.print("sensor_selected: ");
      Serial.println(sensor_selected);
      assignSensor(sensor_selected, tempSensorAddresses[i]);
    }
  }

  String key_offset;
  preferences.begin("values", false);
  for (int i = 0; i < numberOfDevices; i++) {
    addressString = getAddressString(tempSensorAddresses[i]);
    key_offset = "offset" + addressString;
    if (received_doc.containsKey(key_offset)) {
      offset = received_doc[key_offset].as<float>();
      switch (i) {
        case 0:
          offset1 = offset;
          preferences.putFloat("offset1", offset1);
          break;
        case 1:
          offset2 = offset;
          preferences.putFloat("offset2", offset2);
          break;
        case 2:
          offset3 = offset;
          preferences.putFloat("offset3", offset3);
          break;
        case 3:
          offset4 = offset;
          preferences.putFloat("offset4", offset4);
          break;
        default:
          break;
      }
      setoffset(tempSensorAddresses[i], offset);
    }
  }
  preferences.end();

  mqttStateDirty = true;
}

void DEVICE_INIT() {
  Serial.println("From Prefrences");

  preferences.begin("values", false);

  // Unit selections are part of the original /3 configuration contract.
  // Load them back so the pressure_config JSON remains synchronized after reboot.
  ftoC = preferences.getInt("ftoC", 1);
  psiTobar = preferences.getInt("psiTobar", 1);

  ReturnSp = preferences.getInt("temp1set_HIGH", 0);
  suctionAlertSp = preferences.getInt("temp3set_HIGH", 0);
  ReturnAlertSp = preferences.getInt("temp1set_LOW", 0);
  dischargeAlertSp = preferences.getInt("temp4set_LOW", 0);
  amps_limit = preferences.getInt("AMP1_LOW", 0);
  dischargePsiSp = preferences.getInt("psig2set_LOW", 0);
  suctionPsiSp = preferences.getInt("psig1set_HIGH", 0);
  oilPsiSp = preferences.getInt("psig3set_HIGH", 0);

  Comp_restart_delay = preferences.getInt("restartdelay", 0);
  Comp_restart_delay_ms = Comp_restart_delay * 1000;

  OPS_SW = preferences.getInt("oilsw", 0);
  LPS_SW = preferences.getInt("suctionsw", 0);
  HPS_SW = preferences.getInt("dischargesw", 0);
  sucpressuresw = preferences.getInt("sucpressure", 0);
  dispressuresw = preferences.getInt("dispressure", 0);
  oilpressuresw = preferences.getInt("oilpressure", 0);
  CTmodulesw = preferences.getInt("currentsw", 0);
  autoReset = preferences.getInt("autoSwitch", 0);
  modesw = preferences.getInt("mode", 0);

  pressure_output_signal_type = preferences.getInt("pressure_type", 0);
  pressure_unit_selection = preferences.getInt("pressure_unit", 0);
  pressure_range = preferences.getInt("pressure_range", 0);

  pressure_output_signal_type2 = preferences.getInt("pressure_type2", 0);
  pressure_unit_selection2 = preferences.getInt("pressure_unit2", 0);
  pressure_range2 = preferences.getInt("pressure_range2", 0);

  pressure_output_signal_type3 = preferences.getInt("pressure_type3", 0);
  pressure_unit_selection3 = preferences.getInt("pressure_unit3", 0);
  pressure_range3 = preferences.getInt("pressure_range3", 0);

  temp1Assigned = preferences.getBool("temp1_assign", false);
  size_t len_1 = 0;
  if (preferences.isKey("temp1Address")) len_1 = preferences.getBytes("temp1Address", temp1Address, sizeof(DeviceAddress));
  else memset(temp1Address, 0, sizeof(DeviceAddress));

  temp2Assigned = preferences.getBool("temp2_assign", false);
  size_t len_2 = 0;
  if (preferences.isKey("temp2Address")) len_2 = preferences.getBytes("temp2Address", temp2Address, sizeof(DeviceAddress));
  else memset(temp2Address, 0, sizeof(DeviceAddress));

  temp3Assigned = preferences.getBool("temp3_assign", false);
  size_t len_3 = 0;
  if (preferences.isKey("temp3Address")) len_3 = preferences.getBytes("temp3Address", temp3Address, sizeof(DeviceAddress));
  else memset(temp3Address, 0, sizeof(DeviceAddress));

  temp4Assigned = preferences.getBool("temp4_assign", false);
  size_t len_4 = 0;
  if (preferences.isKey("temp4Address")) len_4 = preferences.getBytes("temp4Address", temp4Address, sizeof(DeviceAddress));
  else memset(temp4Address, 0, sizeof(DeviceAddress));

  // Missing offsets are normal on first boot. Guard the reads so Preferences
  // does not print NOT_FOUND errors for keys that have not been created yet.
  offset1 = preferences.isKey("offset1") ? preferences.getFloat("offset1", 0.0f) : 0.0f;
  offset2 = preferences.isKey("offset2") ? preferences.getFloat("offset2", 0.0f) : 0.0f;
  offset3 = preferences.isKey("offset3") ? preferences.getFloat("offset3", 0.0f) : 0.0f;
  offset4 = preferences.isKey("offset4") ? preferences.getFloat("offset4", 0.0f) : 0.0f;

  if (len_1 != sizeof(DeviceAddress)) temp1Assigned = false;
  if (len_2 != sizeof(DeviceAddress)) temp2Assigned = false;
  if (len_3 != sizeof(DeviceAddress)) temp3Assigned = false;
  if (len_4 != sizeof(DeviceAddress)) temp4Assigned = false;

  suction_temp_offset = offset1;
  discharge_temp_offset = offset2;
  supply_temp_offset = offset3;
  return_air_temp_offset = offset4;

  preferences.end();

  if (pressure_unit_selection) {  // psi
    sensorMax = pressure_range;   // max 0-725psi
  } else {                        // bar
    float range = pressure_range * 14.7;
    sensorMax = (int)range;  // max 0-50 bar
  }

  if (pressure_unit_selection2) {  // psi
    sensorMax2 = pressure_range2;  // max 0-725psi
  } else {                         // bar
    float range = pressure_range2 * 14.7;
    sensorMax2 = (int)range;  // max 0-50 bar
  }

  if (pressure_unit_selection3) {  // psi
    sensorMax3 = pressure_range3;  // max 0-725psi
  } else {                         // bar
    float range = pressure_range3 * 14.7;
    sensorMax3 = (int)range;  // max 0-50 bar
  }
}

void callback(char* topic, byte* message, unsigned int length) {
  String messageTemp;

  for (int i = 0; i < length; i++) {
    messageTemp += (char)message[i];
  }

  // Serial.println("Message Received on: ");
  // Serial.println(String(topic));

  if (String(topic) == device_topic_s_1) {  // /test/AM2-AAA001/1
    message_received = true;
    Extract_by_json(messageTemp);
  }

  else if (String(topic) == device_topic_s_2) {  // /test/AM2-AAA001/2
    message_received_config = true;
    Extract_temp_config(messageTemp);
  }

  else if (String(topic) == device_topic_s_3) {  // /test/AM2-AAA001/3
    message_received_pressure_config = true;
    Extract_pressure_config(messageTemp);
  }
}

void reconnect() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Wi-Fi is not connected. Attempting to reconnect...");
    return;
  }
  if (!client.connected()) {
    espClient.setCACert(root_ca);
    espClient.setCertificate(client_cert);
    espClient.setPrivateKey(client_key);
    client.setServer(mqtt_server, mqtt_port);
    client.setCallback(callback);
    Serial.print("Attempting MQTT connection...");

    if (client.connect(devicename.c_str())) {
      Serial.println("connected");
      client.subscribe(device_topic_s_m.c_str());
      mqttStateDirty = true;

    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 10 milliseconds");
    }
  }
}
