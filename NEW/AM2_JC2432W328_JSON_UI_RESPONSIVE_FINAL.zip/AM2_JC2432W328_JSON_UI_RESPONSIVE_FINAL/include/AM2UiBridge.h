#pragma once
#include <Arduino.h>

struct AM2UiSnapshot {
  char deviceId[20];
  int16_t returnTemp10;
  int16_t supplyTemp10;
  int16_t suctionTemp10;
  int16_t dischargeTemp10;
  int16_t rawSensorTemp10[4];
  uint8_t sensorAddress[4][8];
  uint8_t sensorRole[4];
  uint8_t sensorCount;

  int16_t returnSp;
  int16_t returnAlertSp;
  int16_t suctionAlertSp;
  int16_t dischargeAlertSp;
  int16_t suctionPsiSp;
  int16_t dischargePsiSp;
  int16_t oilPsiSp;
  int16_t ampsLimit;

  int16_t suctionPressure;
  int16_t dischargePressure;
  int16_t oilPressure;
  int16_t amp1;
  int16_t amp2;
  int16_t amp3;

  uint8_t compStatus;
  bool runRelayOn;
  bool alarmRelayOn;
  bool hpsActive;
  bool lpsActive;
  bool opsActive;
  bool compFeedback;

  uint8_t mode;
  uint8_t autoReset;
  uint8_t ctEnable;
  uint8_t suctionPressureEnable;
  uint8_t dischargePressureEnable;
  uint8_t oilPressureEnable;
  uint8_t lpsEnable;
  uint8_t hpsEnable;
  uint8_t opsEnable;
  int16_t restartDelay;
};

enum AM2UiCommandType : uint8_t {
  UI_CMD_NONE = 0,
  UI_CMD_START,
  UI_CMD_STOP,
  UI_CMD_RETURN_SP,
  UI_CMD_RETURN_ALERT,
  UI_CMD_SUCTION_ALERT,
  UI_CMD_DISCHARGE_ALERT,
  UI_CMD_MODE,
  UI_CMD_AUTO_RESET,
  UI_CMD_CT_ENABLE,
  UI_CMD_SUCTION_PRESSURE_ENABLE,
  UI_CMD_DISCHARGE_PRESSURE_ENABLE,
  UI_CMD_OIL_PRESSURE_ENABLE,
  UI_CMD_LPS_ENABLE,
  UI_CMD_HPS_ENABLE,
  UI_CMD_OPS_ENABLE,
  UI_CMD_RESTART_DELAY,
  UI_CMD_SUCTION_PSI_SP,
  UI_CMD_DISCHARGE_PSI_SP,
  UI_CMD_OIL_PSI_SP,
  UI_CMD_AMPS_LIMIT,
  UI_CMD_SENSOR_ASSIGN
};

struct AM2UiCommand {
  uint8_t type;
  int32_t value;
  uint8_t sensorIndex;
};

void am2UiGetSnapshot(AM2UiSnapshot& out);
bool am2UiSendCommand(const AM2UiCommand& cmd);
