#pragma once
#include "UI.h"


HardwareSerial RS485Serial(1);

#define RS485_BAUD_RATE AM2_RS485_BAUD
#define RS485_TX_PIN AM2_RS485_TX_PIN
#define RS485_RX_PIN AM2_RS485_RX_PIN

// CT MODULE - unchanged IDs/register from original AM2.
#define MODBUS_SLAVE_ID 0x01
#define MODBUS_FUNCTION_READ_HOLDING_REGISTERS 0x03
#define CT_REGISTER_ADDRESS 0x0103

uint16_t calculateCRC(uint8_t *buffer, uint16_t length) {
  uint16_t crc = 0xFFFF;
  for (uint8_t i = 0; i < length; i++) {
    crc ^= buffer[i];
    for (uint8_t j = 0; j < 8; j++) {
      if (crc & 1) crc = (crc >> 1) ^ 0xA001;
      else crc >>= 1;
    }
  }
  return crc;
}

void sendModbusRequest(uint8_t slaveId, uint8_t functionCode, uint16_t startAddress, uint16_t registerCount) {
  // Auto-direction RS485 module: no DE/RE GPIO is required.
  uint8_t request[8];
  request[0] = slaveId;
  request[1] = functionCode;
  request[2] = startAddress >> 8;
  request[3] = startAddress & 0xFF;
  request[4] = registerCount >> 8;
  request[5] = registerCount & 0xFF;
  uint16_t crc = calculateCRC(request, 6);
  request[6] = crc & 0xFF;
  request[7] = crc >> 8;

  RS485Serial.write(request, sizeof(request));
  RS485Serial.flush();
  uiDelay(10); // exact wait retained; UI/touch serviced during wait
}

bool readModbusResponse(uint8_t *response, uint16_t length) {
  uint32_t timeout = millis() + 1000;
  uint16_t index = 0;
  while (millis() < timeout) {
    if (RS485Serial.available()) {
      response[index++] = RS485Serial.read();
      if (index >= length) return true;
    }
    uiDelay(1); // timeout/logic unchanged; service LVGL like WT reference
  }
  return false;
}

bool readHoldingRegisters(uint8_t slaveId, uint16_t startAddress, uint16_t registerCount, uint16_t *buffer) {
  sendModbusRequest(slaveId, 0x03, startAddress, registerCount);
  uint8_t response[5 + 2 * registerCount];
  uiDelay(300); // original timing preserved; UI remains responsive

  if (readModbusResponse(response, sizeof(response))) {
    uint16_t crc = (response[sizeof(response) - 1] << 8) | response[sizeof(response) - 2];
    if (calculateCRC(response, sizeof(response) - 2) == crc) {
      for (int i = 0; i < registerCount; i++) {
        buffer[i] = (response[3 + i * 2] << 8) | response[4 + i * 2];
      }
      return true;
    } else {
      Serial.println("CRC error!");
      RS485Serial.end();
      uiDelay(50);
      RS485Serial.begin(RS485_BAUD_RATE, SERIAL_8N1, RS485_RX_PIN, RS485_TX_PIN);
      uiDelay(50);
    }
  } else {
    Serial.println("No response or timeout!");
  }
  return false;
}
