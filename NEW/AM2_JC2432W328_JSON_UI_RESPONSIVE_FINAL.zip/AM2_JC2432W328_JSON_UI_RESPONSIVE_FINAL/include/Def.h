#pragma once

#define SENSOR_DISCONNECTED 888
#define SENSOR_NOT_SELECTED 999
#define MQTT_INTERVAL 3000
#define SENSOR_READ_INTERVAL 1000

////////////////////Temperature Sensor DS18B20///////////////////
// CHANGE #1: all four DS18B20 sensors are on one GPIO4 bus.
#define DS18B20_PIN AM2_ONEWIRE_PIN
/////////////////////////////////////////////////////////////////

AsyncWebServer server(80);
Preferences preferences;
WiFiClientSecure espClient;
PubSubClient client(espClient);
OneWire oneWire(DS18B20_PIN);
DallasTemperature sensors(&oneWire);

String devicename = "AM2-444051";

String device_topic_s_m = "/test/" + devicename + "/#";  // subscribe topic
String device_topic_s_1 = "/test/" + devicename + "/1";  // original settings/setpoint input
String device_topic_s_2 = "/test/" + devicename + "/2";  // temperature configuration input
String device_topic_s_3 = "/test/" + devicename + "/3";  // original system configuration input
String device_topic_p = "/KRC/" + devicename;            // main publish topic
String device_topic_pressure_config = device_topic_p + "/pressure_config"; // original AM2 pressure/system config publish

String Name = "DX-MASTER";
String myID = "16092100096";
String substring1 = myID.substring(2, 6);
String substring2 = myID.substring(9, 11);
String hostname = Name + substring1 + substring2;

const char* mqtt_server = "a31qubhv0f0qec-ats.iot.eu-north-1.amazonaws.com";
const int mqtt_port = 8883;
#define MAX_SENSORS 4

DeviceAddress tempSensorAddresses[MAX_SENSORS];
float detectedSensorTemps[MAX_SENSORS] = { SENSOR_DISCONNECTED, SENSOR_DISCONNECTED, SENSOR_DISCONNECTED, SENSOR_DISCONNECTED };
int numberOfDevices = 0;
DeviceAddress temp1Address;
DeviceAddress temp2Address;
DeviceAddress temp3Address;
DeviceAddress temp4Address;
bool temp1Assigned = false;
bool temp2Assigned = false;
bool temp3Assigned = false;
bool temp4Assigned = false;
float discharge_temp_offset, suction_temp_offset, return_air_temp_offset, supply_temp_offset;
float offset, offset1, offset2, offset3, offset4;

String ssid = "";
String password = "";
String macaddress = "";
String myIP = "";

bool message_received = false;
bool message_received_config = false;
bool message_received_pressure_config = false; // original incoming /3 message flag
bool mqttStateDirty = true; // force retained state/config publish after boot/reconnect/change
StaticJsonDocument<1024> received_doc;
bool wifi_ap_mode = false;
unsigned long wifi_setting_time = 0;
int wifi_channel = 0;
bool is_wifi_connected = false;
// Deferred AP handover state.  The AP must not be torn down from inside an
// AsyncWebServer/AsyncTCP callback while its HTTP socket is still closing.
volatile bool wifi_ap_disconnect_pending = false;
unsigned long wifi_ap_disconnect_at = 0;

const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 18000;
const int daylightOffset_sec = 0;

// States of the Machine - unchanged from original AM2.
#define STOPPED 0
#define RUNNING 1
#define AUTO_STOPPED 2
#define RESTARTING 4
#define RETURN_TEMP_ALERT 5
#define SUCTION_TEMP_ALERT 6
#define DISCHARGE_TEMP_ALERT 7
#define SUCTION_PSI_ALERT 8
#define DISCHARGE_PSI_ALERT 9
#define OIL_PSI_ALERT 10
#define AMPS_HIGH 11
#define LPS_ALARM 12
#define HPS_ALARM 13
#define OPS_ALARM 14
#define COMP_FAIL_TO_RUN 15
#define TEMP_SENSOR_ERROR 16
#define MC_STUCK 17

uint8_t inputs = 0;
int comp_Status = 0;

int SuctionTemp = 0;
float SuctionTempC = 0;
int SupplyTemp = 0;
float SupplyTempC = 0;
int ReturnTemp = 0;
float ReturnTempC = 0;
int dischargeTemp = 0;
float dischargeTempC = 0;

int suctionPressure;
int suctionPressureB;
int dischargePressure;
int dischargePressureB;
int OilPressure;
int OilPressureB;

int Comp_Start_delay = 0;
int Comp_restart_delay = 0;
int Comp_restart_delay_ms = 0;

unsigned long COMP_START_TIME = 0;
unsigned long SWITCH_ALARM_HOLD_TIME = 0;
unsigned long COMP_TRIP_HOLD_TIME = 0;
unsigned long COMP_FB_STUCK_TIME = 0;
unsigned long currentMillis = 0;
unsigned long wait_time = 0;
unsigned long RESTART_TIME = 0;
unsigned long pmillis = 0;

// ALERTS
int suctionAlertSp, dischargeAlertSp, ReturnAlertSp, ReturnSp = 0;
int suctionPsiSp, dischargePsiSp, oilPsiSp, amps_limit = 0;
int AMP1, AMP2, AMP3 = 0;

String HPS = "LOW", LPS = "HIGH", OPS = "LOW";
int OPS_SW, HPS_SW, LPS_SW = 0;
int oilpressuresw, dispressuresw, sucpressuresw = 0;
bool comp_alarm, oil_alarm, dis_alarm, suction_alarm, oilpsi_alarm, dispsi_alarm, suctionpsi_alarm = false;
bool machineStopped = false;
bool startup_flag, alarmFlag = false;
bool Machine_Shutdown, Switches_alarm = false;

bool AutoAlarmReset = false;
int autoReset = 0;
int ftoC = 1, psiTobar = 1;
int modesw, CTmodulesw = 0;
bool startSW, stopSW = false;

int pressure_output_signal_type;
int pressure_unit_selection;
int pressure_range;

int pressure_output_signal_type2;
int pressure_unit_selection2;
int pressure_range2;

int pressure_output_signal_type3;
int pressure_unit_selection3;
int pressure_range3;

int sensorMax, sensorMax2, sensorMax3 = 0;
