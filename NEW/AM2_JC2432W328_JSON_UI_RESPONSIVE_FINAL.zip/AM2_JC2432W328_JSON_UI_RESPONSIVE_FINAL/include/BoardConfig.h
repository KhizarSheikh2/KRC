#pragma once
#include <Arduino.h>

// JC2432W328 2.8" capacitive-touch board, 320x240 landscape.
#define AM2_SCREEN_W 320
#define AM2_SCREEN_H 240
#define AM2_TFT_BL_PIN 27

// Built-in CST820 touch controller (separate I2C bus: Wire).
#define AM2_TOUCH_SDA 33
#define AM2_TOUCH_SCL 32
#define AM2_TOUCH_RST 25
#define AM2_TOUCH_ADDR 0x15

// External AM2 I2C bus (Wire1): PCF8574 + ADS1115.
#define AM2_HW_I2C_SDA 21
#define AM2_HW_I2C_SCL 22
#define AM2_HW_I2C_HZ 100000UL
#define AM2_PCF8574_ADDR 0x20
#define AM2_ADS1115_ADDR 0x48

// CHANGE #1: all four DS18B20 sensors share GPIO4.
#define AM2_ONEWIRE_PIN 4

// CHANGE #3: CT/current module on auto-direction RS485.
// No DE/RE GPIO is used.
#define AM2_RS485_RX_PIN 16
#define AM2_RS485_TX_PIN 17
#define AM2_RS485_BAUD 9600

// PCF8574 mapping for the user's actual AM2 PCB wiring.
// P0/P1 remain START/STOP; P2/P3 are the two relay outputs; P4..P7 are PC817-isolated inputs.
// PC817 behavior confirmed on the user's PCB:
// field signal HIGH -> PC817 ON -> PCF input LOW
// field signal LOW/open -> PC817 OFF -> PCF input HIGH.
#define AM2_PCF_START_BIT 0
#define AM2_PCF_STOP_BIT 1
#define AM2_PCF_RUN_RELAY_BIT 2
#define AM2_PCF_ALARM_RELAY_BIT 3
#define AM2_PCF_HPS_BIT 4
#define AM2_PCF_LPS_BIT 5
#define AM2_PCF_OPS_BIT 6
#define AM2_PCF_COMP_FB_BIT 7

// Keep the user's project macro exactly as requested.
// false = relay output is ACTIVE-HIGH (HIGH = ON, LOW = OFF), matching the original AM2 GPIO logic.
#define RELAY_ACTIVE_LOW false

// Relay electrical levels are derived from RELAY_ACTIVE_LOW so the macro is authoritative.
#define AM2_RELAY_ON_LEVEL  (RELAY_ACTIVE_LOW ? LOW : HIGH)
#define AM2_RELAY_OFF_LEVEL (RELAY_ACTIVE_LOW ? HIGH : LOW)

// Temporary serial diagnostics for commissioning the new single-controller PCB.
// Set to 0 after HPS/LPS/OPS/COMP feedback levels have been confirmed.
#define AM2_IO_DIAGNOSTICS 1
