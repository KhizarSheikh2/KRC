#pragma once
#include "UI.h"

// #include <Adafruit_ADS1X15.h>

// /*
//   Voltage= ADC value × FULL-SCALE VOLTAGE /  RESOLUTION
//   where :
//   FULL-SCALE VOLTAGE => 4.096V
//   RESOLUTION => 2^16 / 2 = 32768 i.e MAX ADC VALUE => 32768
// */

// // // for 4-20mA sensors
// // const int SENSOR_MAX_ANALOG_I = 24000;  // 20mA or 3.0V
// // const int SENSOR_MIN_ANALOG_I = 4800;   // 4mA or 0.6V

// // for 0-5v sensors
const int SENSOR_MAX_V = 13454;  //5.1V
const int SENSOR_MIN_V = 0;      // 0.0V

#define ADC_Ports 3  // 3 Channels for each ADS1115

#define ADS1115_ADDR 0x48

// int16_t readADS1115(uint8_t channel) {
//   uint16_t config = 0;

//   // Start single conversion
//   config |= 0x8000;

//   // Select channel (MUX bits)
//   switch (channel) {
//     case 0: config |= 0x4000; break;  // AIN0
//     case 1: config |= 0x5000; break;  // AIN1
//     case 2: config |= 0x6000; break;  // AIN2
//     case 3: config |= 0x7000; break;  // AIN3
//   }

//   // PGA ±4.096V
//   config |= 0x0200;

//   // Single-shot mode
//   config |= 0x0100;

//   // 128 SPS
//   config |= 0x0080;

//   // Disable comparator
//   config |= 0x0003;

//   // Write config register
//   AM2Wire.beginTransmission(ADS1115_ADDR);
//   Wire.write(0x01);  // Config register
//   Wire.write(config >> 8);
//   Wire.write(config & 0xFF);
//   AM2Wire.endTransmission();

//   delay(8);  // Wait conversion (~8ms for 128SPS)

//   // Read conversion register
//   AM2Wire.beginTransmission(ADS1115_ADDR);
//   Wire.write(0x00);  // Conversion register
//   AM2Wire.endTransmission();

//   AM2Wire.requestFrom(ADS1115_ADDR, 2);

//   if (AM2Wire.available() == 2) {
//     int16_t result = (AM2Wire.read() << 8) | AM2Wire.read();
//     return result;
//   }

//   return -1;
// }
int16_t readADS1115(uint8_t channel) {

  uint16_t config = 0x8000;  // Start conversion

  switch (channel) {
    case 0: config |= 0x4000; break;
    case 1: config |= 0x5000; break;
    case 2: config |= 0x6000; break;
    case 3: config |= 0x7000; break;
  }

  config |= 0x0200;  // ±4.096V
  config |= 0x0100;  // Single-shot
  config |= 0x0080;  // 128 SPS
  config |= 0x0003;  // Disable comparator

  // Write config
  AM2Wire.beginTransmission(ADS1115_ADDR);
  AM2Wire.write(0x01);
  AM2Wire.write(config >> 8);
  AM2Wire.write(config & 0xFF);
  AM2Wire.endTransmission();

  // Wait until conversion complete. 128 SPS normally completes in ~8 ms.
  // A short timeout prevents a missing ADS1115 from locking the whole controller.
  const uint32_t conversionStart = millis();
  bool conversionReady = false;
  while (millis() - conversionStart < 40UL) {
    AM2Wire.beginTransmission(ADS1115_ADDR);
    AM2Wire.write(0x01);
    if (AM2Wire.endTransmission() != 0) {
      uiDelay(1);
      continue;
    }

    if (AM2Wire.requestFrom(ADS1115_ADDR, 2) == 2) {
      uint16_t status = (AM2Wire.read() << 8) | AM2Wire.read();
      if (status & 0x8000) {
        conversionReady = true;
        break;
      }
    }
    uiDelay(1);
  }
  if (!conversionReady) return -32768;

  // Read result
  AM2Wire.beginTransmission(ADS1115_ADDR);
  AM2Wire.write(0x00);
  AM2Wire.endTransmission();

  if (AM2Wire.requestFrom(ADS1115_ADDR, 2) != 2)
    return -32768;

  return (AM2Wire.read() << 8) | AM2Wire.read();
}

void scanADC() {
  // Serial.print("Scanning Analog Inputs...");
  for (uint8_t channel = 0; channel < ADC_Ports; channel++) {  // to read only CH0 & CH1
    int16_t raw = readADS1115(channel);
    uiDelay(100);  // Same delay; LVGL/touch serviced during ADC settling

    // Serial.print("\n Channel : ");
    // Serial.print(channel);
    // Serial.print(" Raw Value : ");
    // Serial.print(raw);

    switch (channel) {
      case 0:
        // 0-5V sensor
        suctionPressure = suctionPressureB = 888;
        if (pressure_output_signal_type == 1) {
          if (raw > 0) {
            suctionPressure = map(raw, SENSOR_MIN_V, SENSOR_MAX_V, 0, sensorMax);
            float bar = suctionPressure / 14.7;
            suctionPressureB = (int)bar;
          }
        }
        break;
        //   case 1:
        //     // 4-20mA sensor
        //     if (pressure_output_signal_type == 2) {
        //       dischargePressure = calc(raw, SENSOR_MIN_ANALOG_I, SENSOR_MAX_ANALOG_I, sensorMax2);
        //     }
        //     // 0-5V sensor
        //     else if (pressure_output_signal_type == 1) {
        //       dischargePressure = calc(raw, SENSOR_MIN_ANALOG_V, SENSOR_MAX_ANALOG_V, sensorMax2);
        //     }
        //     if (psiTobar == 0 && dischargePressure < 888) dischargePressure = dischargePressure / 14.7;
        //     // if (raw >= SENSOR_MIN_ANALOG && raw < SENSOR_MAX_ANALOG) {  // Sensor Disconnected check
        //     //   psi_value = map(raw, SENSOR_MIN_ANALOG, SENSOR_MAX_ANALOG, 0, sensorMax2);
        //     //   dischargePressure = psi_value;
        //     //   if (psiTobar == 0) dischargePressure = dischargePressure / 14.7;
        //     // } else {
        //     //   dischargePressure = 888;
        //     // }
        //     break;
        //   case 2:
        //     // 4-20mA sensor
        //     if (pressure_output_signal_type == 2) {
        //       OilPressure = calc(raw, SENSOR_MIN_ANALOG_I, SENSOR_MAX_ANALOG_I, sensorMax3);
        //     }
        //     // 0-5V sensor
        //     else if (pressure_output_signal_type == 1) {
        //       OilPressure = calc(raw, SENSOR_MIN_ANALOG_V, SENSOR_MAX_ANALOG_V, sensorMax3);
        //     }
        //     if (psiTobar == 0 && OilPressure < 888) OilPressure = OilPressure / 14.7;
        //     // if (raw >= SENSOR_MIN_ANALOG_I && raw < SENSOR_MAX_ANALOG_I) {  // Sensor Disconnected check
        //     //   psi_value = map(raw, SENSOR_MIN_ANALOG_I, SENSOR_MAX_ANALOG_I, 0, sensorMax3);
        //     //   OilPressure = psi_value;
        //     //   if (psiTobar == 0) OilPressure = OilPressure / 14.7;
        //     // } else {
        //     //   OilPressure = 888;
        //     // }
        //     break;
      default:
        break;
    }
  }
  // Serial.println();
}
