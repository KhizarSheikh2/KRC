#pragma once
#include <Arduino.h>

bool uiBegin();
void uiSetSystemReady();
void uiService();
void uiDelay(uint32_t durationMs);
