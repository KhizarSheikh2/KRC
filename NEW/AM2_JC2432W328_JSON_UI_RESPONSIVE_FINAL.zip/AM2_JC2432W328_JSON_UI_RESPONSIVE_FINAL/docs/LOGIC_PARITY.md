# Logic parity with supplied AM2

The supplied `AM2_KRC_NANO_AHMED` source is the control-logic authority.

Preserved:

- Device ID `AM2-444051` and `DX-MASTER` hostname identity.
- Main MQTT JSON key set/order (31 fields).
- Original `/test/<device>/1`, `/2`, `/3` incoming app routes.
- Original Wi-Fi/AP/provisioning file byte-for-byte.
- Machine state/status codes 0,1,2,4..17.
- START request / STOP behavior.
- `ReturnTempC > ReturnSp` RUN rule.
- `ReturnTempC < ReturnSp` AUTO STOP rule.
- HPS/LPS/OPS/compressor-feedback evaluation and priority behavior.
- 500 ms switch-trip hold.
- 20 s auto-reset hold.
- 2500 ms compressor-feedback timing.
- Restart delay behavior.
- CT slave/register and current-limit behavior.
- Existing ADS1115 active pressure processing.
- Existing NVS keys for operating configuration.

Required conversion changes:

- BECA code/state/config removed.
- Fourth DS18B20 always supplies Return when assigned.
- Fourth sensor offset switch index corrected to physical sensor index 3 so it behaves like sensors 1..3.
- Sensor-4 unassign stores a zeroed address buffer instead of a null pointer.
- Old direct ESP32 START/STOP/RUN/ALARM pins are adapted through PCF8574 because the JC2432W328 is now the only ESP32.
- Direct 1-Wire bus moved to GPIO4.
- CT RS485 is RX16/TX17 with an automatic-direction module, so DE/RE handling is removed.
- PCF8574/ADS1115 use `Wire1` on GPIO21/22 so they cannot conflict with CST820 touch on `Wire` GPIO33/32.
- UI writes to the same variables and NVS keys used by the app.

Publish behavior requested by the user:

- Main JSON only.
- Temperature configuration JSON only.
- No published pressure-configuration JSON.

The original inbound `/3` configuration route remains because deleting it would change existing mobile-app configuration behavior.
