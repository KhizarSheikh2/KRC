# AM2 JSON synchronization

The original AM2 had three hardware-to-app JSON topics. This release restores all three while keeping BECA removed and sensor 4 as Return.

## App -> hardware
- `/test/AM2-444051/1`: setpoints / alarm limits
- `/test/AM2-444051/2`: DS18B20 roles / offsets
- `/test/AM2-444051/3`: pressure and system configuration

## Hardware -> app
- `/KRC/AM2-444051`: main telemetry/status
- `/KRC/AM2-444051/temperature_config_AM2-444`: temperature configuration
- `/KRC/AM2-444051/pressure_config`: pressure/system configuration

## Synchronization behavior
Incoming app messages and TFT setting changes set `mqttStateDirty`. `client.loop()` is serviced before the publish decision, then all three retained JSONs are published immediately after a configuration change, or every 3 seconds as the normal periodic refresh.

The previous logic skipped the next publish whenever an incoming message flag was set; that caused stale app/TFT state and has been removed.

`returnTempSelection` remains in the pressure_config JSON with value `0` only because the mobile app schema contains it. BECA logic is not restored. Generic app fields `switch`, `startdelay`, and `resetsw` were not consumed by the original AM2 firmware, so no new behavior is invented for them.
