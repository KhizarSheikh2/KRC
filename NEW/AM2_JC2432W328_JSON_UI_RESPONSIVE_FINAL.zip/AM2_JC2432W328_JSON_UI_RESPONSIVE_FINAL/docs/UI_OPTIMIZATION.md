# AM2 UI optimization

The AM2 UI keeps the corrected 320x240 layout while changing the low-level display execution to the known-good WT_COOLING_CYD pattern.

## Geometry
- Header: x=6, y=4, 308x34
- Main page area: x=4, y=42, 312x153
- Navigation: y=198
- Five navigation buttons: 60x38 with 3 px spacing

## Runtime behavior
- No dedicated LVGL FreeRTOS task.
- `uiService()` is called at the start and end of every Arduino `loop()` iteration.
- Only the visible page is refreshed from controller data every 250 ms.
- LVGL's touch read period is 20 ms, matching the WT reference.
- LVGL display refresh period is 33 ms, matching the WT reference.
- Existing CT/ADC wait durations remain the same but pump LVGL/touch using `uiDelay()`.

## Touch
Touch uses the direct working WT coordinate transform. No calibration state can distort the mapping.
