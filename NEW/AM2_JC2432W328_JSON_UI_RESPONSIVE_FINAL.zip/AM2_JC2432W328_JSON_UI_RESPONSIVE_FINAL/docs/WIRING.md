# AM2 JC2432W328 wiring

## JC2432W328 built-in hardware

The TFT/touch pins are already used internally by the display board and should not be reused by AM2 peripherals.

## External I2C

```
JC2432W328 GPIO21 (SDA) ----+---- PCF8574 SDA
                            +---- ADS1115 SDA
JC2432W328 GPIO22 (SCL) ----+---- PCF8574 SCL
3V3/GND ------------------------- common supply/reference
```

Addresses:

- PCF8574 = `0x20`
- ADS1115 = `0x48`

## Four DS18B20 sensors

```
3.3V
  |
  +-- 4.7 kOhm --+-- GPIO4
                 |
                 +-- DS18B20 #1 DQ
                 +-- DS18B20 #2 DQ
                 +-- DS18B20 #3 DQ
                 +-- DS18B20 #4 DQ

3.3V ---------------- all VDD
GND ----------------- all GND
```

Use normal 3-wire powered mode.

Logical roles configured from the app/TFT:

- 1 = Suction
- 2 = Discharge
- 3 = Supply
- 4 = Return
- 0 = Unassigned

## PCF8574

```
P0 START
P1 STOP
P2 RUN relay
P3 ALARM relay
P4 HPS
P5 LPS
P6 OPS
P7 Compressor feedback
```

START/STOP are treated as active-low contacts. HPS/LPS/OPS/COMP_FB pass through PC817 optocouplers. On the commissioned PCB, field HIGH produces PCF LOW and field LOW/open produces PCF HIGH. Therefore:

- HPS/LPS/OPS PCF HIGH = protection fault/open circuit.
- COMP_FB PCF LOW = compressor feedback present/running.
- COMP_FB PCF HIGH = no compressor feedback/stopped.

### Relays

`#define RELAY_ACTIVE_LOW false` is authoritative in this release:

- PCF P2 HIGH = RUN relay ON
- PCF P2 LOW = RUN relay OFF
- PCF P3 HIGH = ALARM relay ON
- PCF P3 LOW = ALARM relay OFF

At firmware initialization the safe latch is `0xF3`: P0/P1/P4..P7 are released HIGH for input operation and P2/P3 are driven LOW so both relays are commanded OFF.

> Hardware note: PCF8574 pins power up released HIGH before firmware executes. If the connected relay interface is truly active-high and must never pulse during MCU boot, use an appropriate external driver/pulldown/interlock in the relay hardware.

## ADS1115

The original AM2 analog-pressure behavior is retained. The original source actively processes A0 (Suction); the A1/A2 conversion blocks remain as they were in the supplied original code.

## CT / three-phase current Modbus

```
GPIO17 TX ---- RS485 DI/TX input
GPIO16 RX ---- RS485 RO/RX output
GND ---------- RS485 GND
A/B ---------- CT module A/B
```

The converter must be automatic-direction because the final firmware has no DE/RE GPIO.

- Baud = 9600
- Slave = `0x01`
- Start register = `0x0103`
- Read count = 3 (AMP1/AMP2/AMP3)
