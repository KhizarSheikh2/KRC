# WT_COOLING_CYD responsive display reference

The user supplied a known-good JC2432W328 project named `WT_COOLING_CYD(1).zip` and reported that its display is responsive, accurate and does not lag.

AM2 now mirrors the parts of that project that matter to HMI behavior:

## Touch
- CST820 I2C address: 0x15
- SDA: GPIO33
- SCL: GPIO32
- Reset: GPIO25
- Reset sequence: HIGH 5 ms, LOW 10 ms, HIGH 60 ms
- I2C frequency: 400 kHz
- I2C timeout: 20 ms
- controller wake/keep-awake write: register 0xFE, value 0xFF
- landscape mapping:
  - swap axes
  - X not inverted
  - Y inverted

Equivalent coordinate result for rotation 1:
- screen X = raw Y
- screen Y = 239 - raw X

No NVS calibration or calibration overlay is used.

## LVGL service model
The reference services `lv_tick_inc()` and `lv_timer_handler()` from the normal application loop. AM2 now follows the same single-task LVGL model.

To avoid AM2's existing Modbus/ADC waits blocking touch, `uiDelay(ms)` preserves the same wait duration while calling `uiService()` during that interval.

## Memory
The reference uses a 20-row draw buffer. AM2 requests the same 20-row size dynamically, falling back to 12, 8 or 4 rows if heap fragmentation prevents the preferred allocation. This avoids adding a large static DRAM block.
