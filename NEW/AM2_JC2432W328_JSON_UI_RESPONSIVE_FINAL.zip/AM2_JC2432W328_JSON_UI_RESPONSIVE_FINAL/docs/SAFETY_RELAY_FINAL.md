# AM2 safety / relay final audit

## PCF8574 mapping
- P0 START
- P1 STOP
- P2 RUN relay
- P3 ALARM relay
- P4 HPS
- P5 LPS
- P6 OPS
- P7 COMP_FB

## PC817 input polarity
Measured on the user's hardware: field HIGH -> PC817 output LOW at PCF; field LOW/open -> PCF HIGH.
Therefore HPS/LPS/OPS fault logic remains active-HIGH at the PCF level. Compressor feedback present is active-LOW at P7.

## Relays
`RELAY_ACTIVE_LOW=false` is authoritative. ON=HIGH, OFF=LOW. Boot safe latch is 0xF3.

## Fail-safe I2C behavior
A PCF read failure returns no START/STOP press, marks safety inputs as fault/no feedback, and `scanAlarms()` asserts machine shutdown.
