# AM2 monitor-mode, PCF8574 and DS18B20 correction

## Monitor mode
The original AM2 `modesw == 0` branch does not issue START/STOP or RUN commands. It monitors alarms and compressor feedback only. The TFT now mirrors that behavior:

- MONITOR mode: no START/STOP button, no setpoint control shown on HOME, and the card says `MONITORING ONLY`.
- CONTROL mode: START/STOP is shown and uses the original `startSW` / `stopSW` flags.
- The controller also rejects a TFT START/STOP command when `modesw != 1`.

## PCF8574 mapping
The project now matches the user's stated PCB mapping exactly:

- P0 START
- P1 STOP
- P2 RUN relay
- P3 ALARM relay
- P4 HPS
- P5 LPS
- P6 OPS
- P7 COMP_FB

The original AM2 alarm logic still treats the logical HPS/LPS/OPS inputs as active HIGH. Because PC817 wiring can invert an external switch, raw P4..P7 levels are printed every 2 seconds during commissioning.

## DS18B20 / GPIO4 diagnosis
The firmware uses standard OneWire + DallasTemperature on GPIO4. Sensor assignment/NVS is not involved in physical discovery: `getDeviceCount()==0` means no 1-Wire presence/ROM was detected.

At boot and every 10 seconds while zero devices are found, the firmware prints:

- GPIO4 idle level
- every raw 1-Wire ROM found
- a clear message when no presence pulse is detected

JC2432W328C boards connect GPIO4 to the onboard active-low RGB LED red channel. This extra load can interfere with a DS18B20 open-drain bus, especially when the sensor itself must pull the line LOW for the presence pulse. If one correctly wired sensor plus a 4.7k pull-up is still not detected, GPIO4 hardware loading is the leading cause.
