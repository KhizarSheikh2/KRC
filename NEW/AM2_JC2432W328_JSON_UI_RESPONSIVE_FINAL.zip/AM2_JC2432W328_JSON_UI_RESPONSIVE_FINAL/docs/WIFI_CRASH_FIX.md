# Wi-Fi / AsyncTCP crash fix

Observed crash:

`assert failed: tcp_update_rcv_ann_wnd ... (new_rcv_ann_wnd <= 0xffff)`

It occurred immediately after successful provisioning and the AP handover.

## Root cause

The provisioning POST body callback runs in AsyncTCP/lwIP context. The old code
called `WiFi.softAPdisconnect(true)` from that callback immediately after
`request->send()`. This can tear down the AP/netif while the HTTP TCP PCB is still
being acknowledged/closed, corrupting the receive-window state and causing the
lwIP assertion.

## Fix

1. The callback now only schedules the AP handover.
2. The actual disconnect runs 1.5 s later from the normal Arduino loop.
3. It uses the same safe call shape as WT_Cooling: `WiFi.softAPdisconnect()`
   (no `true` parameter).
4. No delay is performed after `request->send()` inside the body callback.

This changes only the network handover timing; AM2 control/safety/MQTT payload
logic is unchanged.

## First-boot Preferences messages

Temperature ROM addresses and offsets do not exist before the user configures
them. Reads are guarded by `Preferences::isKey()` so those expected first-boot
missing keys no longer print NOT_FOUND errors. Missing values still behave as
unconfigured/default values.
