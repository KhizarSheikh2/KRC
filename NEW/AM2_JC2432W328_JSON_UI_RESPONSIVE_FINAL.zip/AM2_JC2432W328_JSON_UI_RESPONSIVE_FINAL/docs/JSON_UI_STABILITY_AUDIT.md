# AM2 JSON / UI Stability Audit

## JSON state shown by the user's capture

The three outgoing topics are structurally correct and synchronized with the TFT:

- Main JSON temperatures map to the currently assigned roles.
- Temperature-config JSON reports all four detected ROMs and role values.
- Pressure/system config reports mode=1, which correctly makes the TFT show CONTROL and exposes START/STOP.
- The four temperature-control setpoints in the main JSON match the CTRL page values.

### Current/CT warning

The captured state has `currentsw=1`, but `value0`, `value8`, and `value9` are all `888`, while `value17` (current limit) is `0`. In the original AM2 alarm logic, an enabled current module with those values produces status 11 (`HIGH CURRENT`). This is why the HOME screen shows HIGH CURRENT. The JSON itself is not malformed; it is reporting a CT communication/configuration problem.

### Pressure configuration warning

The captured pressure_config has suction/discharge/oil pressure monitoring enabled, while all pressure types/ranges are 0. The current original AM2 ADS1115 implementation actively converts only suction/A0; discharge/A1 and oil/A2 conversion blocks remain commented in the original source. Therefore enabling all three pressure protections with type/range 0 is not a valid commissioned configuration.

## UI responsiveness fixes in this revision

1. Bottom navigation changed from `LV_EVENT_CLICKED` to `LV_EVENT_PRESSED`. A page now changes on touch-down instead of waiting for finger release. This directly matches the user's photos where a finger is still on SAFE/SET while the previous page remains visible.
2. LVGL handler calls are rate-limited to 5 ms minimum. Cooperative hardware waits used to call `uiService()` every 1 ms and could over-poll CST820 I2C.
3. CT Modbus FC03 is now non-blocking. The old path could spend about 1.31 seconds in every main-loop pass when the CT module did not answer (10 ms + 300 ms + up to 1000 ms timeout). Current values and register contract are unchanged.
4. The three retained MQTT JSONs are published one topic per loop pass rather than as one back-to-back TLS burst.
5. Temperature-config MQTT publish uses the already sampled DS18B20 values instead of starting four additional conversions. This keeps the app and TFT on the same sample and reduces background work.
6. MQTT reconnect attempts are throttled to 5 seconds so a lost broker cannot continuously stall the application loop.

## Logic intentionally unchanged

- Original AM2 safety/alarm order and status codes.
- HPS/LPS/OPS logic and 500 ms hold.
- Compressor feedback timeout.
- Monitor vs Control mode behavior.
- Relay polarity and PCF8574 mapping.
- Main 31-field JSON and pressure_config 22-field JSON schemas.
- Wi-Fi/AP provisioning source.
