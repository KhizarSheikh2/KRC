#include "NetworkPriority.h"
#include <cassert>
#include <iostream>
int main() {
  DxNetworkPriority n;
  using T = DxTransport;
  assert(n.select(false, false, 100) == T::NONE);           // no connection
  assert(n.select(false, true, 200) == T::WIFI);            // unplugged cable
  assert(n.select(false, true, 300) == T::WIFI);            // link up, no WAN/MQTT
  assert(n.select(true, true, 400) == T::WIFI);             // internet restored, guard
  assert(n.select(true, true, 1700) == T::WIFI);
  assert(n.select(true, true, 1900) == T::ETHERNET);        // Ethernet reclaims priority
  assert(n.select(true, false, 2000) == T::ETHERNET);       // Wi-Fi lost, ETH unaffected
  assert(n.select(false, true, 2100) == T::WIFI);           // Ethernet internet lost
  assert(n.select(false, false, 2200) == T::NONE);          // both disconnected
  assert(n.select(true, false, 2300) == T::NONE);           // require stable recovery
  assert(n.select(true, false, 3900) == T::ETHERNET);       // recover alone
  assert(n.select(false, true, 4000) == T::WIFI);           // cable unplugged
  assert(n.select(true, true, 0xfffffff0u) == T::WIFI);
  assert(n.select(true, true, 1600u) == T::ETHERNET);       // rollover safe
  std::cout << "PASS: offline, WiFi fallback, WAN loss, Ethernet reclaim, wraparound\n";
}
