#include <iostream>
#include <cassert>
#include <cstdint>
#include <cmath>
using uint8_t=unsigned char;
using uint32_t=unsigned int;
#define RELAY_SWITCH_DELAY 5000UL
#define TEMP_HYSTERESIS 0.5f
#define EVAP_COOL_SYSTEM 0
#define AUTO_WASH_SYSTEM 1
#define UNIT_COMMAND 2
#define SENSOR_DISCONNECTED 888
#define SENSOR_NOT_SELECTED 999
bool PowerState=true;
int MODE_SWITCH=0, timeschen=0, tmatched=0;
int EVAP_COOL_SYSTEM_SWITCH=0, AUTO_WASH_SYSTEM_SWITCH=0, UNIT_COMMAND_SWITCH=0;
bool EVAP_COOL_SYSTEM_STATUS=false, AUTO_WASH_SYSTEM_STATUS=false, UNIT_COMMAND_STATUS=false;
int EVAP_COOL_SYSTEM_PENDING=-1,AUTO_WASH_SYSTEM_PENDING=-1,UNIT_COMMAND_PENDING=-1;
unsigned long evapCoolPendingTime=0,autoWashPendingTime=0,unitCmdPendingTime=0;
float dischargeTemp=20;
int dischargeSp=30;
int SYSTEM_STATUS=0, FAULT_SWITCH=0;
bool PCFready=true;
bool outputs[3]={false,false,false};
uint32_t fakeTime=1;
uint32_t millis() {return fakeTime;}
bool pcfRelayReady() {return PCFready;}
void pcfRelayAllOff() {outputs[0]=outputs[1]=outputs[2]=false;}
bool writeRelay(uint8_t idx,bool on) {if(!PCFready)return false;outputs[idx]=on;return true;}
bool logicalTempValid(float v) {return std::isfinite(v) && v!=888.0f && v!=999.0f;}
void updateDisplay(){}
struct {void begin(const char*,bool){} void putInt(const char*,int){} void end(){}} preferences;
struct {template<class...T> void printf(const char*,T...){} } Serial;
void runScheduler(){}
// All actual outputs are owned by this single controller path. Hardware
// states are updated ONLY after the PCF8574 acknowledges a full-byte write.
// Confirmation applies to normal changes; wash is a safety override and
// immediately forces P0 EVAP and P2 UNIT OFF before any wash ON request.
namespace {
bool applyImmediateOff(uint8_t channel, bool &state, int &pending, int &command) {
  command = 0;
  pending = -1;
  const bool ack = writeRelay(channel, false);
  if (ack) state = false;
  return ack;
}

void runFiveSecondOutput(uint8_t channel, int requested, bool &state,
                         int &pending, unsigned long &started, const char *name) {
  const bool desired = requested != 0;
  if (desired == state) { pending = -1; return; }
  if (!pcfRelayReady()) { pending = -1; return; }
  if (pending != static_cast<int>(desired)) {
    pending = desired ? 1 : 0;
    started = millis();
    return;
  }
  if (millis() - started < RELAY_SWITCH_DELAY) return;
  if (writeRelay(channel, desired)) {
    state = desired;
    pending = -1;
    Serial.printf("[PCF-RELAY] %s P%u -> %s\n", name, channel, desired ? "ON" : "OFF");
    updateDisplay();
  }
}

void setAutoEvapDemand() {
  const bool valid = logicalTempValid(dischargeTemp);
  if (!valid) { EVAP_COOL_SYSTEM_SWITCH = 0; return; }
  if (dischargeTemp >= static_cast<float>(dischargeSp) + TEMP_HYSTERESIS) {
    EVAP_COOL_SYSTEM_SWITCH = 1;
  } else if (dischargeTemp <= static_cast<float>(dischargeSp) - TEMP_HYSTERESIS) {
    EVAP_COOL_SYSTEM_SWITCH = 0;
  }
  // Hysteresis: otherwise retain last demand.
}
} // namespace

void serviceRelayController() {
  if (!pcfRelayReady()) {
    // External I2C ACK lost: do not claim a verified physical relay state.
    EVAP_COOL_SYSTEM_STATUS = false;
    AUTO_WASH_SYSTEM_STATUS = false;
    UNIT_COMMAND_STATUS = false;
    EVAP_COOL_SYSTEM_PENDING = AUTO_WASH_SYSTEM_PENDING = UNIT_COMMAND_PENDING = -1;
    FAULT_SWITCH = 1;
    // I2C fault requires deliberate power-cycle/acknowledgement, not
    // re-energizing relays automatically on PCF recovery.
    PowerState = false;
    return;
  }

  if (!PowerState) {
    pcfRelayAllOff();
    EVAP_COOL_SYSTEM_STATUS = AUTO_WASH_SYSTEM_STATUS = UNIT_COMMAND_STATUS = false;
    EVAP_COOL_SYSTEM_PENDING = AUTO_WASH_SYSTEM_PENDING = UNIT_COMMAND_PENDING = -1;
    SYSTEM_STATUS = 0;
    return;
  }

  if (MODE_SWITCH != 0) {
    runScheduler();
    AUTO_WASH_SYSTEM_SWITCH = (timeschen && tmatched) ? 1 : 0;
    // The original AUTO behavior requests UNIT ON outside wash windows.
    UNIT_COMMAND_SWITCH = AUTO_WASH_SYSTEM_SWITCH ? 0 : 1;
    setAutoEvapDemand();
  } else if (timeschen != 0) {
    timeschen = 0;
    tmatched = 0;
    preferences.begin("timeenable", false);
    preferences.putInt("timeschen", 0);
    preferences.end();
  }

  // Protect output hardware throughout wash ON, wash OFF delay, and a new
  // wash ON request. No other output may turn ON until wash is physically OFF.
  const bool washInterlocked = AUTO_WASH_SYSTEM_SWITCH != 0 || AUTO_WASH_SYSTEM_STATUS;
  if (washInterlocked) {
    const bool evapOff = applyImmediateOff(EVAP_COOL_SYSTEM, EVAP_COOL_SYSTEM_STATUS,
                                          EVAP_COOL_SYSTEM_PENDING, EVAP_COOL_SYSTEM_SWITCH);
    const bool unitOff = applyImmediateOff(UNIT_COMMAND, UNIT_COMMAND_STATUS,
                                          UNIT_COMMAND_PENDING, UNIT_COMMAND_SWITCH);
    SYSTEM_STATUS = 0;
    // Do not turn wash ON if either OFF command did not get an I2C ACK.
    if (!evapOff || !unitOff) {
      AUTO_WASH_SYSTEM_PENDING = -1;
      return;
    }
  }
  // Apply wash first, then re-evaluate its ACTUAL state. While it is ON,
  // no EVAP/UNIT transitions can be initiated by manual or auto logic.
  runFiveSecondOutput(AUTO_WASH_SYSTEM, AUTO_WASH_SYSTEM_SWITCH,
                      AUTO_WASH_SYSTEM_STATUS, AUTO_WASH_SYSTEM_PENDING,
                      autoWashPendingTime, "AUTO WASH");

  if (AUTO_WASH_SYSTEM_SWITCH || AUTO_WASH_SYSTEM_STATUS) return;

  // Post-wash AUTO mode may restart normal outputs only after P1 is OFF.
  if (MODE_SWITCH != 0) {
    UNIT_COMMAND_SWITCH = 1;
    setAutoEvapDemand();
  }
  runFiveSecondOutput(EVAP_COOL_SYSTEM, EVAP_COOL_SYSTEM_SWITCH,
                      EVAP_COOL_SYSTEM_STATUS, EVAP_COOL_SYSTEM_PENDING,
                      evapCoolPendingTime, "EVAP COOL");
  runFiveSecondOutput(UNIT_COMMAND, UNIT_COMMAND_SWITCH,
                      UNIT_COMMAND_STATUS, UNIT_COMMAND_PENDING,
                      unitCmdPendingTime, "UNIT COMMAND");
  SYSTEM_STATUS = EVAP_COOL_SYSTEM_STATUS ? 1 : 0;
}

void tick(uint32_t t) {fakeTime=t; serviceRelayController();assert(!(outputs[1] && (outputs[0] || outputs[2])));}
int main() {
  EVAP_COOL_SYSTEM_SWITCH=UNIT_COMMAND_SWITCH=1;
  tick(1); assert(!outputs[0]&&!outputs[2]);
  tick(5002); assert(outputs[0] && outputs[2] && !outputs[1]);
  AUTO_WASH_SYSTEM_SWITCH=1;
  tick(5100); assert(!outputs[0]&&!outputs[2]&&!outputs[1]);
  tick(10100); assert(outputs[1]&&!outputs[0]&&!outputs[2]);
  EVAP_COOL_SYSTEM_SWITCH=UNIT_COMMAND_SWITCH=1;
  tick(11100); assert(!outputs[0]&&!outputs[2]&&outputs[1]);
  AUTO_WASH_SYSTEM_SWITCH=0;
  tick(11200); assert(outputs[1]);
  tick(16200); assert(!outputs[1]&&!outputs[0]&&!outputs[2]);
  EVAP_COOL_SYSTEM_SWITCH=1;
  tick(16300);tick(21300);assert(outputs[0]);
  PCFready=false;tick(21400); assert(!PowerState&&FAULT_SWITCH==1);
  std::cout << "PASS: 5-s relay confirmation, wash-first interlock, wash-off hold, I2C fault latch" << std::endl;
}
