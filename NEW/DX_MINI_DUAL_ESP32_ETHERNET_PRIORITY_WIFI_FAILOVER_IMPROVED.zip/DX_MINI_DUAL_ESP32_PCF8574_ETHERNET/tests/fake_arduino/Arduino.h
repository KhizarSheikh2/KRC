#pragma once
#include <string>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <deque>
#include <algorithm>
class String : public std::string {
 public:
  using std::string::string;
  String(const std::string& s):std::string(s){}
  int indexOf(char c) const {auto i=find(c);return i==npos ? -1 : static_cast<int>(i);}
};
class HardwareSerial {
 public:
  std::deque<uint8_t> received;
  std::string outgoing;
  int available(){return static_cast<int>(received.size());}
  int read(){int c=received.front();received.pop_front();return c;}
  size_t write(uint8_t c){outgoing.push_back(static_cast<char>(c));return 1;}
  size_t write(const uint8_t* p,size_t n){outgoing.append((const char*)p,n);return n;}
  void feed(const std::string& s){for(auto c:s)received.push_back(static_cast<uint8_t>(c));}
};
