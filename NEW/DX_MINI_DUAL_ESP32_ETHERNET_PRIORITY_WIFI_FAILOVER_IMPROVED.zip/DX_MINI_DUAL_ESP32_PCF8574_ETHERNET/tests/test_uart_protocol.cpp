#include "BridgeProtocol.h"
#include <cassert>
#include <iostream>
int main(){
 HardwareSerial tx,rx;
 auto send=[&](char k,const String& m){assert(DxLink::send(tx,k,m));};
 send('B',R"({"mqtt":true,"link":true})");
 send('M',"/test/DXM-AAA001/1\t{\"r2Sw\":\"1\"}");
 auto good=tx.outgoing;
 auto bad=good;bad[11]='X';
 DxLink::Parser parser;
 int n=0;
 rx.feed(bad);parser.poll(rx,[&](char,const String&){++n;});
 assert(n==1); // the second frame is intact
 n=0;rx.feed(good);
 parser.poll(rx,[&](char type, const String& payload){
  ++n;if(n==1){assert(type=='B');assert(payload==R"({"mqtt":true,"link":true})");}
  else assert(type=='M');
 });
 assert(n==2);
 std::cout<<"PASS: UART CRC16 framing, MQTT payload, corruption discard\n";
}
