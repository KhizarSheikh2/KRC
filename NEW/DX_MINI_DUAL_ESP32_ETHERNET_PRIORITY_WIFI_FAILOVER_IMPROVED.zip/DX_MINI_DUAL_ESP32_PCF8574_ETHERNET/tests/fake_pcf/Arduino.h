#pragma once
#include <cstdint>
#include <cstdio>
constexpr uint8_t LOW = 0;
constexpr uint8_t HIGH = 1;
extern uint32_t fakeMillis;
inline uint32_t millis() { return fakeMillis; }
struct FakeSerial {
  template <typename... Args>
  void printf(const char*, Args...) {}
  void println(const char*) {}
};
extern FakeSerial Serial;
