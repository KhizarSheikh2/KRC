#pragma once
#include <cstdint>
#include <vector>
extern bool fakeAck;
extern std::vector<uint8_t> i2cWrites;
class TwoWire {
  uint8_t staged = 0;
 public:
  explicit TwoWire(int) {}
  bool begin(int, int, uint32_t) {return true;}
  void setTimeOut(uint16_t) {}
  void beginTransmission(uint8_t address) { if (address != 0x20) __builtin_trap(); }
  size_t write(uint8_t value) { staged=value; return 1; }
  uint8_t endTransmission() {
    if (!fakeAck) return 4;
    i2cWrites.push_back(staged);
    return 0;
  }
};
