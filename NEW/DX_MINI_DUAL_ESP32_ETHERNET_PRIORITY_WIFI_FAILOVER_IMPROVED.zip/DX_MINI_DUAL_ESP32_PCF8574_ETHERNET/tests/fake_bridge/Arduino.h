#pragma once
#include <string>
#include <deque>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
class String : public std::string {
public:
  using std::string::string;
  String(const std::string &other) : std::string(other) {}
  explicit String(uint32_t n) : std::string(std::to_string(n)) {}
  int indexOf(char c) const { auto i=find(c); return i==npos?-1:static_cast<int>(i); }
  String substring(size_t from) const {return String(substr(from));}
  String substring(size_t from,size_t to) const {return String(substr(from,to-from));}
};
class HardwareSerial {
public:
  std::deque<uint8_t> received;
  std::string outgoing;
  void setRxBufferSize(size_t){}
  void setTxBufferSize(size_t){}
  void begin(int,int,int,int){}
  int available(){return (int)received.size();}
  int read(){int n=received.front();received.pop_front();return n;}
  size_t write(uint8_t c){outgoing.push_back((char)c);return 1;}
  size_t write(const uint8_t *p,size_t n){outgoing.append((const char *)p,n);return n;}
  void feed(const std::string &v){for(char c:v)received.push_back((uint8_t)c);}
};
struct Logger {
 template<class ...Args> void printf(const char *, Args ...) {}
 void println(const char *) {}
};
extern Logger Serial;
extern HardwareSerial Serial2;
extern uint32_t fakeMillis;
inline uint32_t millis(){return fakeMillis;}
inline uint32_t esp_random(){return 1234000;}
#define SERIAL_8N1 0
struct FakeJsonValue {
 template<typename T> T operator|(T def) const {return def;}
 template<typename T> T as() const {return T{};}
};
template<size_t N> struct StaticJsonDocument {
 FakeJsonValue operator[](const char*) const {return {};}
};
template<size_t N> bool deserializeJson(StaticJsonDocument<N>&, const String&) {return true;}
