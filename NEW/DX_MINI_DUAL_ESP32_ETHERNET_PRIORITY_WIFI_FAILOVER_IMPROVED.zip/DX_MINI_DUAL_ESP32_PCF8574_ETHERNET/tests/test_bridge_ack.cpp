#include <Arduino.h>
#include "NetworkPriority.h"
#include <cassert>
#include <iostream>
Logger Serial;
HardwareSerial Serial2;
uint32_t fakeMillis = 100;
constexpr int BRIDGE_BAUD=230400;
constexpr int BRIDGE_UART_RX=16;
constexpr int BRIDGE_UART_TX=17;
bool bridge_mqtt_up=true;
uint32_t bridge_last_status_ms=100;
bool eth_connected=false;
bool w5500_detected=false;
bool ethernetLinkPresent=false;
bool ethernet_using_dhcp=false;
String ethernetIpAddress;
String ethernetMacAddress;
using NetworkTransport = DxTransport;
DxTransport activeNetwork=DxTransport::ETHERNET;
void bridgeOnMqttMessage(const String&,const String&){}
#include "BridgeUart.h"

std::string frame(char type,const String& text){
  HardwareSerial wire;
  assert(DxLink::send(wire,type,text));
  return wire.outgoing;
}
String currentSeq(){
  HardwareSerial wire;
  DxLink::Parser parser;
  wire.feed(Serial2.outgoing);
  String id;
  parser.poll(wire,[&](char type,const String& p){
    if(type=='P' && id.empty()) id=p.substring(0,p.indexOf('|'));
  });
  return id;
}
int main(){
  bridgeInit();
  bridgeLastAckMs=100;
  assert(bridgeMqttReady());
  assert(bridgePublish("/KRC/DXM-AAA001", "{\"network\":\"ETHERNET\"}"));
  assert(bridgeQueueSize==1);
  const String firstId = currentSeq();
  assert(!firstId.empty());
  assert(bridgePublish("/KRC/DXM-AAA001/temperature_config_DXM","{\"temp1\":30}"));
  assert(bridgeQueueSize==2);
  Serial2.feed(frame('R',firstId+"|1"));
  fakeMillis+=100;
  bridgePoll();
  assert(bridgeQueueSize==1);
  const String secondId = currentSeq();
  assert(secondId==firstId); // scan gives first, need extract new by scanning frames
  // After timeout, retransmission occurs and negative R must force fallback.
  fakeMillis+=2600;
  bridgePoll();
  assert(bridgeQueueSize==1);
  // First is already acknowledged, and a negative ACK is for the second.
  const uint32_t second=bridgePending[bridgeQueueHead].seq;
  Serial2.feed(frame('R',String(second)+"|0"));
  fakeMillis+=100;
  bridgePoll();
  assert(bridgeQueueSize==0);
  assert(!bridgeMqttReady());
  fakeMillis+=11000;
  bridge_last_status_ms=fakeMillis;
  bridgeLastAckMs=fakeMillis;
  assert(bridgeMqttReady());
  std::cout<<"PASS: UART publish queue ACK, delivery confirmation, failure fallback, retry guard\n";
}
