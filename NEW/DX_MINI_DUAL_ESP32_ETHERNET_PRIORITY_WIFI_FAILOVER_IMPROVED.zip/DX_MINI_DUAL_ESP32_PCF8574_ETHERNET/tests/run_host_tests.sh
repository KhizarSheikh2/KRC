#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
# Extract exact production macros and function definitions from Def.h.
python3 - "$ROOT" "$TMP" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1]); tmp=Path(sys.argv[2])
t=(root/'01_DISPLAY_MAIN_ESP32/include/Def.h').read_text()
a=t.index('#define RELAY_ACTIVE_LOW ')
b=t.index('// Buzzer pin.',a)
(tmp/'RelayMappingExtract.h').write_text(t[a:b])
PY
SRC="$ROOT/01_DISPLAY_MAIN_ESP32"
g++ -std=c++17 -Wall -Wextra -Werror -I"$ROOT/tests/fake_pcf" -I"$SRC/include" -I"$TMP" \
  "$ROOT/tests/test_pcf_relay_polarity.cpp" "$SRC/src/PCFRelays.cpp" -o "$TMP/test_pcf"
"$TMP/test_pcf"
g++ -std=c++17 -Wall -Wextra "$ROOT/tests/test_relay_controller.cpp" -o "$TMP/test_interlock"
"$TMP/test_interlock"
g++ -std=c++17 -Wall -Wextra -I"$ROOT/tests/fake_arduino" -I"$ROOT/01_DISPLAY_MAIN_ESP32/include" \
  "$ROOT/tests/test_uart_protocol.cpp" -o "$TMP/test_uart"
"$TMP/test_uart"
g++ -std=c++17 -Wall -Wextra -Werror -I"$SRC/include" \
  "$ROOT/tests/test_network_priority.cpp" -o "$TMP/test_network"
"$TMP/test_network"
g++ -std=c++17 -Wall -Wextra -Werror -I"$ROOT/tests/fake_bridge" -I"$SRC/include" \
  "$ROOT/tests/test_bridge_ack.cpp" -o "$TMP/test_bridge_ack"
"$TMP/test_bridge_ack"
