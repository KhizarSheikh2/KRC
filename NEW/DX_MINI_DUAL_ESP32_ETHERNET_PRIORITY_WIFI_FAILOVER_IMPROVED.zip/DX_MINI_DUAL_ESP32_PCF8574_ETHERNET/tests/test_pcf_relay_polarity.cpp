// Compile PCFRelays.cpp itself against mock I2C and extract the REAL relay
// mapping from Def.h to avoid accidentally testing a duplicated formula.
#include <Arduino.h>
#include <Wire.h>
#include <cassert>
#include <iostream>
uint32_t fakeMillis = 100;
bool fakeAck = true;
std::vector<uint8_t> i2cWrites;
FakeSerial Serial;
#include "PCFRelays.h"
#include "RelayMappingExtract.h"

void check(uint8_t expected) {
  assert(!i2cWrites.empty());
  if (i2cWrites.back() != expected) {
    std::cerr << "Wrong PCF value: got " << (int)i2cWrites.back()
              << ", expected " << (int)expected << "\n";
    std::abort();
  }
}

int main() {
  static_assert(RELAY_ACTIVE_LOW, "This hardware has active-LOW relay inputs");
  assert(pcfRelayBegin());
  check(0xFF);                               // all inactive at boot
  assert(writeRelay(0, true)); check(0xFE);   // P0 energizes
  assert(writeRelay(0, false));check(0xFF);  // P0 releases
  assert(writeRelay(1, true)); check(0xFD);   // P1 energizes
  assert(writeRelay(1, false));check(0xFF);  // P1 releases
  assert(writeRelay(2, true)); check(0xFB);   // P2 energizes
  assert(writeRelay(2, false));check(0xFF);  // P2 releases
  assert(writeRelay(0, true)); check(0xFE);
  assert(writeRelay(2, true)); check(0xFA);  // evap+unit (normal)
  assert(writeRelay(0, false)); check(0xFB);
  assert(writeRelay(2, false)); check(0xFF);
  assert(writeRelay(1, true)); check(0xFD);
  pcfRelayAllOff(); check(0xFF);              // forced safe state
  assert(!pcfRelayWrite(3, false)); check(0xFF);
  assert(writeRelay(1, true)); check(0xFD);
  fakeAck = false;
  fakeMillis += 1001;
  pcfRelayService();
  assert(!pcfRelayReady());                   // ACK lost
  assert(!writeRelay(0,true));               // cannot write
  fakeAck = true;
  fakeMillis += 2001;
  pcfRelayService(); check(0xFF);            // recovered in OFF state
  assert(pcfRelayReady());
  assert(writeRelay(1,true)); check(0xFD);    // normal operations resume
  std::cout << "PASS: active-LOW P0/P1/P2, boot OFF, forced OFF, I2C recovery OFF\n";
}
