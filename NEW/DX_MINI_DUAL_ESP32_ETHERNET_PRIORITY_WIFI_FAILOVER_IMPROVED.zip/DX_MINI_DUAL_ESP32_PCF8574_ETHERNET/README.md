# DX-Mini: Dual ESP32, PCF8574, Ethernet Priority + Wi-Fi Failover

**Revision:** 2026-10-14. Main controller JC2432W328 + independent Ethernet W5500 ESP32.

## Projects
- `01_DISPLAY_MAIN_ESP32/`: primary DX-Mini logic, LVGL display, DS18B20, PCF8574 active-LOW relays, manual/auto logic, Wi-Fi internet + AWS IoT MQTT, UART transport priority.
- `02_W5500_ETHERNET_ESP32/`: W5500 SPI + EthernetLarge/SSLClient AWS IoT MQTT and UART bridge; NEVER drives relays.
- `tests/`: host C++ logic tests for relay polarity/safety, UART integrity and priority transitions.

### Priority rules
1. **Ethernet ONLINE** means its own TLS MQTT connection is authenticated and subscribed to the app topics, plus recent UART status/echo confirmation. A cable and LAN DHCP alone are not proof of cloud availability. After 1.5 seconds of healthy reports, use Ethernet for JSON and MQTT inbound app commands.
2. **Ethernet cable attached, no WAN or broker unreachable:** maintain Wi-Fi station and its separate MQTT session. Publish/receive exclusively on Wi-Fi while Ethernet MQTT is down; keep checking Ethernet in the background on ESP32 #2.
3. **Ethernet internet restored:** Ethernet bridge reconnects MQTT and sends health heartbeat. The display automatically switches back after a short recovery guard and immediately publishes both retained runtime and sensor-config snapshots over Ethernet.
4. **Ethernet unplugged:** UART reports the loss, and the main device switches to already-connected Wi-Fi MQTT. If the bridge itself disappears, a 3.5 s heartbeat expiration also triggers fallback.
5. **Both MQTT transports unavailable:** UI indicates OFFLINE; relay control, temperatures, scheduler and local touchscreen functions continue on the main ESP32. The system will retry connectivity.

Wi-Fi stays provisioned and connected while Ethernet is preferred. Wi-Fi MQTT standby remains connected where possible. Only ONE of the transports sends active cloud reports or processes inbound app commands. Distinct AWS MQTT client IDs: `DXM-AAA001-wifi` and `DXM-AAA001-eth`.

### JSON publishing reliability
Ethernet publication frames now use sequence identifiers and CRC-16; an `R` response is emitted by ESP32 #2 after calling `mqtt.publish()`. ESP32 #1 keeps a bounded transmit queue with acknowledgement timeout and 2 attempts; duplicate frame IDs are suppressed by ESP32 #2. An unconfirmed Ethernet publish degrades Ethernet temporarily, allowing Wi-Fi fallback. The fresh retained runtime/config snapshots are published on each route change. This is still **MQTT QoS 0**: a successful MQTT client `publish` means accepted by the client for sending, NOT proof that AWS persisted the message. For guaranteed broker delivery you need QoS 1 with PUBACK tracking and/or nonvolatile message buffering.

### Cloud and hardware prerequisites
- The AWS IoT policy attached to the client certificate must grant `iot:Connect` to BOTH suffixed client IDs and allow `iot:Subscribe`, `iot:Receive`, `iot:Publish` for the original device topics. Otherwise one or both transports will never reach ONLINE even if the router works. AWS region and endpoint must match both firmwares.
- `EthernetLarge@2.0.0` (modified for large W5500 socket buffers) is intentionally paired with `SSLClient@1.6.11`. Neither is the standard Arduino Ethernet library. See https://github.com/OPEnSLab-OSU/SSLClient#sslclient-with-ethernet.
- The ESP32 #2 hardware must be powered and communicating over crossed 3.3 V UART. Configure the same `DXM-AAA001` on both boards and set W5500_RESET according to the actual wiring.
- See `WIRING_AND_SAFETY.md` for exact GPIO and PCF output polarity. Device certificates and private keys are bundled; keep this project private and rotate any exposed credentials.

### Verification limitations
The supplied host tests pass; source/topic/protocol consistency was checked. **This is NOT a validated real-hardware build**. PlatformIO and ESP32 toolchains were unavailable in this environment, and no live W5500, DNS, TLS, AWS IoT or cable-pull tests were performed. Both PlatformIO projects MUST compile/upload and pass the hardware acceptance procedure in `ETHERNET_FAILOVER_TEST_PLAN.md` before field use.

### Safety note
The main ESP32 still performs Wi-Fi TLS reconnect calls from its main loop. These can block briefly during unstable Wi-Fi/Internet; therefore relay control deadlines should not be represented as hard real-time safety guarantees. Keep hardware contactor interlocks and independent electrical safety limits, especially Auto Wash vs Unit/Evap.

ESP32 #2 includes a 45 s task watchdog to reset and reprobe the Ethernet module if its TLS/network loop hangs. During this restart, the main ESP32 falls back to Wi-Fi once the bridge heartbeat expires.
