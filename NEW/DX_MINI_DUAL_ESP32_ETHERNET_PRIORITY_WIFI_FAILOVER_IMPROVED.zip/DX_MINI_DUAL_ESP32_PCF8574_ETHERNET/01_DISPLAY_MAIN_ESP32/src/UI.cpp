#include <Arduino.h>
#include <cstring>
#include <WiFi.h>
#include <TFT_eSPI.h>
#include <lvgl.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <esp_heap_caps.h>
#include <math.h>
#include <string.h>

#include "UI.h"
#include "DisplayConfig.h"
#include "CST820Touch.h"
#include "NetworkPriority.h"

// Controller state is owned by the original DX-Mini firmware (Def.h in main.cpp).
// These extern declarations let the UI observe that state without redefining it.
extern bool PowerState;
extern bool dischargeTempAlarm;
extern bool returnTempAlarm;
extern bool EVAP_COOL_SYSTEM_STATUS;
extern bool AUTO_WASH_SYSTEM_STATUS;
extern bool UNIT_COMMAND_STATUS;
extern float SupplyTemp;
extern float ReturnTemp;
extern float dischargeTemp;
extern int dischargeSp;
extern int ReturnSp;
extern int EVAP_COOL_SYSTEM_SWITCH;
extern int AUTO_WASH_SYSTEM_SWITCH;
extern int UNIT_COMMAND_SWITCH;
extern int FAULT_SWITCH;
extern int MODE_SWITCH;
extern String devicename;
extern String ssid;
extern String myIP;
extern bool eth_connected;
extern DxTransport activeNetwork;
extern bool w5500_detected;

namespace {
constexpr int UI_W = DX_UI_WIDTH;
constexpr int UI_H = DX_UI_HEIGHT;
constexpr float SENSOR_DISCONNECTED_VALUE = 888.0f;
constexpr float SENSOR_NOT_SELECTED_VALUE = 999.0f;

enum UiPage : uint8_t { PAGE_HOME = 0, PAGE_TEMPS, PAGE_OUTPUTS, PAGE_SETTINGS };

TFT_eSPI tft;
CST820Touch touch(TOUCH_SDA, TOUCH_SCL, TOUCH_RST, TOUCH_INT, TOUCH_I2C_ADDR);
lv_disp_draw_buf_t drawBuf;
lv_color_t *drawMem = nullptr;
uint16_t drawBufferLines = 0;
lv_disp_drv_t dispDrv;
lv_indev_drv_t indevDrv;

lv_point_t lastTouchPoint{0, 0};
bool touchContactLatched = false;
uint32_t lastValidTouchMs = 0;
constexpr uint32_t TOUCH_RELEASE_GRACE_MS = 55;
#if DX_TOUCH_DEBUG
uint32_t lastTouchDebugMs = 0;
#endif
uint32_t lastLvTick = 0;
uint32_t lastUiRefresh = 0;
uint32_t lastActionMs = 0;
uint32_t toastUntil = 0;
uint32_t splashVisibleSince = 0;

// LVGL/TFT are serviced only by this dedicated task after uiInit().
// This keeps the HMI alive even if MQTT TLS, NTP or Wi-Fi work blocks loop().
TaskHandle_t uiTaskHandle = nullptr;
QueueHandle_t actionQueue = nullptr;
QueueHandle_t bootQueue = nullptr;
QueueHandle_t toastQueue = nullptr;
volatile bool uiDirtyRequested = true;
volatile bool mainScreenRequested = false;
volatile bool mainScreenVisible = false;

struct BootMessage {
  int value;
  char status[32];
};

struct ToastMessage {
  uint32_t durationMs;
  char text[40];
};

struct UiRuntimeSnapshot {
  bool power;
  uint8_t network; // 0=offline, 1=WiFi, 2=Ethernet
  bool dischargeAlarm;
  bool returnAlarm;
  bool evapStatus;
  bool washStatus;
  bool unitStatus;
  int mode;
  int dischargeSetpoint;
  int returnSetpoint;
  int evapCommand;
  int washCommand;
  int unitCommand;
  int16_t discharge10;
  int16_t return10;
  int16_t supply10;
  uint8_t page;
};

UiRuntimeSnapshot lastSnapshot{};
bool haveSnapshot = false;
uint32_t lastStatePoll = 0;

UiPage activePage = PAGE_HOME;
uint8_t selectedTemp = 0; // discharge, return, supply

lv_obj_t *screenSplash = nullptr;
lv_obj_t *screenMain = nullptr;
lv_obj_t *splashBar = nullptr;
lv_obj_t *splashStatus = nullptr;
lv_obj_t *pageHome = nullptr;
lv_obj_t *pageTemps = nullptr;
lv_obj_t *pageOutputs = nullptr;
lv_obj_t *pageSettings = nullptr;

// Header
lv_obj_t *lblContext = nullptr;
lv_obj_t *chipPower = nullptr;
lv_obj_t *lblPower = nullptr;
lv_obj_t *chipWifi = nullptr;
lv_obj_t *lblWifi = nullptr;
lv_obj_t *chipMode = nullptr;
lv_obj_t *lblMode = nullptr;

// Home
lv_obj_t *outputCard[3] = {nullptr, nullptr, nullptr};
lv_obj_t *outputState[3] = {nullptr, nullptr, nullptr};
lv_obj_t *tempCard[3] = {nullptr, nullptr, nullptr};
lv_obj_t *tempValue[3] = {nullptr, nullptr, nullptr};
lv_obj_t *tempSub[3] = {nullptr, nullptr, nullptr};

// Temps page
lv_obj_t *tempPageValue[3] = {nullptr, nullptr, nullptr};
lv_obj_t *tempPageSet[2] = {nullptr, nullptr};

// Outputs page
lv_obj_t *outActual[3] = {nullptr, nullptr, nullptr};
lv_obj_t *outButton[3] = {nullptr, nullptr, nullptr};
lv_obj_t *outButtonText[3] = {nullptr, nullptr, nullptr};

// Settings
lv_obj_t *settingsDeviceId = nullptr;
lv_obj_t *settingsPower = nullptr;
lv_obj_t *settingsMode = nullptr;
lv_obj_t *settingsNetwork = nullptr;
lv_obj_t *settingsSsid = nullptr;

// Setpoint modal
lv_obj_t *setpointOverlay = nullptr;
lv_obj_t *setpointTitle = nullptr;
lv_obj_t *setpointCurrent = nullptr;
lv_obj_t *setpointSp = nullptr;
uint8_t setpointTarget = 0;

// AUTO -> MANUAL password modal
constexpr char MANUAL_MODE_PIN[] = "1234";
lv_obj_t *pinOverlay = nullptr;
lv_obj_t *pinDots = nullptr;
lv_obj_t *pinMessage = nullptr;
char pinEntry[5] = {0};
uint8_t pinLength = 0;

// Navigation
lv_obj_t *navBtn[4] = {nullptr, nullptr, nullptr, nullptr};
lv_obj_t *navText[4] = {nullptr, nullptr, nullptr, nullptr};
lv_obj_t *navLine[4] = {nullptr, nullptr, nullptr, nullptr};

// Display-side temperature hold cache. This keeps the UI stable if a read
// briefly returns SENSOR_DISCONNECTED / SENSOR_NOT_SELECTED for a cycle.
float displayedTemps[3] = {SENSOR_DISCONNECTED_VALUE, SENSOR_DISCONNECTED_VALUE, SENSOR_DISCONNECTED_VALUE};
bool displayedTempValid[3] = {false, false, false};

// Toast
lv_obj_t *toast = nullptr;
lv_obj_t *toastText = nullptr;

const lv_color_t C_BG = lv_color_hex(0x03080E);
const lv_color_t C_HEADER = lv_color_hex(0x07121D);
const lv_color_t C_PANEL = lv_color_hex(0x0A1724);
const lv_color_t C_PANEL2 = lv_color_hex(0x0D1C2B);
const lv_color_t C_PANEL3 = lv_color_hex(0x07131F);
const lv_color_t C_BORDER = lv_color_hex(0x244A67);
const lv_color_t C_BORDER_DIM = lv_color_hex(0x163249);
const lv_color_t C_TEXT = lv_color_hex(0xF4F8FC);
const lv_color_t C_MUTED = lv_color_hex(0xA6B9CB);
const lv_color_t C_DIM = lv_color_hex(0x60788E);
const lv_color_t C_CYAN = lv_color_hex(0x20D6FF);
const lv_color_t C_BLUE = lv_color_hex(0x3395FF);
const lv_color_t C_GREEN = lv_color_hex(0x38E58B);
const lv_color_t C_AMBER = lv_color_hex(0xF3C968);
const lv_color_t C_RED = lv_color_hex(0xFF6172);

void base(lv_obj_t *obj) {
  lv_obj_set_style_pad_all(obj, 0, LV_PART_MAIN);
  lv_obj_set_style_shadow_width(obj, 0, LV_PART_MAIN);
  lv_obj_clear_flag(obj, LV_OBJ_FLAG_SCROLLABLE);
}

void bg(lv_obj_t *obj, lv_color_t color) {
  lv_obj_set_style_bg_color(obj, color, LV_PART_MAIN);
  lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, LV_PART_MAIN);
}

void panel(lv_obj_t *obj, lv_color_t fill, lv_color_t border, int radius = 8, int borderWidth = 1) {
  base(obj);
  bg(obj, fill);
  lv_obj_set_style_border_color(obj, border, LV_PART_MAIN);
  lv_obj_set_style_border_width(obj, borderWidth, LV_PART_MAIN);
  lv_obj_set_style_radius(obj, radius, LV_PART_MAIN);
}

lv_obj_t *label(lv_obj_t *parent, const char *text, const lv_font_t *font, lv_color_t color) {
  lv_obj_t *obj = lv_label_create(parent);
  lv_label_set_text(obj, text);
  lv_obj_set_style_text_font(obj, font, LV_PART_MAIN);
  lv_obj_set_style_text_color(obj, color, LV_PART_MAIN);
  return obj;
}

void setBorder(lv_obj_t *obj, lv_color_t color, int width = 1) {
  if (!obj) return;
  lv_obj_set_style_border_color(obj, color, LV_PART_MAIN);
  lv_obj_set_style_border_width(obj, width, LV_PART_MAIN);
}

bool validTemp(float value) {
  return isfinite(value) && value != SENSOR_DISCONNECTED_VALUE && value != SENSOR_NOT_SELECTED_VALUE;
}

float uiTempForDisplay(uint8_t index, float liveValue) {
  if (index > 2) return liveValue;
  if (validTemp(liveValue)) {
    displayedTemps[index] = liveValue;
    displayedTempValid[index] = true;
    return liveValue;
  }
  if (displayedTempValid[index]) return displayedTemps[index];
  return liveValue;
}

void formatTemp(char *out, size_t outLen, float value, uint8_t decimals = 1, bool includeUnit = false) {
  if (!out || outLen == 0) return;
  if (!validTemp(value)) {
    snprintf(out, outLen, "---%s", includeUnit ? " C" : "");
    return;
  }
  snprintf(out, outLen, includeUnit ? "%.*f C" : "%.*f", static_cast<int>(decimals), value);
}

void wakeUiTask() {
  if (uiTaskHandle) xTaskNotifyGive(uiTaskHandle);
}

void requestUiRefresh() {
  uiDirtyRequested = true;
  wakeUiTask();
}

void queueAction(UiAction action) {
  if (action == UI_ACTION_NONE || !actionQueue) return;
  const uint32_t now = millis();
  if (now - lastActionMs < 35) return;
  lastActionMs = now;

  // Queue actions instead of keeping a single pending slot. This prevents
  // quick valid taps from being lost while the controller loop is busy.
  (void)xQueueSend(actionQueue, &action, 0);
}

void actionEvent(lv_event_t *e) {
  const lv_event_code_t code = lv_event_get_code(e);
  if (code != LV_EVENT_PRESSED && code != LV_EVENT_LONG_PRESSED_REPEAT) return;
  queueAction((UiAction)(intptr_t)lv_event_get_user_data(e));
}

lv_obj_t *touchButton(lv_obj_t *parent, int x, int y, int w, int h,
                      const char *text, const lv_font_t *font,
                      lv_color_t accent, UiAction action, int radius = 8,
                      bool allowRepeat = false) {
  lv_obj_t *btn = lv_btn_create(parent);
  lv_obj_set_pos(btn, x, y);
  lv_obj_set_size(btn, w, h);
  panel(btn, C_PANEL3, accent, radius, 1);
  lv_obj_set_style_bg_color(btn, C_PANEL2, LV_STATE_PRESSED);
  lv_obj_set_style_border_color(btn, C_TEXT, LV_STATE_PRESSED);
  lv_obj_add_event_cb(btn, actionEvent, LV_EVENT_PRESSED, (void *)(intptr_t)action);
  if (allowRepeat) lv_obj_add_event_cb(btn, actionEvent, LV_EVENT_LONG_PRESSED_REPEAT, (void *)(intptr_t)action);
  lv_obj_t *txt = label(btn, text, font, accent);
  lv_obj_center(txt);
  return btn;
}

void setEnabledVisual(lv_obj_t *obj, bool enabled) {
  if (!obj) return;
  lv_obj_set_style_opa(obj, enabled ? LV_OPA_COVER : LV_OPA_80, LV_PART_MAIN);
}

bool allocateDrawBuffer() {
  // Keep the LVGL draw buffer off static .bss so the ESP32 linker retains
  // enough DRAM for Wi-Fi/TLS and the original DX-Mini globals.  The Water
  // Tank reference uses a 20-line buffer; DX-Mini uses a 16-line preferred
  // buffer with automatic fallbacks because TLS/MQTT also needs internal RAM.
  // This cuts the number of SPI flushes versus the old 8-line buffer without
  // bringing back the earlier DRAM overflow.
  static constexpr uint16_t candidates[] = {12, 10, 8, 6};

  for (uint16_t lines : candidates) {
    const size_t bytes = static_cast<size_t>(UI_W) * lines * sizeof(lv_color_t);
    drawMem = static_cast<lv_color_t *>(
        heap_caps_malloc(bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT));
    if (drawMem != nullptr) {
      drawBufferLines = lines;
      Serial.printf("[DISPLAY] LVGL draw buffer: %u lines / %u bytes\n",
                    drawBufferLines, static_cast<unsigned>(bytes));
      return true;
    }
  }

  drawBufferLines = 0;
  Serial.println("[DISPLAY] ERROR: LVGL draw buffer allocation failed");
  return false;
}

void flushDisplay(lv_disp_drv_t *drv, const lv_area_t *area, lv_color_t *colorP) {
  const uint32_t w = (uint32_t)(area->x2 - area->x1 + 1);
  const uint32_t h = (uint32_t)(area->y2 - area->y1 + 1);
  tft.startWrite();
  tft.setAddrWindow(area->x1, area->y1, w, h);
  tft.pushColors(reinterpret_cast<uint16_t *>(&colorP->full), w * h, true);
  tft.endWrite();
  lv_disp_flush_ready(drv);
}

bool mapTouch(uint16_t rawX, uint16_t rawY, lv_point_t &point) {
  // CST820 is fixed in portrait coordinates even when the TFT is rendered in
  // landscape. Convert controller coordinates into LVGL's 320x240 frame.
  int x = static_cast<int>(rawX);
  int y = static_cast<int>(rawY);

#if DX_TOUCH_SWAP_XY
  const int tmp = x;
  x = y;
  y = tmp;
#endif

#if DX_TOUCH_INVERT_X
  x = (DX_UI_WIDTH - 1) - x;
#endif
#if DX_TOUCH_INVERT_Y
  y = (DX_UI_HEIGHT - 1) - y;
#endif

  x += DX_TOUCH_X_OFFSET;
  y += DX_TOUCH_Y_OFFSET;

  // Never clamp an invalid touch into the nearest widget. A bad sample must be
  // ignored; clamping is what can make an out-of-range touch activate another
  // button at an edge of the screen.
  if (x < 0 || x >= DX_UI_WIDTH || y < 0 || y >= DX_UI_HEIGHT) return false;

  point.x = static_cast<lv_coord_t>(x);
  point.y = static_cast<lv_coord_t>(y);
  return true;
}

void readTouch(lv_indev_drv_t *, lv_indev_data_t *data) {
  uint16_t rawX = 0, rawY = 0;
  const uint32_t now = millis();

  if (touch.read(rawX, rawY)) {
    lv_point_t mapped{};
    if (mapTouch(rawX, rawY, mapped)) {
      lastTouchPoint = mapped;
      lastValidTouchMs = now;
      touchContactLatched = true;
      data->point = lastTouchPoint;
      data->state = LV_INDEV_STATE_PR;
#if DX_TOUCH_DEBUG
      if (now - lastTouchDebugMs > 80) {
        lastTouchDebugMs = now;
        Serial.printf("[TOUCH] raw=(%u,%u) screen=(%d,%d)\n", rawX, rawY, lastTouchPoint.x, lastTouchPoint.y);
      }
#endif
      return;
    }
  }

  // The CST820 occasionally drops one sample while a finger is still down.
  // Keep the pointer PRESSED for a very short grace period so LVGL sees one
  // continuous contact instead of RELEASE -> PRESS -> RELEASE bouncing.
  if (touchContactLatched && (now - lastValidTouchMs) < TOUCH_RELEASE_GRACE_MS) {
    data->point = lastTouchPoint;
    data->state = LV_INDEV_STATE_PR;
    return;
  }

  touchContactLatched = false;
  data->point = lastTouchPoint;
  data->state = LV_INDEV_STATE_REL;
}

void showToast(const char *text, uint32_t ms = 800) {
  if (!toast || !toastText) return;
  lv_label_set_text(toastText, text);
  lv_obj_clear_flag(toast, LV_OBJ_FLAG_HIDDEN);
  lv_obj_move_foreground(toast);
  toastUntil = millis() + ms;
}

void pageEvent(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_PRESSED) return;
  activePage = (UiPage)(intptr_t)lv_event_get_user_data(e);
  lv_obj_add_flag(pageHome, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(pageTemps, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(pageOutputs, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(pageSettings, LV_OBJ_FLAG_HIDDEN);
  if (activePage == PAGE_HOME) lv_obj_clear_flag(pageHome, LV_OBJ_FLAG_HIDDEN);
  else if (activePage == PAGE_TEMPS) lv_obj_clear_flag(pageTemps, LV_OBJ_FLAG_HIDDEN);
  else if (activePage == PAGE_OUTPUTS) lv_obj_clear_flag(pageOutputs, LV_OBJ_FLAG_HIDDEN);
  else lv_obj_clear_flag(pageSettings, LV_OBJ_FLAG_HIDDEN);
  for (int i = 0; i < 4; ++i) {
    const bool selected = i == (int)activePage;
    lv_obj_set_style_text_color(navText[i], selected ? C_CYAN : C_MUTED, LV_PART_MAIN);
    bg(navLine[i], selected ? C_CYAN : C_HEADER);
  }
  updateDisplay();
}

void createSetpointDialog();
void createPinDialog();

void updatePinDots() {
  if (!pinDots) return;
  char dots[12] = {0};
  size_t pos = 0;
  for (uint8_t i = 0; i < 4; ++i) {
    const char c = i < pinLength ? '*' : '-';
    if (pos + 2 < sizeof(dots)) {
      dots[pos++] = c;
      if (i < 3) dots[pos++] = ' ';
    }
  }
  dots[pos] = '\0';
  lv_label_set_text(pinDots, dots);
}

void closeSetpointDialog(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_PRESSED || !setpointOverlay) return;
  lv_obj_add_flag(setpointOverlay, LV_OBJ_FLAG_HIDDEN);
}

void openSetpointDialog(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_PRESSED) return;
  const uint8_t target = (uint8_t)(intptr_t)lv_event_get_user_data(e);
  if (target > 1) return;  // Supply is monitor-only.
  if (!setpointOverlay) createSetpointDialog();
  if (!setpointOverlay) {
    Serial.println("[DISPLAY] ERROR: setpoint dialog allocation failed");
    return;
  }
  setpointTarget = target;
  selectedTemp = target;
  lv_obj_clear_flag(setpointOverlay, LV_OBJ_FLAG_HIDDEN);
  lv_obj_move_foreground(setpointOverlay);
  updateDisplay();
}

void setpointMinusEvent(lv_event_t *e) {
  const lv_event_code_t code = lv_event_get_code(e);
  if (code != LV_EVENT_PRESSED && code != LV_EVENT_LONG_PRESSED_REPEAT) return;
  queueAction(setpointTarget == 0 ? UI_ACTION_DISCHARGE_MINUS : UI_ACTION_RETURN_MINUS);
}

void setpointPlusEvent(lv_event_t *e) {
  const lv_event_code_t code = lv_event_get_code(e);
  if (code != LV_EVENT_PRESSED && code != LV_EVENT_LONG_PRESSED_REPEAT) return;
  queueAction(setpointTarget == 0 ? UI_ACTION_DISCHARGE_PLUS : UI_ACTION_RETURN_PLUS);
}

void closePinDialog() {
  pinLength = 0;
  pinEntry[0] = '\0';
  if (pinMessage) lv_label_set_text(pinMessage, "ENTER PIN");
  updatePinDots();
  if (pinOverlay) lv_obj_add_flag(pinOverlay, LV_OBJ_FLAG_HIDDEN);
}

void modeRequestEvent(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_PRESSED) return;

  // MANUAL -> AUTO is immediate. AUTO -> MANUAL is protected by PIN 1234.
  if (MODE_SWITCH == 0) {
    queueAction(UI_ACTION_TOGGLE_MODE);
    return;
  }

  if (!pinOverlay) createPinDialog();
  if (!pinOverlay) {
    Serial.println("[DISPLAY] ERROR: PIN dialog allocation failed");
    return;
  }
  pinLength = 0;
  pinEntry[0] = '\0';
  lv_label_set_text(pinMessage, "ENTER PIN");
  lv_obj_set_style_text_color(pinMessage, C_MUTED, LV_PART_MAIN);
  updatePinDots();
  lv_obj_clear_flag(pinOverlay, LV_OBJ_FLAG_HIDDEN);
  lv_obj_move_foreground(pinOverlay);
}

void pinKeyEvent(lv_event_t *e) {
  if (lv_event_get_code(e) != LV_EVENT_PRESSED) return;
  const intptr_t key = (intptr_t)lv_event_get_user_data(e);

  if (key >= 0 && key <= 9) {
    if (pinLength < 4) {
      pinEntry[pinLength++] = char('0' + key);
      pinEntry[pinLength] = '\0';
      lv_label_set_text(pinMessage, "ENTER PIN");
      lv_obj_set_style_text_color(pinMessage, C_MUTED, LV_PART_MAIN);
      updatePinDots();
    }
    return;
  }

  if (key == -1) {  // backspace
    if (pinLength > 0) {
      --pinLength;
      pinEntry[pinLength] = '\0';
      updatePinDots();
    }
    return;
  }

  if (key == -3) {  // cancel
    closePinDialog();
    return;
  }

  if (key == -2) {  // OK
    if (pinLength == 4 && strcmp(pinEntry, MANUAL_MODE_PIN) == 0) {
      closePinDialog();
      // Only request AUTO -> MANUAL. If the mode changed elsewhere while the
      // dialog was open, never invert it unexpectedly.
      if (MODE_SWITCH != 0) {
        queueAction(UI_ACTION_TOGGLE_MODE);
        showToast("ACCESS GRANTED", 900);
      }
    } else {
      pinLength = 0;
      pinEntry[0] = '\0';
      updatePinDots();
      lv_label_set_text(pinMessage, "WRONG PIN");
      lv_obj_set_style_text_color(pinMessage, C_RED, LV_PART_MAIN);
    }
  }
}

lv_obj_t *headerChip(lv_obj_t *parent, int x, int w, const char *text, lv_color_t accent,
                     lv_obj_t **outLabel, UiAction action = UI_ACTION_NONE) {
  lv_obj_t *chip = action == UI_ACTION_NONE ? lv_obj_create(parent) : lv_btn_create(parent);
  lv_obj_set_pos(chip, x, 5);
  lv_obj_set_size(chip, w, 30);
  panel(chip, C_PANEL3, accent, 7, 1);
  if (action != UI_ACTION_NONE) {
    lv_obj_set_style_bg_color(chip, C_PANEL2, LV_STATE_PRESSED);
    lv_obj_add_event_cb(chip, actionEvent, LV_EVENT_PRESSED, (void *)(intptr_t)action);
  }
  *outLabel = label(chip, text, &lv_font_montserrat_10, accent);
  lv_obj_center(*outLabel);
  return chip;
}

void createHeader() {
  lv_obj_t *header = lv_obj_create(screenMain);
  lv_obj_set_pos(header, 0, 0);
  lv_obj_set_size(header, UI_W, 40);
  base(header);
  bg(header, C_HEADER);
  lv_obj_set_style_border_width(header, 0, LV_PART_MAIN);

  lv_obj_t *name = label(header, "DX-MINI", &lv_font_montserrat_18, C_TEXT);
  lv_obj_set_pos(name, 8, 5);
  lblContext = label(header, "HOME", &lv_font_montserrat_8, C_CYAN);
  lv_obj_set_pos(lblContext, 9, 27);

  chipPower = headerChip(header, 128, 44, "ON", C_GREEN, &lblPower, UI_ACTION_TOGGLE_POWER);
  chipWifi = headerChip(header, 176, 58, "NET", C_CYAN, &lblWifi);
  chipMode = headerChip(header, 238, 77, "MANUAL", C_AMBER, &lblMode);

  lv_obj_t *line = lv_obj_create(header);
  lv_obj_set_pos(line, 0, 39);
  lv_obj_set_size(line, UI_W, 1);
  base(line);
  bg(line, C_BORDER);
  lv_obj_set_style_border_width(line, 0, LV_PART_MAIN);
}

void createHomeTempCard(int idx, int x, const char *name) {
  tempCard[idx] = lv_btn_create(pageHome);
  lv_obj_set_pos(tempCard[idx], x, 4);
  lv_obj_set_size(tempCard[idx], 100, 76);
  panel(tempCard[idx], C_PANEL, idx == 0 ? C_CYAN : C_BORDER, 9, idx == 0 ? 2 : 1);
  lv_obj_set_style_bg_color(tempCard[idx], C_PANEL2, LV_STATE_PRESSED);

  if (idx < 2) {
    lv_obj_add_event_cb(tempCard[idx], openSetpointDialog, LV_EVENT_PRESSED, (void *)(intptr_t)idx);
  }

  lv_obj_t *title = label(tempCard[idx], name, &lv_font_montserrat_10, idx == 0 ? C_CYAN : C_MUTED);
  lv_obj_align(title, LV_ALIGN_TOP_LEFT, 8, 7);

  tempValue[idx] = label(tempCard[idx], "--- C", &lv_font_montserrat_20, C_TEXT);
  lv_obj_align(tempValue[idx], LV_ALIGN_LEFT_MID, 8, 3);

  tempSub[idx] = label(tempCard[idx], idx < 2 ? "TAP TO SET" : "MONITOR", &lv_font_montserrat_8,
                       idx < 2 ? C_CYAN : C_DIM);
  lv_obj_align(tempSub[idx], LV_ALIGN_BOTTOM_LEFT, 8, -6);
}

void createHomeOutputCard(int idx, int x, const char *name, UiAction action) {
  outputCard[idx] = lv_btn_create(pageHome);
  lv_obj_set_pos(outputCard[idx], x, 85);
  lv_obj_set_size(outputCard[idx], 100, 71);
  panel(outputCard[idx], C_PANEL3, C_BORDER, 9, 2);
  lv_obj_set_style_bg_color(outputCard[idx], C_PANEL2, LV_STATE_PRESSED);
  lv_obj_add_event_cb(outputCard[idx], actionEvent, LV_EVENT_PRESSED, (void *)(intptr_t)action);

  lv_obj_t *title = label(outputCard[idx], name, &lv_font_montserrat_10, C_TEXT);
  lv_obj_align(title, LV_ALIGN_TOP_LEFT, 8, 9);

  outputState[idx] = label(outputCard[idx], "OFF", &lv_font_montserrat_20, C_TEXT);
  lv_obj_align(outputState[idx], LV_ALIGN_LEFT_MID, 8, 9);

  lv_obj_t *hint = label(outputCard[idx], "ACTUAL", &lv_font_montserrat_8, C_DIM);
  lv_obj_align(hint, LV_ALIGN_BOTTOM_LEFT, 8, -6);
}

void createHome() {
  pageHome = lv_obj_create(screenMain);
  lv_obj_set_pos(pageHome, 0, 40);
  lv_obj_set_size(pageHome, UI_W, 164);
  base(pageHome);
  bg(pageHome, C_BG);
  lv_obj_set_style_border_width(pageHome, 0, LV_PART_MAIN);

  // Touch-first home page: temperatures first, then outputs.
  createHomeTempCard(0, 5, "DISCHARGE");
  createHomeTempCard(1, 110, "RETURN");
  createHomeTempCard(2, 215, "SUPPLY");

  createHomeOutputCard(0, 5, "EVAP COOL", UI_ACTION_TOGGLE_EVAP);
  createHomeOutputCard(1, 110, "AUTO WASH", UI_ACTION_TOGGLE_WASH);
  createHomeOutputCard(2, 215, "UNIT CMD", UI_ACTION_TOGGLE_UNIT);
}

void createTempControl(int idx, int x, const char *title, UiAction minusAction, UiAction plusAction) {
  lv_obj_t *card = lv_obj_create(pageTemps);
  lv_obj_set_pos(card, x, 5);
  lv_obj_set_size(card, 152, 104);
  panel(card, C_PANEL, idx == 0 ? C_CYAN : C_BORDER, 9, idx == 0 ? 2 : 1);

  lv_obj_t *titleLbl = label(card, title, &lv_font_montserrat_12, idx == 0 ? C_CYAN : C_TEXT);
  lv_obj_set_pos(titleLbl, 10, 8);
  tempPageValue[idx] = label(card, "--- C", &lv_font_montserrat_24, C_TEXT);
  lv_obj_set_pos(tempPageValue[idx], 10, 31);
  lv_obj_t *sp = label(card, "SETPOINT", &lv_font_montserrat_8, C_MUTED);
  lv_obj_set_pos(sp, 10, 72);
  tempPageSet[idx] = label(card, "0 C", &lv_font_montserrat_14, C_TEXT);
  lv_obj_set_pos(tempPageSet[idx], 10, 85);

  // Minimum ~30 px finger targets for reliable touch on the 2.8" panel.
  touchButton(card, 78, 65, 31, 34, "-", &lv_font_montserrat_18, C_CYAN, minusAction, 15, true);
  touchButton(card, 115, 65, 31, 34, "+", &lv_font_montserrat_18, C_CYAN, plusAction, 15, true);
}

void createTemps() {
  pageTemps = lv_obj_create(screenMain);
  lv_obj_set_pos(pageTemps, 0, 40);
  lv_obj_set_size(pageTemps, UI_W, 164);
  base(pageTemps);
  bg(pageTemps, C_BG);
  lv_obj_set_style_border_width(pageTemps, 0, LV_PART_MAIN);

  createTempControl(0, 5, "DISCHARGE AIR", UI_ACTION_DISCHARGE_MINUS, UI_ACTION_DISCHARGE_PLUS);
  createTempControl(1, 163, "RETURN AIR", UI_ACTION_RETURN_MINUS, UI_ACTION_RETURN_PLUS);

  lv_obj_t *supply = lv_obj_create(pageTemps);
  lv_obj_set_pos(supply, 5, 114);
  lv_obj_set_size(supply, 310, 46);
  panel(supply, C_PANEL3, C_BORDER_DIM, 8, 1);
  lv_obj_t *title = label(supply, "SUPPLY AIR", &lv_font_montserrat_10, C_MUTED);
  lv_obj_set_pos(title, 10, 7);
  tempPageValue[2] = label(supply, "--- C", &lv_font_montserrat_20, C_TEXT);
  lv_obj_set_pos(tempPageValue[2], 10, 21);
  lv_obj_t *monitor = label(supply, "MONITOR ONLY", &lv_font_montserrat_10, C_BLUE);
  lv_obj_align(monitor, LV_ALIGN_RIGHT_MID, -12, 0);
}

void createOutputRow(int idx, int y, const char *name, UiAction action) {
  lv_obj_t *row = lv_obj_create(pageOutputs);
  lv_obj_set_pos(row, 5, y);
  lv_obj_set_size(row, 310, 49);
  panel(row, C_PANEL, C_BORDER, 8, 1);

  lv_obj_t *nameLbl = label(row, name, &lv_font_montserrat_14, C_TEXT);
  lv_obj_set_pos(nameLbl, 11, 7);
  lv_obj_t *actualCaption = label(row, "ACTUAL", &lv_font_montserrat_8, C_MUTED);
  lv_obj_set_pos(actualCaption, 11, 31);
  outActual[idx] = label(row, "OFF", &lv_font_montserrat_12, C_TEXT);
  lv_obj_set_pos(outActual[idx], 57, 27);

  outButton[idx] = touchButton(row, 226, 7, 75, 35, "OFF", &lv_font_montserrat_12,
                               C_TEXT, action, 17);
  outButtonText[idx] = lv_obj_get_child(outButton[idx], 0);
}

void createOutputs() {
  pageOutputs = lv_obj_create(screenMain);
  lv_obj_set_pos(pageOutputs, 0, 40);
  lv_obj_set_size(pageOutputs, UI_W, 164);
  base(pageOutputs);
  bg(pageOutputs, C_BG);
  lv_obj_set_style_border_width(pageOutputs, 0, LV_PART_MAIN);

  createOutputRow(0, 5, "EVAP COOL", UI_ACTION_TOGGLE_EVAP);
  createOutputRow(1, 57, "AUTO WASH", UI_ACTION_TOGGLE_WASH);
  createOutputRow(2, 109, "UNIT COMMAND", UI_ACTION_TOGGLE_UNIT);
}

void createSettings() {
  pageSettings = lv_obj_create(screenMain);
  lv_obj_set_pos(pageSettings, 0, 40);
  lv_obj_set_size(pageSettings, UI_W, 164);
  base(pageSettings);
  bg(pageSettings, C_BG);
  lv_obj_set_style_border_width(pageSettings, 0, LV_PART_MAIN);

  // Identity: device name is dynamic from Def.h (DXM-AAA001, DXM-AAA002, ...).
  lv_obj_t *identity = lv_obj_create(pageSettings);
  lv_obj_set_pos(identity, 5, 5);
  lv_obj_set_size(identity, 310, 36);
  panel(identity, C_PANEL, C_BORDER, 8, 1);
  char initialIdentity[48];
  snprintf(initialIdentity, sizeof(initialIdentity), "DX-MINI  |  %s", devicename.c_str());
  settingsDeviceId = label(identity, initialIdentity, &lv_font_montserrat_14, C_TEXT);
  lv_obj_set_width(settingsDeviceId, 290);
  lv_label_set_long_mode(settingsDeviceId, LV_LABEL_LONG_DOT);
  lv_obj_align(settingsDeviceId, LV_ALIGN_LEFT_MID, 10, 0);

  lv_obj_t *power = lv_obj_create(pageSettings);
  lv_obj_set_pos(power, 5, 46);
  lv_obj_set_size(power, 152, 62);
  panel(power, C_PANEL, C_BORDER, 8, 1);
  lv_obj_t *pt = label(power, "SYSTEM POWER", &lv_font_montserrat_10, C_MUTED);
  lv_obj_set_pos(pt, 9, 7);
  settingsPower = label(power, "ON", &lv_font_montserrat_18, C_GREEN);
  lv_obj_set_pos(settingsPower, 9, 31);
  touchButton(power, 81, 14, 62, 38, "TOGGLE", &lv_font_montserrat_10, C_GREEN,
              UI_ACTION_TOGGLE_POWER, 9);

  lv_obj_t *mode = lv_obj_create(pageSettings);
  lv_obj_set_pos(mode, 163, 46);
  lv_obj_set_size(mode, 152, 62);
  panel(mode, C_PANEL, C_BORDER, 8, 1);
  lv_obj_t *mt = label(mode, "CONTROL MODE", &lv_font_montserrat_10, C_MUTED);
  lv_obj_set_pos(mt, 9, 7);
  settingsMode = label(mode, "MANUAL", &lv_font_montserrat_16, C_AMBER);
  lv_obj_set_pos(settingsMode, 9, 32);

  lv_obj_t *modeBtn = lv_btn_create(mode);
  lv_obj_set_pos(modeBtn, 88, 14);
  lv_obj_set_size(modeBtn, 55, 38);
  panel(modeBtn, C_PANEL3, C_AMBER, 9, 1);
  lv_obj_set_style_bg_color(modeBtn, C_PANEL2, LV_STATE_PRESSED);
  lv_obj_add_event_cb(modeBtn, modeRequestEvent, LV_EVENT_PRESSED, nullptr);
  lv_obj_t *modeBtnTxt = label(modeBtn, "CHANGE", &lv_font_montserrat_8, C_AMBER);
  lv_obj_center(modeBtnTxt);

  lv_obj_t *network = lv_obj_create(pageSettings);
  lv_obj_set_pos(network, 5, 113);
  lv_obj_set_size(network, 310, 47);
  panel(network, C_PANEL3, C_BORDER, 8, 1);
  lv_obj_t *nt = label(network, "NETWORK", &lv_font_montserrat_10, C_MUTED);
  lv_obj_set_pos(nt, 10, 6);
  settingsSsid = label(network, "NO SSID", &lv_font_montserrat_12, C_TEXT);
  lv_obj_set_width(settingsSsid, 205);
  lv_label_set_long_mode(settingsSsid, LV_LABEL_LONG_DOT);
  lv_obj_set_pos(settingsSsid, 10, 24);
  settingsNetwork = label(network, "OFFLINE", &lv_font_montserrat_14, C_DIM);
  lv_obj_align(settingsNetwork, LV_ALIGN_RIGHT_MID, -12, 7);
}

void createSetpointDialog() {
  setpointOverlay = lv_obj_create(screenMain);
  lv_obj_set_pos(setpointOverlay, 0, 0);
  lv_obj_set_size(setpointOverlay, UI_W, UI_H);
  base(setpointOverlay);
  bg(setpointOverlay, lv_color_hex(0x010407));
  lv_obj_set_style_bg_opa(setpointOverlay, LV_OPA_90, LV_PART_MAIN);
  lv_obj_set_style_border_width(setpointOverlay, 0, LV_PART_MAIN);
  lv_obj_add_flag(setpointOverlay, LV_OBJ_FLAG_CLICKABLE);

  lv_obj_t *dialog = lv_obj_create(setpointOverlay);
  lv_obj_set_size(dialog, 270, 166);
  lv_obj_align(dialog, LV_ALIGN_CENTER, 0, 0);
  panel(dialog, C_PANEL, C_CYAN, 12, 2);

  setpointTitle = label(dialog, "DISCHARGE AIR", &lv_font_montserrat_16, C_CYAN);
  lv_obj_set_pos(setpointTitle, 14, 12);

  lv_obj_t *closeBtn = touchButton(dialog, 226, 8, 32, 30, "X", &lv_font_montserrat_12,
                                   C_RED, UI_ACTION_NONE, 8);
  lv_obj_add_event_cb(closeBtn, closeSetpointDialog, LV_EVENT_PRESSED, nullptr);

  lv_obj_t *curLabel = label(dialog, "CURRENT", &lv_font_montserrat_8, C_MUTED);
  lv_obj_set_pos(curLabel, 16, 50);
  setpointCurrent = label(dialog, "--- C", &lv_font_montserrat_24, C_TEXT);
  lv_obj_set_pos(setpointCurrent, 16, 65);

  lv_obj_t *spLabel = label(dialog, "SETPOINT", &lv_font_montserrat_8, C_MUTED);
  lv_obj_set_pos(spLabel, 16, 107);
  setpointSp = label(dialog, "0 C", &lv_font_montserrat_20, C_TEXT);
  lv_obj_set_pos(setpointSp, 16, 122);

  lv_obj_t *minus = lv_btn_create(dialog);
  lv_obj_set_pos(minus, 154, 78);
  lv_obj_set_size(minus, 46, 46);
  panel(minus, C_PANEL3, C_CYAN, 23, 2);
  lv_obj_set_style_bg_color(minus, C_PANEL2, LV_STATE_PRESSED);
  lv_obj_add_event_cb(minus, setpointMinusEvent, LV_EVENT_PRESSED, nullptr);
  lv_obj_add_event_cb(minus, setpointMinusEvent, LV_EVENT_LONG_PRESSED_REPEAT, nullptr);
  lv_obj_t *minusTxt = label(minus, "-", &lv_font_montserrat_24, C_TEXT);
  lv_obj_center(minusTxt);

  lv_obj_t *plus = lv_btn_create(dialog);
  lv_obj_set_pos(plus, 208, 78);
  lv_obj_set_size(plus, 46, 46);
  panel(plus, C_PANEL3, C_CYAN, 23, 2);
  lv_obj_set_style_bg_color(plus, C_PANEL2, LV_STATE_PRESSED);
  lv_obj_add_event_cb(plus, setpointPlusEvent, LV_EVENT_PRESSED, nullptr);
  lv_obj_add_event_cb(plus, setpointPlusEvent, LV_EVENT_LONG_PRESSED_REPEAT, nullptr);
  lv_obj_t *plusTxt = label(plus, "+", &lv_font_montserrat_24, C_TEXT);
  lv_obj_center(plusTxt);

  lv_obj_add_flag(setpointOverlay, LV_OBJ_FLAG_HIDDEN);
}

void createPinDialog() {
  pinOverlay = lv_obj_create(screenMain);
  lv_obj_set_pos(pinOverlay, 0, 0);
  lv_obj_set_size(pinOverlay, UI_W, UI_H);
  base(pinOverlay);
  bg(pinOverlay, lv_color_hex(0x010407));
  lv_obj_set_style_bg_opa(pinOverlay, LV_OPA_90, LV_PART_MAIN);
  lv_obj_set_style_border_width(pinOverlay, 0, LV_PART_MAIN);
  lv_obj_add_flag(pinOverlay, LV_OBJ_FLAG_CLICKABLE);

  lv_obj_t *dialog = lv_obj_create(pinOverlay);
  lv_obj_set_size(dialog, 252, 218);
  lv_obj_align(dialog, LV_ALIGN_CENTER, 0, 0);
  panel(dialog, C_PANEL, C_AMBER, 12, 2);

  lv_obj_t *title = label(dialog, "MANUAL MODE ACCESS", &lv_font_montserrat_14, C_TEXT);
  lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 10);

  pinMessage = label(dialog, "ENTER PIN", &lv_font_montserrat_10, C_MUTED);
  lv_obj_align(pinMessage, LV_ALIGN_TOP_MID, 0, 34);
  pinDots = label(dialog, "- - - -", &lv_font_montserrat_18, C_AMBER);
  lv_obj_align(pinDots, LV_ALIGN_TOP_MID, 0, 52);

  const int xs[3] = {24, 91, 158};
  const int ys[4] = {83, 116, 149, 182};
  int digit = 1;
  for (int r = 0; r < 3; ++r) {
    for (int c = 0; c < 3; ++c) {
      lv_obj_t *btn = lv_btn_create(dialog);
      lv_obj_set_pos(btn, xs[c], ys[r]);
      lv_obj_set_size(btn, 58, 28);
      panel(btn, C_PANEL3, C_BORDER, 7, 1);
      lv_obj_set_style_bg_color(btn, C_PANEL2, LV_STATE_PRESSED);
      lv_obj_add_event_cb(btn, pinKeyEvent, LV_EVENT_PRESSED, (void *)(intptr_t)digit);
      char digitText[2] = {char('0' + digit), '\0'};
      lv_obj_t *txt = label(btn, digitText, &lv_font_montserrat_12, C_TEXT);
      lv_obj_center(txt);
      ++digit;
    }
  }

  // Bottom row: backspace, zero, confirm.
  lv_obj_t *back = lv_btn_create(dialog);
  lv_obj_set_pos(back, xs[0], ys[3]);
  lv_obj_set_size(back, 58, 28);
  panel(back, C_PANEL3, C_BORDER, 7, 1);
  lv_obj_add_event_cb(back, pinKeyEvent, LV_EVENT_PRESSED, (void *)(intptr_t)-1);
  lv_obj_t *backTxt = label(back, "<", &lv_font_montserrat_12, C_TEXT);
  lv_obj_center(backTxt);

  lv_obj_t *zero = lv_btn_create(dialog);
  lv_obj_set_pos(zero, xs[1], ys[3]);
  lv_obj_set_size(zero, 58, 28);
  panel(zero, C_PANEL3, C_BORDER, 7, 1);
  lv_obj_add_event_cb(zero, pinKeyEvent, LV_EVENT_PRESSED, (void *)(intptr_t)0);
  lv_obj_t *zeroTxt = label(zero, "0", &lv_font_montserrat_12, C_TEXT);
  lv_obj_center(zeroTxt);

  lv_obj_t *ok = lv_btn_create(dialog);
  lv_obj_set_pos(ok, xs[2], ys[3]);
  lv_obj_set_size(ok, 58, 28);
  panel(ok, C_PANEL3, C_GREEN, 7, 1);
  lv_obj_add_event_cb(ok, pinKeyEvent, LV_EVENT_PRESSED, (void *)(intptr_t)-2);
  lv_obj_t *okTxt = label(ok, "OK", &lv_font_montserrat_10, C_GREEN);
  lv_obj_center(okTxt);

  lv_obj_t *cancel = lv_btn_create(dialog);
  lv_obj_set_pos(cancel, 216, 7);
  lv_obj_set_size(cancel, 28, 28);
  panel(cancel, C_PANEL3, C_RED, 7, 1);
  lv_obj_add_event_cb(cancel, pinKeyEvent, LV_EVENT_PRESSED, (void *)(intptr_t)-3);
  lv_obj_t *cancelTxt = label(cancel, "X", &lv_font_montserrat_10, C_RED);
  lv_obj_center(cancelTxt);

  lv_obj_add_flag(pinOverlay, LV_OBJ_FLAG_HIDDEN);
}

void createNavigation() {
  lv_obj_t *bar = lv_obj_create(screenMain);
  lv_obj_set_pos(bar, 0, 204);
  lv_obj_set_size(bar, UI_W, 36);
  base(bar);
  bg(bar, C_HEADER);
  lv_obj_set_style_border_width(bar, 0, LV_PART_MAIN);

  const char *names[4] = {"HOME", "TEMPS", "OUTPUTS", "SETTINGS"};
  for (int i = 0; i < 4; ++i) {
    navBtn[i] = lv_btn_create(bar);
    lv_obj_set_pos(navBtn[i], i * 80, 0);
    lv_obj_set_size(navBtn[i], 80, 36);
    base(navBtn[i]);
    bg(navBtn[i], C_HEADER);
    lv_obj_set_style_border_width(navBtn[i], 0, LV_PART_MAIN);
    lv_obj_set_style_radius(navBtn[i], 0, LV_PART_MAIN);
    lv_obj_set_style_bg_color(navBtn[i], C_PANEL2, LV_STATE_PRESSED);
    lv_obj_add_event_cb(navBtn[i], pageEvent, LV_EVENT_PRESSED, (void *)(intptr_t)i);
    navText[i] = label(navBtn[i], names[i], &lv_font_montserrat_10, i == 0 ? C_CYAN : C_MUTED);
    lv_obj_center(navText[i]);

    navLine[i] = lv_obj_create(bar);
    lv_obj_set_pos(navLine[i], i * 80 + 10, 33);
    lv_obj_set_size(navLine[i], 60, 2);
    base(navLine[i]);
    bg(navLine[i], i == 0 ? C_CYAN : C_HEADER);
    lv_obj_set_style_border_width(navLine[i], 0, LV_PART_MAIN);
  }
}

void createSplash() {
  screenSplash = lv_obj_create(nullptr);
  base(screenSplash);
  bg(screenSplash, C_BG);
  lv_obj_set_style_border_width(screenSplash, 0, LV_PART_MAIN);

  lv_obj_t *badge = lv_obj_create(screenSplash);
  lv_obj_set_pos(badge, 28, 53);
  lv_obj_set_size(badge, 72, 72);
  panel(badge, C_PANEL, C_CYAN, 10, 2);
  lv_obj_t *dx = label(badge, "DX", &lv_font_montserrat_28, C_CYAN);
  lv_obj_center(dx);

  lv_obj_t *title = label(screenSplash, "DX-MINI", &lv_font_montserrat_28, C_TEXT);
  lv_obj_set_pos(title, 119, 56);
  lv_obj_t *sub = label(screenSplash, devicename.c_str(), &lv_font_montserrat_12, C_CYAN);
  lv_obj_set_pos(sub, 120, 91);

  splashBar = lv_bar_create(screenSplash);
  lv_obj_set_pos(splashBar, 28, 157);
  lv_obj_set_size(splashBar, 264, 8);
  lv_bar_set_range(splashBar, 0, 100);
  lv_bar_set_value(splashBar, 0, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(splashBar, C_PANEL2, LV_PART_MAIN);
  lv_obj_set_style_bg_color(splashBar, C_CYAN, LV_PART_INDICATOR);
  lv_obj_set_style_radius(splashBar, 4, LV_PART_MAIN);
  lv_obj_set_style_radius(splashBar, 4, LV_PART_INDICATOR);

  splashStatus = label(screenSplash, "STARTING", &lv_font_montserrat_10, C_MUTED);
  lv_obj_align(splashStatus, LV_ALIGN_BOTTOM_MID, 0, -50);
}

void createMain() {
  Serial.println("[DISPLAY] Building main HMI...");
  screenMain = lv_obj_create(nullptr);
  base(screenMain);
  bg(screenMain, C_BG);
  lv_obj_set_style_border_width(screenMain, 0, LV_PART_MAIN);
  createHeader();
  createHome();
  createTemps();
  createOutputs();
  createSettings();
  createNavigation();

  toast = lv_obj_create(screenMain);
  lv_obj_set_size(toast, 190, 40);
  lv_obj_align(toast, LV_ALIGN_CENTER, 0, 0);
  panel(toast, C_PANEL2, C_CYAN, 9, 2);
  lv_obj_clear_flag(toast, LV_OBJ_FLAG_CLICKABLE);
  toastText = label(toast, "", &lv_font_montserrat_14, C_TEXT);
  lv_obj_center(toastText);
  lv_obj_add_flag(toast, LV_OBJ_FLAG_HIDDEN);

  lv_obj_clear_flag(pageHome, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(pageTemps, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(pageOutputs, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(pageSettings, LV_OBJ_FLAG_HIDDEN);
  Serial.println("[DISPLAY] Main HMI built");
}

void updateHeader() {
  const bool wifi = activeNetwork == DxTransport::WIFI;
  const bool ethernet = activeNetwork == DxTransport::ETHERNET;
  const bool autoMode = MODE_SWITCH != 0;

  lv_label_set_text(lblPower, PowerState ? "ON" : "OFF");
  lv_obj_set_style_text_color(lblPower, PowerState ? C_GREEN : C_RED, LV_PART_MAIN);
  setBorder(chipPower, PowerState ? C_GREEN : C_RED);

  const char *networkText = ethernet ? "ETH" : (wifi ? "WIFI" : "OFF");
  const lv_color_t networkColor = ethernet ? C_GREEN : (wifi ? C_CYAN : C_DIM);
  lv_label_set_text(lblWifi, networkText);
  lv_obj_set_style_text_color(lblWifi, networkColor, LV_PART_MAIN);
  setBorder(chipWifi, (ethernet || wifi) ? networkColor : C_BORDER_DIM);

  lv_label_set_text(lblMode, autoMode ? "AUTO" : "MANUAL");
  lv_obj_set_style_text_color(lblMode, autoMode ? C_BLUE : C_AMBER, LV_PART_MAIN);
  setBorder(chipMode, autoMode ? C_BLUE : C_AMBER);

  if (activePage == PAGE_HOME) {
    lv_label_set_text(lblContext, "HOME");
  } else if (activePage == PAGE_TEMPS) lv_label_set_text(lblContext, "TEMPERATURES");
  else if (activePage == PAGE_OUTPUTS) lv_label_set_text(lblContext, "OUTPUT CONTROL");
  else lv_label_set_text(lblContext, "SETTINGS");
}

void updateHomeOutputs() {
  const bool actual[3] = {EVAP_COOL_SYSTEM_STATUS, AUTO_WASH_SYSTEM_STATUS, UNIT_COMMAND_STATUS};
  const bool manual = MODE_SWITCH == 0;

  for (int i = 0; i < 3; ++i) {
    // Home cards are ACTUAL outputs, not a pending manual command.
    const bool shownOn = actual[i];
    const lv_color_t color = shownOn ? C_GREEN : C_TEXT;
    lv_label_set_text(outputState[i], shownOn ? "ON" : "OFF");
    lv_obj_set_style_text_color(outputState[i], color, LV_PART_MAIN);
    lv_obj_set_style_text_color(lv_obj_get_child(outputCard[i], 0), C_TEXT, LV_PART_MAIN);
    setBorder(outputCard[i], shownOn ? C_GREEN : C_BORDER, 2);
    bg(outputCard[i], C_PANEL);
    setEnabledVisual(outputCard[i], PowerState && manual);
  }
}

void updateTemps() {
  const float liveValues[3] = {dischargeTemp, ReturnTemp, SupplyTemp};
  const float values[3] = {
      uiTempForDisplay(0, dischargeTemp),
      uiTempForDisplay(1, ReturnTemp),
      uiTempForDisplay(2, SupplyTemp)};
  const bool alarms[3] = {dischargeTempAlarm, returnTempAlarm, false};

  char text[20];
  for (int i = 0; i < 3; ++i) {
    formatTemp(text, sizeof(text), values[i], 1, true);
    lv_label_set_text(tempValue[i], text);
    lv_obj_set_style_text_color(tempValue[i],
                                (validTemp(liveValues[i]) && alarms[i]) ? C_RED : C_TEXT,
                                LV_PART_MAIN);
    setBorder(tempCard[i], selectedTemp == i ? C_CYAN : C_BORDER,
              selectedTemp == i ? 2 : 1);
  }

  lv_label_set_text_fmt(tempSub[0], "SP %d C", dischargeSp);
  lv_label_set_text_fmt(tempSub[1], "SP %d C", ReturnSp);
  lv_label_set_text(tempSub[2], "MONITOR");

  // Dedicated temperature page.
  formatTemp(text, sizeof(text), values[0], 1, true);
  lv_label_set_text(tempPageValue[0], text);
  formatTemp(text, sizeof(text), values[1], 1, true);
  lv_label_set_text(tempPageValue[1], text);
  formatTemp(text, sizeof(text), values[2], 1, true);
  lv_label_set_text(tempPageValue[2], text);
  lv_label_set_text_fmt(tempPageSet[0], "%d C", dischargeSp);
  lv_label_set_text_fmt(tempPageSet[1], "%d C", ReturnSp);
  lv_obj_set_style_text_color(tempPageValue[0],
                              (validTemp(liveValues[0]) && dischargeTempAlarm) ? C_RED : C_TEXT,
                              LV_PART_MAIN);
  lv_obj_set_style_text_color(tempPageValue[1],
                              (validTemp(liveValues[1]) && returnTempAlarm) ? C_RED : C_TEXT,
                              LV_PART_MAIN);

  // Home-card setpoint dialog follows live values while open.
  if (setpointTitle && setpointCurrent && setpointSp) {
    const bool isDischarge = setpointTarget == 0;
    lv_label_set_text(setpointTitle, isDischarge ? "DISCHARGE AIR" : "RETURN AIR");
    formatTemp(text, sizeof(text), values[isDischarge ? 0 : 1], 1, true);
    lv_label_set_text(setpointCurrent, text);
    lv_label_set_text_fmt(setpointSp, "%d C", isDischarge ? dischargeSp : ReturnSp);
  }
}

void updateOutputs() {
  const bool actual[3] = {EVAP_COOL_SYSTEM_STATUS, AUTO_WASH_SYSTEM_STATUS, UNIT_COMMAND_STATUS};
  const int command[3] = {EVAP_COOL_SYSTEM_SWITCH, AUTO_WASH_SYSTEM_SWITCH, UNIT_COMMAND_SWITCH};
  const bool manual = MODE_SWITCH == 0;

  for (int i = 0; i < 3; ++i) {
    lv_label_set_text(outActual[i], actual[i] ? "ON" : "OFF");
    lv_obj_set_style_text_color(outActual[i], actual[i] ? C_GREEN : C_TEXT, LV_PART_MAIN);

    const lv_color_t color = command[i] ? C_GREEN : C_TEXT;
    lv_label_set_text(outButtonText[i], command[i] ? "ON" : "OFF");
    lv_obj_set_style_text_color(outButtonText[i], color, LV_PART_MAIN);
    setBorder(outButton[i], command[i] ? C_GREEN : C_BORDER, 2);
    setEnabledVisual(outButton[i], PowerState && manual);
  }
}

void updateSettings() {
  const bool wifi = activeNetwork == DxTransport::WIFI;
  const bool ethernet = activeNetwork == DxTransport::ETHERNET;
  const bool autoMode = MODE_SWITCH != 0;

  if (settingsDeviceId) {
    char identity[48];
    snprintf(identity, sizeof(identity), "DX-MINI  |  %s", devicename.c_str());
    lv_label_set_text(settingsDeviceId, identity);
  }

  lv_label_set_text(settingsPower, PowerState ? "ON" : "OFF");
  lv_obj_set_style_text_color(settingsPower, PowerState ? C_GREEN : C_RED, LV_PART_MAIN);

  lv_label_set_text(settingsMode, autoMode ? "AUTO" : "MANUAL");
  lv_obj_set_style_text_color(settingsMode, autoMode ? C_BLUE : C_AMBER, LV_PART_MAIN);

  if (ethernet) {
    lv_label_set_text(settingsNetwork, "ETHERNET");
    lv_obj_set_style_text_color(settingsNetwork, C_GREEN, LV_PART_MAIN);
  } else if (wifi) {
    lv_label_set_text(settingsNetwork, "WIFI");
    lv_obj_set_style_text_color(settingsNetwork, C_CYAN, LV_PART_MAIN);
  } else {
    lv_label_set_text(settingsNetwork, "OFFLINE");
    lv_obj_set_style_text_color(settingsNetwork, C_DIM, LV_PART_MAIN);
  }

  if (settingsSsid) {
    if (ethernet) {
      char ipText[48];
      snprintf(ipText, sizeof(ipText), "IP %s", myIP.length() ? myIP.c_str() : "0.0.0.0");
      lv_label_set_text(settingsSsid, ipText);
      lv_obj_set_style_text_color(settingsSsid, C_TEXT, LV_PART_MAIN);
    } else if (wifi) {
      const String shownSsid = WiFi.SSID().length() ? WiFi.SSID() : ssid;
      lv_label_set_text(settingsSsid, shownSsid.length() ? shownSsid.c_str() : "WIFI CONNECTED");
      lv_obj_set_style_text_color(settingsSsid, C_TEXT, LV_PART_MAIN);
    } else if (w5500_detected) {
      lv_label_set_text(settingsSsid, "ETH CABLE / WIFI NOT CONNECTED");
      lv_obj_set_style_text_color(settingsSsid, C_DIM, LV_PART_MAIN);
    } else {
      lv_label_set_text(settingsSsid, "NOT CONNECTED");
      lv_obj_set_style_text_color(settingsSsid, C_DIM, LV_PART_MAIN);
    }
  }
}
} // namespace

namespace {
int16_t quantizeTemp(float value) {
  if (!validTemp(value)) return value == SENSOR_NOT_SELECTED_VALUE ? INT16_MAX : INT16_MIN;
  const long scaled = lroundf(value * 10.0f);
  return static_cast<int16_t>(constrain(scaled, -32767L, 32766L));
}

UiRuntimeSnapshot captureUiSnapshot() {
  UiRuntimeSnapshot s;
  memset(&s, 0, sizeof(s));
  s.power = PowerState;
  s.network = static_cast<uint8_t>(activeNetwork);
  s.dischargeAlarm = dischargeTempAlarm;
  s.returnAlarm = returnTempAlarm;
  s.evapStatus = EVAP_COOL_SYSTEM_STATUS;
  s.washStatus = AUTO_WASH_SYSTEM_STATUS;
  s.unitStatus = UNIT_COMMAND_STATUS;
  s.mode = MODE_SWITCH;
  s.dischargeSetpoint = dischargeSp;
  s.returnSetpoint = ReturnSp;
  s.evapCommand = EVAP_COOL_SYSTEM_SWITCH;
  s.washCommand = AUTO_WASH_SYSTEM_SWITCH;
  s.unitCommand = UNIT_COMMAND_SWITCH;
  s.discharge10 = quantizeTemp(dischargeTemp);
  s.return10 = quantizeTemp(ReturnTemp);
  s.supply10 = quantizeTemp(SupplyTemp);
  s.page = static_cast<uint8_t>(activePage);
  return s;
}

bool runtimeStateChanged() {
  const UiRuntimeSnapshot now = captureUiSnapshot();
  if (!haveSnapshot || memcmp(&now, &lastSnapshot, sizeof(now)) != 0) {
    lastSnapshot = now;
    haveSnapshot = true;
    return true;
  }
  return false;
}

void renderDisplay() {
  if (!screenMain) return;

  // Header is always visible.  Only refresh the currently visible page;
  // updating all four hidden pages on every state change wastes CPU, LVGL
  // heap churn and SPI invalidation bandwidth.
  updateHeader();
  switch (activePage) {
    case PAGE_HOME:
      updateHomeOutputs();
      updateTemps();
      break;
    case PAGE_TEMPS:
      updateTemps();
      break;
    case PAGE_OUTPUTS:
      updateOutputs();
      break;
    case PAGE_SETTINGS:
      updateSettings();
      break;
  }
}

void processQueuedUiMessages() {
  BootMessage boot{};
  while (bootQueue && xQueueReceive(bootQueue, &boot, 0) == pdTRUE) {
    if (screenSplash) {
      lv_bar_set_value(splashBar, constrain(boot.value, 0, 100), LV_ANIM_OFF);
      lv_label_set_text(splashStatus, boot.status);
    }
  }

  ToastMessage message{};
  while (toastQueue && xQueueReceive(toastQueue, &message, 0) == pdTRUE) {
    showToast(message.text, message.durationMs);
  }
}

void uiTask(void *) {
  lastLvTick = millis();
  constexpr uint32_t MIN_SPLASH_MS = 1200;

  for (;;) {
    const uint32_t now = millis();
    const uint32_t elapsed = now - lastLvTick;
    if (elapsed) {
      lv_tick_inc(elapsed);
      lastLvTick = now;
    }

    processQueuedUiMessages();

    if (mainScreenRequested && !mainScreenVisible &&
        (splashVisibleSince == 0 || (now - splashVisibleSince) >= MIN_SPLASH_MS)) {
      if (!screenMain) {
        createMain();
        lv_mem_monitor_t memAfterMain{};
        lv_mem_monitor(&memAfterMain);
        Serial.printf("[DISPLAY] LVGL after main: free=%u largest=%u frag=%u%%\n",
                      static_cast<unsigned>(memAfterMain.free_size),
                      static_cast<unsigned>(memAfterMain.free_biggest_size),
                      static_cast<unsigned>(memAfterMain.frag_pct));
        Serial.printf("[DISPLAY] UI task stack free words=%u\n",
                      static_cast<unsigned>(uxTaskGetStackHighWaterMark(nullptr)));
      }
      if (screenMain) {
        lv_scr_load(screenMain);
        lv_refr_now(nullptr);
        mainScreenVisible = true;
        uiDirtyRequested = true;
        if (screenSplash) {
          lv_obj_del(screenSplash);
          screenSplash = nullptr;
          splashBar = nullptr;
          splashStatus = nullptr;
        }
        Serial.println("[DISPLAY] DX-MINI main HMI active");
      }
    }

    bool stateChanged = false;
    if ((now - lastStatePoll) >= 20) {
      lastStatePoll = now;
      stateChanged = runtimeStateChanged();
    }

    // Do not redraw the whole dashboard four times per second when nothing
    // changed.  The previous 250 ms unconditional refresh continuously
    // invalidated labels/styles and kept the SPI bus busy.  Redraw on a real
    // state change, an explicit UI request, or a slow 1 s safety refresh.
    if (uiDirtyRequested || stateChanged || (now - lastUiRefresh) >= 1000) {
      uiDirtyRequested = false;
      lastUiRefresh = now;
      renderDisplay();
    }

    if (toast && toastUntil && (int32_t)(now - toastUntil) >= 0) {
      lv_obj_add_flag(toast, LV_OBJ_FLAG_HIDDEN);
      toastUntil = 0;
    }

    // lv_timer_handler() services refresh, animations and the pointer input.
    // A short task sleep keeps CPU use low while retaining fast touch response.
    const uint32_t nextTimer = lv_timer_handler();
    const TickType_t sleepTicks = pdMS_TO_TICKS(constrain(nextTimer, 2U, 5U));
    ulTaskNotifyTake(pdTRUE, sleepTicks);
  }
}
} // namespace

UiAction uiTakeAction() {
  UiAction action = UI_ACTION_NONE;
  if (actionQueue) (void)xQueueReceive(actionQueue, &action, 0);
  return action;
}

void updateDisplay() {
  requestUiRefresh();
}

void uiInit() {
  pinMode(TFT_BACKLIGHT_PIN, OUTPUT);
  digitalWrite(TFT_BACKLIGHT_PIN, LOW);

  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);

  Serial.print("[TOUCH] CST820: ");
  if (touch.begin()) {
    Serial.printf("detected at 0x%02X | swapXY=%d invertX=%d invertY=%d\n",
                  touch.address(), DX_TOUCH_SWAP_XY, DX_TOUCH_INVERT_X, DX_TOUCH_INVERT_Y);
  } else {
    Serial.println("NOT DETECTED");
  }

  lv_init();
  lastLvTick = millis();

  if (!allocateDrawBuffer()) {
    // Do not continue into LVGL with a null draw buffer.  Keep the panel
    // dark and return cleanly rather than risking a crash/reboot loop.
    digitalWrite(TFT_BACKLIGHT_PIN, LOW);
    return;
  }
  lv_disp_draw_buf_init(&drawBuf, drawMem, nullptr, UI_W * drawBufferLines);

  lv_disp_drv_init(&dispDrv);
  dispDrv.hor_res = UI_W;
  dispDrv.ver_res = UI_H;
  dispDrv.flush_cb = flushDisplay;
  dispDrv.draw_buf = &drawBuf;
  lv_disp_drv_register(&dispDrv);

  lv_indev_drv_init(&indevDrv);
  indevDrv.type = LV_INDEV_TYPE_POINTER;
  indevDrv.read_cb = readTouch;
  indevDrv.long_press_time = 320;
  indevDrv.long_press_repeat_time = 90;
  lv_indev_drv_register(&indevDrv);

  actionQueue = xQueueCreate(16, sizeof(UiAction));
  bootQueue = xQueueCreate(1, sizeof(BootMessage));
  toastQueue = xQueueCreate(4, sizeof(ToastMessage));
  if (!actionQueue || !bootQueue || !toastQueue) {
    Serial.println("[DISPLAY] ERROR: UI queue allocation failed");
  }

  Serial.println("[DISPLAY] Building splash...");
  createSplash();
  Serial.println("[DISPLAY] Splash built");

  lv_mem_monitor_t lvMem{};
  lv_mem_monitor(&lvMem);
  Serial.printf("[DISPLAY] LVGL free=%u bytes | largest=%u | ESP heap=%u\n",
                static_cast<unsigned>(lvMem.free_size),
                static_cast<unsigned>(lvMem.free_biggest_size),
                static_cast<unsigned>(ESP.getFreeHeap()));

  // Draw the splash completely before enabling the backlight.
  lv_scr_load(screenSplash);
  lv_bar_set_value(splashBar, 5, LV_ANIM_OFF);
  lv_label_set_text(splashStatus, "STARTING");
  lv_timer_handler();
  lv_refr_now(nullptr);
  splashVisibleSince = millis();
  digitalWrite(TFT_BACKLIGHT_PIN, HIGH);

  // Keep all LVGL/TFT access on a dedicated higher-priority task. The Arduino
  // loop can block in TLS/NTP/Wi-Fi without freezing the display or touch.
  BaseType_t created = xTaskCreatePinnedToCore(
      uiTask, "dx_ui", 8192, nullptr, 2, &uiTaskHandle, 1);
  if (created != pdPASS) {
    uiTaskHandle = nullptr;
    Serial.println("[DISPLAY] ERROR: UI task creation failed");
  } else {
    Serial.printf("[DISPLAY] DX-MINI splash visible | UI task active | touch poll=%dms\n",
                  LV_INDEV_DEF_READ_PERIOD);
  }
}


bool uiMainReady() {
  return mainScreenVisible;
}

void uiLoop() {
  // Normal path: LVGL is serviced by the dedicated UI task.  If task creation
  // ever fails because of unexpected low memory, gracefully fall back to the
  // original single-threaded servicing so the display still remains usable.
  if (uiTaskHandle) return;

  const uint32_t now = millis();
  const uint32_t elapsed = now - lastLvTick;
  if (elapsed) {
    lv_tick_inc(elapsed);
    lastLvTick = now;
  }

  processQueuedUiMessages();

  constexpr uint32_t MIN_SPLASH_MS = 1200;
  if (mainScreenRequested && !mainScreenVisible &&
      (splashVisibleSince == 0 || (now - splashVisibleSince) >= MIN_SPLASH_MS)) {
    if (!screenMain) createMain();
    if (screenMain) {
      lv_scr_load(screenMain);
      lv_refr_now(nullptr);
      mainScreenVisible = true;
      uiDirtyRequested = true;
      if (screenSplash) {
        lv_obj_del(screenSplash);
        screenSplash = nullptr;
        splashBar = nullptr;
        splashStatus = nullptr;
      }
      Serial.println("[DISPLAY] DX-MINI main HMI active (fallback)");
    }
  }

  bool stateChanged = false;
  if ((now - lastStatePoll) >= 20) {
    lastStatePoll = now;
    stateChanged = runtimeStateChanged();
  }
  if (uiDirtyRequested || stateChanged || (now - lastUiRefresh) >= 1000) {
    uiDirtyRequested = false;
    lastUiRefresh = now;
    renderDisplay();
  }

  if (toast && toastUntil && (int32_t)(now - toastUntil) >= 0) {
    lv_obj_add_flag(toast, LV_OBJ_FLAG_HIDDEN);
    toastUntil = 0;
  }

  lv_timer_handler();
}

void showStartupScreen() {
  BootMessage message{};
  message.value = 10;
  snprintf(message.status, sizeof(message.status), "%s", "INITIALIZING");
  if (bootQueue) xQueueOverwrite(bootQueue, &message);
  wakeUiTask();
}

void uiSetBootProgress(int value, const char *status) {
  BootMessage message{};
  message.value = constrain(value, 0, 100);
  snprintf(message.status, sizeof(message.status), "%s", status ? status : "");
  if (bootQueue) xQueueOverwrite(bootQueue, &message);
  wakeUiTask();
}

void uiShowMain() {
  mainScreenRequested = true;
  requestUiRefresh();
}

void showCenteredText(const char *text, int seconds) {
  if (!text || !toastQueue) return;
  ToastMessage message{};
  message.durationMs = static_cast<uint32_t>(max(seconds, 1)) * 700U;
  snprintf(message.text, sizeof(message.text), "%s", text);
  (void)xQueueSend(toastQueue, &message, 0);
  wakeUiTask();
}
