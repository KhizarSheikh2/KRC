#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <ESPAsyncWebServer.h>
#include <Preferences.h>
#include "esp_task_wdt.h"
#include "esp_system.h"

#include "aws_cred.h"
#include "PCFRelays.h"
#include "NetworkPriority.h"
#include "Def.h"
#include "BridgeUart.h"
#include "temp.h"
#include "UI.h"
#include "MQTT.h"
#include "WifiThread.h"

// PlatformIO/C++ forward declaration.
void updateTimeNow();
void serviceRelayController();

static constexpr int MIN_RTEMP = 0;
static constexpr int MIN_DTEMP = 0;
static constexpr int MAX_RTEMP = 100;
static constexpr int MAX_DTEMP = 200;

bool logicalTempValid(float value) {
  return isfinite(value) &&
         value != SENSOR_DISCONNECTED &&
         value != SENSOR_NOT_SELECTED;
}

void updateControlOutputs() {
  // Never apply stored switch commands straight to physical outputs;
  // the state machine must enforce all five-second delays and interlocks.
  if (!PowerState) pcfRelayAllOff();
}

namespace {
bool tempConversionPending = false;
uint32_t tempConversionStartedMs = 0;
uint32_t lastTempReadMs = 0;
constexpr uint32_t DS18B20_CONVERSION_MS = 800UL; // 12-bit conversion worst case is 750 ms.

void requestTemperatureConversion() {
  sensors.setWaitForConversion(false);
  sensors.requestTemperatures();
  tempConversionPending = true;
  tempConversionStartedMs = millis();
}

void serviceTemperatureSensors() {
  const uint32_t now = millis();

  if (!tempConversionPending) {
    if (now - lastTempReadMs >= SENSOR_READ_INTERVAL) requestTemperatureConversion();
    return;
  }

  // Read only after the conversion has finished AND at the requested 1 s cycle.
  if (now - tempConversionStartedMs < DS18B20_CONVERSION_MS ||
      now - lastTempReadMs < SENSOR_READ_INTERVAL) {
    return;
  }

  refreshTemperatureDeviceList();

  dischargeTemp = temp1Assigned ? SENSOR_DISCONNECTED : SENSOR_NOT_SELECTED;
  SupplyTemp = temp2Assigned ? SENSOR_DISCONNECTED : SENSOR_NOT_SELECTED;
  ReturnTemp = temp3Assigned ? SENSOR_DISCONNECTED : SENSOR_NOT_SELECTED;

  for (int i = 0; i < numberOfDevices; ++i) {
    const float raw = sensors.getTempC(tempSensorAddresses[i]);
    if (!validDs18b20Temperature(raw)) continue;

    if (temp1Assigned && compareAddresses(tempSensorAddresses[i], temp1Address)) {
      dischargeTemp = raw + discharge_temp_offset;
    } else if (temp2Assigned && compareAddresses(tempSensorAddresses[i], temp2Address)) {
      SupplyTemp = raw + supply_temp_offset;
    } else if (temp3Assigned && compareAddresses(tempSensorAddresses[i], temp3Address)) {
      ReturnTemp = raw + return_air_temp_offset;
    }
  }

  dischargeTempAlarm = logicalTempValid(dischargeTemp) && dischargeTemp >= dischargeSp;
  returnTempAlarm = logicalTempValid(ReturnTemp) && ReturnTemp > ReturnSp;
  R_A_TEMP_Alarm = returnTempAlarm;

  if (numberOfDevices == 0) Serial.println("[TEMP] No DS18B20 sensor found");

  lastTempReadMs = now;
  updateDisplay();
  requestTemperatureConversion(); // Pipeline the next conversion without blocking control/UI.
}
} // namespace

void setup() {
  esp_task_wdt_init(10, true);
  Serial.begin(115200);
  delay(50);

  // Initialize external PCF8574 outputs BEFORE UI/network startup.
  // PCF8574 powers up with all pins HIGH (0xFF). On this ACTIVE-LOW
  // relay interface HIGH = OFF, so initialize and recover with 0xFF.
  // Still use independent hardware interlocks for safety-critical loads.
  pcfRelayBegin();
  pinMode(BUZZER_PIN, OUTPUT);
  pcfRelayAllOff();
  digitalWrite(BUZZER_PIN, LOW);

  // Start the known-working JC2432W328 display before network/TLS allocation.
  uiInit();
  showStartupScreen();

  sensors.begin();
  sensors.setWaitForConversion(false);
  requestTemperatureConversion();

  Serial.println("\n\n[BOOT] DX-MINI starting\n");
  Serial.print("[BOOT] Device: ");
  Serial.println(devicename);
  Serial.printf("[BOOT] Relay polarity: RELAY_ACTIVE_LOW=%s (PCF LOW=ON, HIGH=OFF)\n",
                RELAY_ACTIVE_LOW ? "true" : "false");

  uiSetBootProgress(25, "RESTORING SETTINGS");
  DEVICE_INIT();
  uiSetBootProgress(45, "SETTINGS READY");

  macaddress = WiFi.macAddress();
  uiSetBootProgress(58, "CONNECTING WIFI");
  if (loadCredentials(ssid, password)) {
    Serial.println("[WIFI] Loaded saved credentials");
    connectToWiFi(ssid, password);
  } else {
    Serial.println("[WIFI] No saved credentials; AP provisioning enabled");
    startAccessPoint();
  }

  server_setup();

  // The display ESP32 no longer allocates Ethernet TLS objects;
  // the W5500 bridge owns the Ethernet TLS stack.
  uiSetBootProgress(88, "BUILDING DASHBOARD");
  uiSetBootProgress(100, "SYSTEM READY");
  uiShowMain();
  const uint32_t uiReadyWaitStart = millis();
  while (!uiMainReady() && millis() - uiReadyWaitStart < 2500UL) {
    delay(10);
  }
  Serial.printf("[DISPLAY] Main dashboard ready=%d | free heap=%u\n",
                uiMainReady() ? 1 : 0, static_cast<unsigned>(ESP.getFreeHeap()));

  bridgeInit();
  networkSetup();
  updateDisplay();
}

void beep(int duration = BUZZER_DURATION, int freq = BUZZER_FREQ) {
  // tone() is already non-blocking on ESP32.  Do not stall touch handling for
  // an extra 10 ms on every tap.
  tone(BUZZER_PIN, freq, duration);
}

void Poweroff() {
  EVAP_COOL_SYSTEM_SWITCH = 0;
  AUTO_WASH_SYSTEM_SWITCH = 0;
  UNIT_COMMAND_SWITCH = 0;

  EVAP_COOL_SYSTEM_STATUS = false;
  AUTO_WASH_SYSTEM_STATUS = false;
  UNIT_COMMAND_STATUS = false;
  EVAP_COOL_SYSTEM_PENDING = -1;
  AUTO_WASH_SYSTEM_PENDING = -1;
  UNIT_COMMAND_PENDING = -1;

  writeRelay(EVAP_COOL_SYSTEM, false);
  writeRelay(AUTO_WASH_SYSTEM, false);
  writeRelay(UNIT_COMMAND, false);

  // Persist the safe state so a reboot while powered OFF cannot restore an old
  // manual relay command.
  preferences.begin("values", false);
  preferences.putInt("r1Sw", 0);
  preferences.putInt("r2Sw", 0);
  preferences.putInt("r3Sw", 0);
  preferences.end();

  showCenteredText("POWER OFF", 2);
}

namespace {
bool setpointCommitPending = false;
uint32_t lastSetpointEditMs = 0;
constexpr uint32_t SETPOINT_COMMIT_DELAY_MS = 350;

bool uiMqttPublishPending = false;
uint32_t uiMqttPublishRequestedMs = 0;
constexpr uint32_t UI_MQTT_DEFER_MS = 150;

uint32_t lastRelayTapMs[3] = {0, 0, 0};
constexpr uint32_t RELAY_TAP_DEBOUNCE_MS = 180;

bool relayTapAccepted(uint8_t index) {
  if (index > 2) return false;
  const uint32_t now = millis();
  if (lastRelayTapMs[index] != 0 && (now - lastRelayTapMs[index]) < RELAY_TAP_DEBOUNCE_MS) {
    return false;
  }
  lastRelayTapMs[index] = now;
  return true;
}

bool manualRelayTransitionPending() {
  if (MODE_SWITCH != 0) return false;
  return EVAP_COOL_SYSTEM_PENDING != -1 ||
         AUTO_WASH_SYSTEM_PENDING != -1 ||
         UNIT_COMMAND_PENDING != -1;
}

void markSetpointForCommit() {
  setpointCommitPending = true;
  lastSetpointEditMs = millis();
}

void commitSetpointsIfDue() {
  if (!setpointCommitPending) return;
  if (millis() - lastSetpointEditMs < SETPOINT_COMMIT_DELAY_MS) return;

  // Batch NVS + MQTT after the user stops pressing +/- instead of performing
  // flash writes and TLS publishes for every single step.  The live setpoint
  // variables are changed immediately, so control behavior is immediate.
  preferences.begin("values", false);
  preferences.putInt("dischargeSp", dischargeSp);
  preferences.putInt("returnSp", ReturnSp);
  preferences.end();

  if (mqttConnected()) publishJson();
  setpointCommitPending = false;
}

void requestUiMqttPublish() {
  uiMqttPublishPending = true;
  uiMqttPublishRequestedMs = millis();
}

void serviceUiMqttPublish() {
  if (!uiMqttPublishPending) return;
  if (millis() - uiMqttPublishRequestedMs < UI_MQTT_DEFER_MS) return;
  // Physical manual relay control has priority over TLS/MQTT.  Wait until the
  // original 5-second relay transition has completed before publishing.
  if (manualRelayTransitionPending()) return;
  if (mqttConnected()) publishJson();
  uiMqttPublishPending = false;
}
} // namespace

void processTouchAction(UiAction action) {
  if (action == UI_ACTION_NONE) return;

  beep();

  bool stateChanged = false;
  bool publishImmediately = true;

  switch (action) {
    case UI_ACTION_TOGGLE_POWER:
      PowerState = !PowerState;
      preferences.begin("values", false);
      preferences.putBool("PowerState", PowerState);
      preferences.end();

      if (PowerState) {
        showCenteredText("POWER ON", 2);
        updateControlOutputs();
      } else {
        Poweroff();
      }
      stateChanged = true;
      break;

    case UI_ACTION_TOGGLE_MODE: {
      const int previousMode = MODE_SWITCH;
      MODE_SWITCH = MODE_SWITCH == 0 ? 1 : 0;

      preferences.begin("values", false);
      preferences.putInt("modeSw", MODE_SWITCH);

      // Same safety behavior already used by the MQTT command path:
      // entering MANUAL starts with all outputs commanded OFF.
      if (previousMode != MODE_SWITCH && MODE_SWITCH == 0) {
        EVAP_COOL_SYSTEM_SWITCH = 0;
        AUTO_WASH_SYSTEM_SWITCH = 0;
        UNIT_COMMAND_SWITCH = 0;

        EVAP_COOL_SYSTEM_STATUS = false;
        AUTO_WASH_SYSTEM_STATUS = false;
        UNIT_COMMAND_STATUS = false;

        EVAP_COOL_SYSTEM_PENDING = -1;
        AUTO_WASH_SYSTEM_PENDING = -1;
        UNIT_COMMAND_PENDING = -1;

        writeRelay(EVAP_COOL_SYSTEM, false);
        writeRelay(AUTO_WASH_SYSTEM, false);
        writeRelay(UNIT_COMMAND, false);

        preferences.putInt("r1Sw", EVAP_COOL_SYSTEM_SWITCH);
        preferences.putInt("r2Sw", AUTO_WASH_SYSTEM_SWITCH);
        preferences.putInt("r3Sw", UNIT_COMMAND_SWITCH);
      }
      preferences.end();

      showCenteredText(MODE_SWITCH == 0 ? "MANUAL MODE" : "AUTO MODE", 2);
      stateChanged = true;
      break;
    }

    case UI_ACTION_DISCHARGE_MINUS:
      if (PowerState && dischargeSp > MIN_DTEMP) {
        dischargeSp--;
        markSetpointForCommit();
        publishImmediately = false;
        stateChanged = true;
      }
      break;

    case UI_ACTION_DISCHARGE_PLUS:
      if (PowerState && dischargeSp < MAX_DTEMP) {
        dischargeSp++;
        markSetpointForCommit();
        publishImmediately = false;
        stateChanged = true;
      }
      break;

    case UI_ACTION_RETURN_MINUS:
      if (PowerState && ReturnSp > MIN_RTEMP) {
        ReturnSp--;
        markSetpointForCommit();
        publishImmediately = false;
        stateChanged = true;
      }
      break;

    case UI_ACTION_RETURN_PLUS:
      if (PowerState && ReturnSp < MAX_RTEMP) {
        ReturnSp++;
        markSetpointForCommit();
        publishImmediately = false;
        stateChanged = true;
      }
      break;

    case UI_ACTION_TOGGLE_EVAP:
      if (PowerState && MODE_SWITCH == 0 && relayTapAccepted(0)) {
        if ((AUTO_WASH_SYSTEM_SWITCH || AUTO_WASH_SYSTEM_STATUS) && !EVAP_COOL_SYSTEM_SWITCH) {
          showCenteredText("WASH INTERLOCK", 2); break;
        }
        EVAP_COOL_SYSTEM_SWITCH = !EVAP_COOL_SYSTEM_SWITCH;
        EVAP_COOL_SYSTEM_PENDING = EVAP_COOL_SYSTEM_SWITCH;
        evapCoolPendingTime = millis();
        preferences.begin("values", false);
        preferences.putInt("r1Sw", EVAP_COOL_SYSTEM_SWITCH);
        preferences.end();
        Serial.printf("[MANUAL] EVAP command=%s pin=%d delay=%lu ms\n",
                      EVAP_COOL_SYSTEM_SWITCH ? "ON" : "OFF",
                      EVAP_COOL_SYSTEM,
                      (unsigned long)RELAY_SWITCH_DELAY);
        publishImmediately = false;
        requestUiMqttPublish();
        stateChanged = true;
      } else if (MODE_SWITCH != 0) {
        showCenteredText("AUTO CONTROL", 2);
      }
      break;

    case UI_ACTION_TOGGLE_WASH:
      if (PowerState && MODE_SWITCH == 0 && relayTapAccepted(1)) {
        AUTO_WASH_SYSTEM_SWITCH = !AUTO_WASH_SYSTEM_SWITCH;
        if (AUTO_WASH_SYSTEM_SWITCH) {
          // Safety actions execute immediately; wash ON still waits 5s.
          EVAP_COOL_SYSTEM_SWITCH = 0;
          UNIT_COMMAND_SWITCH = 0;
          if (writeRelay(EVAP_COOL_SYSTEM, false)) EVAP_COOL_SYSTEM_STATUS = false;
          if (writeRelay(UNIT_COMMAND, false)) UNIT_COMMAND_STATUS = false;
          EVAP_COOL_SYSTEM_PENDING = UNIT_COMMAND_PENDING = -1;
        }
        AUTO_WASH_SYSTEM_PENDING = AUTO_WASH_SYSTEM_SWITCH;
        autoWashPendingTime = millis();
        preferences.begin("values", false);
        preferences.putInt("r2Sw", AUTO_WASH_SYSTEM_SWITCH);
        if (AUTO_WASH_SYSTEM_SWITCH) {
          preferences.putInt("r1Sw", 0);
          preferences.putInt("r3Sw", 0);
        }
        preferences.end();
        Serial.printf("[MANUAL] WASH command=%s pin=%d delay=%lu ms\n",
                      AUTO_WASH_SYSTEM_SWITCH ? "ON" : "OFF",
                      AUTO_WASH_SYSTEM,
                      (unsigned long)RELAY_SWITCH_DELAY);
        publishImmediately = false;
        requestUiMqttPublish();
        stateChanged = true;
      } else if (MODE_SWITCH != 0) {
        showCenteredText("AUTO CONTROL", 2);
      }
      break;

    case UI_ACTION_TOGGLE_UNIT:
      if (PowerState && MODE_SWITCH == 0 && relayTapAccepted(2)) {
        if ((AUTO_WASH_SYSTEM_SWITCH || AUTO_WASH_SYSTEM_STATUS) && UNIT_COMMAND_SWITCH == 0) {
          showCenteredText("WASH INTERLOCK", 2);
        } else {
          UNIT_COMMAND_SWITCH = !UNIT_COMMAND_SWITCH;
          UNIT_COMMAND_PENDING = UNIT_COMMAND_SWITCH;
          unitCmdPendingTime = millis();
          preferences.begin("values", false);
          preferences.putInt("r3Sw", UNIT_COMMAND_SWITCH);
          preferences.end();
          Serial.printf("[MANUAL] UNIT command=%s pin=%d delay=%lu ms\n",
                        UNIT_COMMAND_SWITCH ? "ON" : "OFF",
                        UNIT_COMMAND,
                        (unsigned long)RELAY_SWITCH_DELAY);
          publishImmediately = false;
          requestUiMqttPublish();
          stateChanged = true;
        }
      } else if (MODE_SWITCH != 0) {
        showCenteredText("AUTO CONTROL", 2);
      }
      break;

    default:
      break;
  }

  if (stateChanged) {
    updateDisplay();
    if (publishImmediately && mqttConnected()) publishJson();
  }
}

// All actual outputs are owned by this single controller path. Hardware
// states are updated ONLY after the PCF8574 acknowledges a full-byte write.
// Confirmation applies to normal changes; wash is a safety override and
// immediately forces P0 EVAP and P2 UNIT OFF before any wash ON request.
namespace {
bool applyImmediateOff(uint8_t channel, bool &state, int &pending, int &command) {
  command = 0;
  pending = -1;
  const bool ack = writeRelay(channel, false);
  if (ack) state = false;
  return ack;
}

void runFiveSecondOutput(uint8_t channel, int requested, bool &state,
                         int &pending, unsigned long &started, const char *name) {
  const bool desired = requested != 0;
  if (desired == state) { pending = -1; return; }
  if (!pcfRelayReady()) { pending = -1; return; }
  if (pending != static_cast<int>(desired)) {
    pending = desired ? 1 : 0;
    started = millis();
    return;
  }
  if (millis() - started < RELAY_SWITCH_DELAY) return;
  if (writeRelay(channel, desired)) {
    state = desired;
    pending = -1;
    Serial.printf("[PCF-RELAY] %s P%u -> %s\n", name, channel, desired ? "ON" : "OFF");
    updateDisplay();
  }
}

void setAutoEvapDemand() {
  const bool valid = logicalTempValid(dischargeTemp);
  if (!valid) { EVAP_COOL_SYSTEM_SWITCH = 0; return; }
  if (dischargeTemp >= static_cast<float>(dischargeSp) + TEMP_HYSTERESIS) {
    EVAP_COOL_SYSTEM_SWITCH = 1;
  } else if (dischargeTemp <= static_cast<float>(dischargeSp) - TEMP_HYSTERESIS) {
    EVAP_COOL_SYSTEM_SWITCH = 0;
  }
  // Hysteresis: otherwise retain last demand.
}
} // namespace

void serviceRelayController() {
  if (!pcfRelayReady()) {
    // External I2C ACK lost: do not claim a verified physical relay state.
    EVAP_COOL_SYSTEM_STATUS = false;
    AUTO_WASH_SYSTEM_STATUS = false;
    UNIT_COMMAND_STATUS = false;
    EVAP_COOL_SYSTEM_PENDING = AUTO_WASH_SYSTEM_PENDING = UNIT_COMMAND_PENDING = -1;
    FAULT_SWITCH = 1;
    // I2C fault requires deliberate power-cycle/acknowledgement, not
    // re-energizing relays automatically on PCF recovery.
    PowerState = false;
    return;
  }

  if (!PowerState) {
    pcfRelayAllOff();
    EVAP_COOL_SYSTEM_STATUS = AUTO_WASH_SYSTEM_STATUS = UNIT_COMMAND_STATUS = false;
    EVAP_COOL_SYSTEM_PENDING = AUTO_WASH_SYSTEM_PENDING = UNIT_COMMAND_PENDING = -1;
    SYSTEM_STATUS = 0;
    return;
  }

  if (MODE_SWITCH != 0) {
    runScheduler();
    AUTO_WASH_SYSTEM_SWITCH = (timeschen && tmatched) ? 1 : 0;
    // The original AUTO behavior requests UNIT ON outside wash windows.
    UNIT_COMMAND_SWITCH = AUTO_WASH_SYSTEM_SWITCH ? 0 : 1;
    setAutoEvapDemand();
  } else if (timeschen != 0) {
    timeschen = 0;
    tmatched = 0;
    preferences.begin("timeenable", false);
    preferences.putInt("timeschen", 0);
    preferences.end();
  }

  // Protect output hardware throughout wash ON, wash OFF delay, and a new
  // wash ON request. No other output may turn ON until wash is physically OFF.
  const bool washInterlocked = AUTO_WASH_SYSTEM_SWITCH != 0 || AUTO_WASH_SYSTEM_STATUS;
  if (washInterlocked) {
    const bool evapOff = applyImmediateOff(EVAP_COOL_SYSTEM, EVAP_COOL_SYSTEM_STATUS,
                                          EVAP_COOL_SYSTEM_PENDING, EVAP_COOL_SYSTEM_SWITCH);
    const bool unitOff = applyImmediateOff(UNIT_COMMAND, UNIT_COMMAND_STATUS,
                                          UNIT_COMMAND_PENDING, UNIT_COMMAND_SWITCH);
    SYSTEM_STATUS = 0;
    // Do not turn wash ON if either OFF command did not get an I2C ACK.
    if (!evapOff || !unitOff) {
      AUTO_WASH_SYSTEM_PENDING = -1;
      return;
    }
  }
  // Apply wash first, then re-evaluate its ACTUAL state. While it is ON,
  // no EVAP/UNIT transitions can be initiated by manual or auto logic.
  runFiveSecondOutput(AUTO_WASH_SYSTEM, AUTO_WASH_SYSTEM_SWITCH,
                      AUTO_WASH_SYSTEM_STATUS, AUTO_WASH_SYSTEM_PENDING,
                      autoWashPendingTime, "AUTO WASH");

  if (AUTO_WASH_SYSTEM_SWITCH || AUTO_WASH_SYSTEM_STATUS) return;

  // Post-wash AUTO mode may restart normal outputs only after P1 is OFF.
  if (MODE_SWITCH != 0) {
    UNIT_COMMAND_SWITCH = 1;
    setAutoEvapDemand();
  }
  runFiveSecondOutput(EVAP_COOL_SYSTEM, EVAP_COOL_SYSTEM_SWITCH,
                      EVAP_COOL_SYSTEM_STATUS, EVAP_COOL_SYSTEM_PENDING,
                      evapCoolPendingTime, "EVAP COOL");
  runFiveSecondOutput(UNIT_COMMAND, UNIT_COMMAND_SWITCH,
                      UNIT_COMMAND_STATUS, UNIT_COMMAND_PENDING,
                      unitCmdPendingTime, "UNIT COMMAND");
  SYSTEM_STATUS = EVAP_COOL_SYSTEM_STATUS ? 1 : 0;
}

void loop() {
  static bool wasPoweredOff = false;

  uiLoop();

  // Drain several queued taps per controller pass so touch never develops a
  // backlog during temporary network work.
  for (uint8_t i = 0; i < 6; ++i) {
    const UiAction action = uiTakeAction();
    if (action == UI_ACTION_NONE) break;
    processTouchAction(action);
  }

  // Relay/temperature operations remain local to the display controller.
  // UART is serviced before and after network operations.
  bridgePoll();
  pcfRelayService();
  serviceTemperatureSensors();
  commitSetpointsIfDue();

  if (millis() - wait_update_time >= 5000UL) {
    updateTimeNow();
    wait_update_time = millis();
  }

  if (!PowerState) {
    if (!wasPoweredOff) {
      Poweroff();
      wasPoweredOff = true;
    }

    if (millis() - wait_time >= MQTT_INTERVAL) {
      if (mqttConnected()) publishJson();
      wait_time = millis();
    }
    networkService();
    bridgePoll();
    return;
  }
  wasPoweredOff = false;

  serviceRelayController();

  // Let relay control run before any potentially blocking TLS/MQTT publish.
  serviceUiMqttPublish();

  ///////////////////////////////////////////////////////////
  if (!manualRelayTransitionPending() && millis() - wait_time >= MQTT_INTERVAL) {
    if (message_received || message_received_config) {
      message_received = false;
      message_received_config = false;
    }

    if (mqttConnected()) {
      // publishJson() publishes both the runtime and temperature-config payloads
      // through whichever transport is currently active.
      publishJson();
    }
    wait_time = millis();
  }
  networkService();
  bridgePoll();
}
////////////////////Scheduler///////////////////

void runScheduler() {
  if (!timeschen) {
    tmatched = 0;
    return;
  }

  if (time(nullptr) <= 1609459200 || weekDay >= 7 || current_hour >= 24) {
    tmatched = 0;
    return;
  }

  tmatched = (days_in_num[weekDay] && hours_num[current_hour]) ? 1 : 0;
}

void parse_schedule(String timesch)
{
    memset(days_in_num,0,sizeof(days_in_num));
    memset(hours_num,0,sizeof(hours_num));

    int pipeIndex = timesch.indexOf('|');
    if(pipeIndex==-1) return;

    String hoursPart = timesch.substring(0,pipeIndex);
    String daysPart  = timesch.substring(pipeIndex+1);

    // HOURS
    if(hoursPart.startsWith("hoursch="))
    {
        String hstr = hoursPart.substring(8);

        if(hstr=="24")
        {
            for(int i=0;i<24;i++) hours_num[i]=1;
        }
        else
        {
            int start=0;
            int comma = hstr.indexOf(',',start);

            while(comma!=-1)
            {
                int h = hstr.substring(start,comma).toInt();
                if(h>=0 && h<24) hours_num[h]=1;

                start = comma+1;
                comma = hstr.indexOf(',',start);
            }

            int h = hstr.substring(start).toInt();
            if(h>=0 && h<24) hours_num[h]=1;
        }
    }

    // DAYS
    if(daysPart.startsWith("daysch="))
    {
        String dstr = daysPart.substring(7);

        if(dstr=="7")
        {
            for(int i=0;i<7;i++) days_in_num[i]=1;
        }
        else
        {
            int start=0;
            int comma=dstr.indexOf(',',start);

            while(comma!=-1)
            {
                int d = dstr.substring(start,comma).toInt();
                if(d>=0 && d<7) days_in_num[d]=1;

                start = comma+1;
                comma = dstr.indexOf(',',start);
            }

            int d = dstr.substring(start).toInt();
            if(d>=0 && d<7) days_in_num[d]=1;
        }
    }
}



void updateTimeNow() {
  const time_t utcNow = time(nullptr);
  if (utcNow <= 1609459200) { // clock not synchronized yet
    return;
  }

  // Keep scheduler time independent of which transport performed NTP. Unix time
  // is UTC; apply the configured Pakistan offset explicitly and use gmtime_r.
  const time_t localEpoch = utcNow + gmtOffset_sec + daylightOffset_sec;
  struct tm timeinfo{};
  gmtime_r(&localEpoch, &timeinfo);

  weekDay = static_cast<uint8_t>((timeinfo.tm_wday + 6) % 7); // Monday=0
  current_hour = static_cast<uint8_t>(timeinfo.tm_hour);

  char buffer[16];
  snprintf(buffer, sizeof(buffer), "%02d%02d%02d%02d%02d%02d",
           timeinfo.tm_mday,
           timeinfo.tm_mon + 1,
           timeinfo.tm_year % 100,
           timeinfo.tm_hour,
           timeinfo.tm_min,
           timeinfo.tm_sec);
  timenow = String(buffer);
}

// void hour_day(String hours_ch, String days_ch) {
//   for (uint8_t i = 0; i < 24; i++) {
//     hours_num[i] = false;
//   }
//   for (uint8_t i = 0; i < 7; i++) {
//     days_in_num[i] = false;
//   }

//   if (hours_ch.length() > 0 && days_ch.length() > 0) {
//     int8_t length_of_hours = 1;

//     for (uint8_t i = 0; i < hours_ch.length(); i++) {
//       if (hours_ch.charAt(i) == ',') {
//         length_of_hours++;  // 2
//       }
//     }
//     int8_t hours_start = 0;
//     uint8_t hours_end = hours_ch.indexOf(',');  // 1

//     for (uint8_t i = 0; i < length_of_hours; i++) {  // i-> 0, 1, end
//       if (hours_end == -1) {
//         hours_end = hours_ch.length();
//       }
//       int8_t hoursnum = hours_ch.substring(hours_start, hours_end).toInt();  // 0 , 1
//       hours_start = hours_end + 1;                                           // 2
//       hours_end = hours_ch.indexOf(',', hours_start);                        // 2
//       hours_num[hoursnum] = true;
//     }

//     int8_t length_of_days_ch = 1;
//     // days_in_num[] = { false, false, false, false, false, false, false };
//     //  { 0 = Monday, 1 = Tuesday, 2 = Wednesday, 3 = Thursday, 4 = Friday, 5 = Saturday, 6 = Sunday }

//     // length_of_days_ch = 1;
//     for (uint8_t i = 0; i < days_ch.length(); i++) {
//       // Serial.println("days_ch");
//       // Serial.print(days_ch.length());
//       if (days_ch.charAt(i) == ',') {
//         length_of_days_ch++;
//       }
//     }

//     int8_t day_start = 0;
//     uint8_t day_end = days_ch.indexOf(',');

//     for (int8_t i = 0; i < length_of_days_ch; i++) {
//       if (day_end == -1) {
//         // Handle the last element in the string
//         day_end = days_ch.length();
//       }
//       int8_t daynum = days_ch.substring(day_start, day_end).toInt();
//       day_start = day_end + 1;
//       day_end = days_ch.indexOf(',', day_start);

//       days_in_num[daynum] = true;
//     }

//     for (int8_t i = 0; i < 24; i++) {
//       String hours_key = "hours_key" + String(i);
//       preferences.putBool(hours_key.c_str(), hours_num[i]);
//     }
//     for (int8_t i = 0; i < 7; i++) {
//       String days_key = "days_key" + String(i);
//       preferences.putBool(days_key.c_str(), days_in_num[i]);
//     }
//   } else {
//     return;
//   }
// }
