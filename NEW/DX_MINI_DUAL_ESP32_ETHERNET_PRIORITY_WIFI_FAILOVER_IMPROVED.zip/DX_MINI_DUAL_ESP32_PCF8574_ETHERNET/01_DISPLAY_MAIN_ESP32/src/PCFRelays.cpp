#include <Arduino.h>
#include <Wire.h>
#include "PCFRelays.h"

namespace {
TwoWire relayWire(1);
uint8_t shadow = 0xFF;     // Active-low: all PCF port pins HIGH = all relays OFF
bool ready = false;
uint32_t lastProbeMs = 0;
uint32_t lastHealthMs = 0;

bool transmit(uint8_t value) {
  relayWire.beginTransmission(PCF8574_ADDRESS);
  relayWire.write(value);
  const bool ack = relayWire.endTransmission() == 0;
  if (!ack) ready = false;
  return ack;
}
}

bool pcfRelayBegin() {
  relayWire.begin(PCF8574_SDA, PCF8574_SCL, 100000);
  relayWire.setTimeOut(20);
  shadow = 0xFF;
  ready = transmit(shadow);
  lastProbeMs = lastHealthMs = millis();
  Serial.printf("[PCF] 0x%02X SDA=%u SCL=%u ACK=%u (0xFF: P0/P1/P2 HIGH = relays OFF)\n",
                PCF8574_ADDRESS, PCF8574_SDA, PCF8574_SCL, ready);
  return ready;
}

bool pcfRelayReady() { return ready; }

// A full-byte shadow write is required: independently writing P0/P1/P2
// without preserving the other bits would cause unintentional relay changes.
bool pcfRelayWrite(uint8_t index, bool high) {
  if (index > 2 || !ready) return false;
  const uint8_t mask = static_cast<uint8_t>(1U << index);
  const uint8_t next = high ? static_cast<uint8_t>(shadow | mask)
                            : static_cast<uint8_t>(shadow & ~mask);
  if (next == shadow) return true;
  if (!transmit(next)) return false;
  shadow = next;
  return true;
}

void pcfRelayAllOff() {
  if (ready && transmit(0xFF)) shadow = 0xFF;
}

void pcfRelayService() {
  const uint32_t now = millis();
  if (!ready && now - lastProbeMs >= 2000UL) {
    lastProbeMs = now;
    // On I2C recovery, START WITH ALL OUTPUTS OFF. Do not replay an
    // old ON shadow after disconnect/reboot.
    if (transmit(0xFF)) {
      shadow = 0xFF;
      ready = true;
      Serial.println("[PCF] Reconnected, all relay outputs forced OFF");
    }
  } else if (ready && now - lastHealthMs >= 1000UL) {
    lastHealthMs = now;
    if (!transmit(shadow)) Serial.println("[PCF] I2C ACK LOST: relay state unconfirmed");
  }
}
