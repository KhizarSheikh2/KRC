#pragma once
#include <Arduino.h>

// Shared UART framing: !TYPE|CRC16HEX|PAYLOAD\n
// CRC16-CCITT over TYPE + '|' + PAYLOAD. Compact JSON contains no raw newline.
// Truncated/corrupt frames are ignored. All traffic is 3.3 V UART, 230400 8N1.
namespace DxLink {
constexpr size_t MAX_PAYLOAD = 2500;
constexpr size_t MAX_FRAME = MAX_PAYLOAD + 16;

inline uint16_t crcStep(uint16_t crc, uint8_t byte) {
  crc ^= static_cast<uint16_t>(byte) << 8;
  for (int i = 0; i < 8; ++i) crc = (crc & 0x8000) ? (crc << 1) ^ 0x1021 : crc << 1;
  return crc;
}
inline uint16_t checksum(char type, const String& payload) {
  uint16_t crc = crcStep(0xFFFF, static_cast<uint8_t>(type));
  crc = crcStep(crc, '|');
  for (size_t i=0; i<payload.length(); ++i) crc=crcStep(crc, payload[i]);
  return crc;
}
inline bool send(HardwareSerial &port, char type, const String& payload) {
  if (payload.length() > MAX_PAYLOAD || payload.indexOf('\n') >= 0 || payload.indexOf('\r') >= 0) return false;
  char header[11];
  snprintf(header, sizeof(header), "!%c|%04X|", type, checksum(type, payload));
  return port.write(reinterpret_cast<const uint8_t*>(header), strlen(header)) == strlen(header)
      && port.write(reinterpret_cast<const uint8_t*>(payload.c_str()), payload.length()) == payload.length()
      && port.write('\n') == 1;
}

struct Parser {
  char buffer[MAX_FRAME + 1]{};
  size_t length = 0;
  bool overflow = false;

  template <typename Handler>
  void poll(HardwareSerial &port, Handler handler) {
    size_t budget = 6144;
    while (port.available() && budget--) {
      const char c = static_cast<char>(port.read());
      if (c == '\n') {
        if (!overflow && length >= 8 && buffer[0] == '!' && buffer[2] == '|' && buffer[7] == '|') {
          buffer[length] = '\0';
          const char type = buffer[1];
          char crcStr[5] = {buffer[3], buffer[4], buffer[5], buffer[6], '\0'};
          char *end = nullptr;
          const unsigned long received = strtoul(crcStr, &end, 16);
          if (end == crcStr + 4) {
            const String payload(buffer + 8);
            if (received == checksum(type, payload)) handler(type, payload);
          }
        }
        length = 0;
        overflow = false;
      } else if (c == '\r') {
        continue;
      } else if (length < MAX_FRAME) {
        if (!overflow) buffer[length++] = c;
      } else {
        overflow = true;
      }
    }
  }
};
} // namespace DxLink
