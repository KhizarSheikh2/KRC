#pragma once
#include "BridgeProtocol.h"
#include <sys/time.h>
#include <time.h>

void bridgeOnMqttMessage(const String& topic, const String& json);

DxLink::Parser bridgeParser;
uint32_t bridgeLastAckMs = 0;
uint32_t bridgeDegradedUntilMs = 0;
uint32_t bridgeLastPingMs = 0;
String bridgePingToken;

inline bool bridgeMqttReady() {
  if (bridgeDegradedUntilMs && static_cast<int32_t>(millis() - bridgeDegradedUntilMs) < 0) return false;
  return bridge_mqtt_up && bridge_last_status_ms != 0 && bridgeLastAckMs != 0 &&
         (millis() - bridge_last_status_ms < 3500UL) &&
         (millis() - bridgeLastAckMs < 3500UL);
}

// Three-slot publish queue: one runtime and one temperature JSON. Each packet
// is confirmed by the Ethernet ESP32 after its MQTT publish() call returns.
// A successful ACK is transport-level acceptance (MQTT QoS 0), NOT broker QoS 1.
namespace {
struct BridgePendingPublication {
  uint32_t seq = 0;
  String payload;
  uint32_t sentAtMs = 0;
  uint8_t attempts = 0;
};
BridgePendingPublication bridgePending[3];
uint8_t bridgeQueueHead = 0;
uint8_t bridgeQueueSize = 0;
uint32_t bridgeNextSequence = 1;
constexpr uint32_t BRIDGE_PUB_ACK_TIMEOUT_MS = 2500;
constexpr uint8_t BRIDGE_PUB_MAX_ATTEMPTS = 2;

void bridgeClearPublications() {
  for (auto &entry : bridgePending) {
    entry.payload = String();
    entry.seq = 0;
    entry.attempts = 0;
    entry.sentAtMs = 0;
  }
  bridgeQueueHead = 0;
  bridgeQueueSize = 0;
}

void bridgePublishFailure() {
  Serial.println("[BRIDGE] MQTT publish not confirmed; giving WiFi a chance");
  bridgeClearPublications();
  bridgeDegradedUntilMs = millis() + 10000UL;
}

void bridgeOnPublishResult(const String &result) {
  if (!bridgeQueueSize) return;
  const int div = result.indexOf('|');
  if (div < 1 || div > 10) return;
  for (int i = 0; i < div; ++i)
    if (result[i] < '0' || result[i] > '9') return;
  const uint32_t id = static_cast<uint32_t>(strtoul(result.c_str(), nullptr, 10));
  BridgePendingPublication &entry = bridgePending[bridgeQueueHead];
  if (id != entry.seq || entry.attempts == 0) return;
  if (result.substring(div+1) != "1") {
    bridgePublishFailure();
    return;
  }
  Serial.printf("[BRIDGE] publish accepted by Ethernet MQTT seq=%lu\n", (unsigned long)id);
  entry.payload = String();
  entry.seq = 0;
  entry.attempts = 0;
  bridgeQueueHead = (bridgeQueueHead + 1U) % 3U;
  --bridgeQueueSize;
}

void bridgeServicePublications() {
  if (!bridgeQueueSize) return;
  if (!bridgeMqttReady()) {
    bridgeClearPublications(); // publish a fresh snapshot on fallback/recovery
    return;
  }
  BridgePendingPublication &entry = bridgePending[bridgeQueueHead];
  const uint32_t now = millis();
  if (entry.attempts && now - entry.sentAtMs < BRIDGE_PUB_ACK_TIMEOUT_MS) return;
  if (entry.attempts >= BRIDGE_PUB_MAX_ATTEMPTS) {
    bridgePublishFailure();
    return;
  }
  if (DxLink::send(Serial2, 'P', String(entry.seq) + '|' + entry.payload)) {
    entry.sentAtMs = now;
    ++entry.attempts;
  } else bridgePublishFailure();
}
} // namespace

void bridgeInit() {
  // Prevent retry-ID collision if the main ESP32 reboots while Ethernet stays up.
  bridgeNextSequence = esp_random();
  if (bridgeNextSequence == 0) bridgeNextSequence = 1;
  Serial2.setRxBufferSize(4096);
  Serial2.setTxBufferSize(4096);
  Serial2.begin(BRIDGE_BAUD, SERIAL_8N1, BRIDGE_UART_RX, BRIDGE_UART_TX);
  Serial.println("[BRIDGE] UART2 display RX16 TX17 <-> Ethernet ESP32 TX17 RX16");
}

void bridgePoll() {
  // Supply valid SNTP time to the Ethernet board when its router blocks NTP.
  // This is bootstrap assistance, not a replacement for TLS certificate checks.
  static uint32_t lastClockSyncSentMs = 0;
  if (time(nullptr) > 1609459200 && millis() - lastClockSyncSentMs >= 10000UL) {
    lastClockSyncSentMs = millis();
    DxLink::send(Serial2, 'T', String((uint32_t)time(nullptr)));
  }
  if (millis() - bridgeLastPingMs >= 1000UL) {
    bridgeLastPingMs = millis();
    bridgePingToken = String(bridgeLastPingMs);
    DxLink::send(Serial2, 'Q', bridgePingToken);
  }
  bridgeParser.poll(Serial2, [](char type, const String& payload) {
    if (type == 'R') {
      bridgeOnPublishResult(payload);
    } else if (type == 'A') {
      if (payload == bridgePingToken) bridgeLastAckMs = millis();
    } else
    if (type == 'B') {
      StaticJsonDocument<512> status;
      if (deserializeJson(status, payload)) return;
      bridge_last_status_ms = millis();
      bridge_mqtt_up = status["mqtt"] | false;
      eth_connected = bridge_mqtt_up && (status["network"] | false);
      w5500_detected = status["chip"] | false;
      ethernetLinkPresent = status["link"] | false;
      ethernet_using_dhcp = status["dhcp"] | false;
      ethernetIpAddress = status["ip"].as<String>();
      ethernetMacAddress = status["mac"].as<String>();
      // The main controller owns the scheduler: sync its RTC even if it has
      // no Wi-Fi, using the Ethernet bridge's validated NTP timestamp.
      const time_t bridgeUtc = status["time"] | static_cast<time_t>(0);
      if (bridgeUtc > 1609459200 && (time(nullptr) <= 1609459200 ||
          labs(static_cast<long>(time(nullptr) - bridgeUtc)) > 15)) {
        struct timeval tv{bridgeUtc, 0};
        settimeofday(&tv, nullptr);
      }
    } else if (type == 'M') {
      // Ethernet sends only MQTT messages from the ORIGINAL app subscribe path.
      const int separator = payload.indexOf('\t');
      if (separator <= 0 || separator >= 160) return;
      if (activeNetwork == NetworkTransport::ETHERNET)
        bridgeOnMqttMessage(payload.substring(0, separator), payload.substring(separator + 1));
    }
  });
  if (bridge_last_status_ms && millis() - bridge_last_status_ms > 3500UL) {
    bridge_mqtt_up = false;
    bridgeClearPublications();
    eth_connected = false;
    ethernetLinkPresent = false;
  }
  bridgeServicePublications();
}

inline bool bridgePublish(const String& topic, const String& json) {
  if (!bridgeMqttReady() || bridgeQueueSize >= 3) return false;
  if (topic.length() > 160 || topic.indexOf('\t') >= 0 ||
      json.indexOf('\n') >= 0 || json.indexOf('\r') >= 0) return false;
  const String payload = topic + '\t' + json;
  if (payload.length() + 12 >= DxLink::MAX_PAYLOAD) return false;
  BridgePendingPublication &entry = bridgePending[(bridgeQueueHead + bridgeQueueSize) % 3];
  entry.seq = bridgeNextSequence++;
  if (bridgeNextSequence == 0) bridgeNextSequence = 1;
  entry.payload = payload;
  entry.attempts = 0;
  entry.sentAtMs = 0;
  ++bridgeQueueSize;
  bridgeServicePublications();
  return true; // queued: an R acknowledgement confirms the Ethernet MQTT write
}
