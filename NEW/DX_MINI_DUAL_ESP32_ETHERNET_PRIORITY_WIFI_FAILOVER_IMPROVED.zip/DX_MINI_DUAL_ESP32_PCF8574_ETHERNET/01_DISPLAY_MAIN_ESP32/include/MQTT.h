#pragma once

#include "Scheduler.h"

void temp_sensor_select_publish();

bool mqttConnected() {
  if (activeNetwork == NetworkTransport::ETHERNET) return bridgeMqttReady();
  if (activeNetwork == NetworkTransport::WIFI) return wifiMqttClient.connected() && wifi_mqtt_subscribed;
  return false;
}

bool activeNetworkReady() {
  return bridgeMqttReady() || (WiFi.status() == WL_CONNECTED && wifiMqttClient.connected() && wifi_mqtt_subscribed);
}

bool mqttPublish(const String& topic, const char* json, bool retain) {
  if (!mqttConnected()) return false;
  if (activeNetwork == NetworkTransport::ETHERNET)
    return bridgePublish(topic, String(json)); // queue accepted; Ethernet result logged on UART ACK.
  return wifiMqttClient.publish(topic.c_str(), json, retain);
}

// Main retained runtime JSON. Existing DX-MINI keys and value formats are kept
// for app compatibility; network diagnostics are added as native JSON fields.
void publishJson() {
  if (!mqttConnected()) return;

  StaticJsonDocument<1536> doc;
  doc["powerState"] = String(PowerState);
  doc["returnTemp"] = String(ReturnTemp);
  doc["supplyTemp"] = String(SupplyTemp);
  doc["dischargeTemp"] = String(dischargeTemp);

  doc["returnSp"] = String(ReturnSp);
  doc["dischargeSp"] = String(dischargeSp);
  doc["returnTempAlarm"] = returnTempAlarm;
  doc["dischargeTempAlarm"] = dischargeTempAlarm;

  doc["r1Status"] = String(EVAP_COOL_SYSTEM_STATUS);
  doc["r2Status"] = String(AUTO_WASH_SYSTEM_STATUS);
  doc["r3Status"] = String(UNIT_COMMAND_STATUS);

  doc["r1Sw"] = String(EVAP_COOL_SYSTEM_SWITCH);
  doc["r2Sw"] = String(AUTO_WASH_SYSTEM_SWITCH);
  doc["r3Sw"] = String(UNIT_COMMAND_SWITCH);
  doc["modeSw"] = String(MODE_SWITCH);
  doc["faultSw"] = String(FAULT_SWITCH);
  doc["systemStatus"] = String(PowerState);

  doc["timesch"] = timesch;
  doc["timeschen"] = String(timeschen);
  doc["tmatched"] = tmatched;
  doc["mac_address"] = macaddress;
  doc["ip_address"] = myIP;

  // Network metadata for diagnostics / app display.
  doc["network"] = activeNetworkLabel();
  doc["mqtt_status"] = mqttConnected() ? 1 : 0;
  doc["w5500_detected"] = w5500_detected ? 1 : 0;
  doc["ethernet_link"] = ethernetLinkPresent ? 1 : 0;
  doc["ethernet_status"] = eth_connected ? 1 : 0;
  doc["ethernet_ip"] = ethernetIpAddress;
  doc["ethernet_mac"] = ethernetMacAddress;
  doc["ethernet_addressing"] = eth_connected ? (ethernet_using_dhcp ? "DHCP" : "STATIC") : "OFF";
  doc["wifi_status"] = WiFi.status() == WL_CONNECTED ? 1 : 0;
  doc["wifi_ip"] = WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("");
  doc["ssid"] = WiFi.status() == WL_CONNECTED ? WiFi.SSID() : String("");

  char jsonBuffer[1800];
  const size_t n = serializeJson(doc, jsonBuffer, sizeof(jsonBuffer));
  const bool mainPublished = mqttPublish(device_topic_p, jsonBuffer, true);

  Serial.printf("[MQTT] Main JSON %s via %s | bytes=%u | topic=%s\n",
                mainPublished ? (activeNetwork == NetworkTransport::ETHERNET ? "QUEUED" : "PUBLISHED") : "FAILED",
                activeNetworkLabel(),
                static_cast<unsigned>(n),
                device_topic_p.c_str());

  // Keep the original DX-MINI behavior: configuration JSON immediately follows
  // each main runtime JSON publication.
  temp_sensor_select_publish();
}

void temp_sensor_select_publish() {
  if (!mqttConnected()) return;

  DynamicJsonDocument json_doc(768);
  float temperature_read = SENSOR_DISCONNECTED;

  const int count = constrain(numberOfDevices, 0, MAX_SENSORS);
  for (int i = 0; i < count; i++) {
    if (addressIsZero(tempSensorAddresses[i])) continue;

    read_temp(temperature_read, tempSensorAddresses[i]);
    const String addressString = getAddressString(tempSensorAddresses[i]);

    if (i == 0) {
      json_doc["address1"] = addressString;
      json_doc["temp1"] = temperature_read;
    } else if (i == 1) {
      json_doc["address2"] = addressString;
      json_doc["temp2"] = temperature_read;
    } else if (i == 2) {
      json_doc["address3"] = addressString;
      json_doc["temp3"] = temperature_read;
    }

    json_doc[addressString] = 0;
    if (temp1Assigned && compareAddresses(tempSensorAddresses[i], temp1Address)) {
      json_doc[addressString] = 1;
    } else if (temp2Assigned && compareAddresses(tempSensorAddresses[i], temp2Address)) {
      json_doc[addressString] = 2;
    } else if (temp3Assigned && compareAddresses(tempSensorAddresses[i], temp3Address)) {
      json_doc[addressString] = 3;
    }
  }

  // Legacy app contract: offset1/2/3 correspond to address1/2/3.
  json_doc["offset1"] = offset1;
  json_doc["offset2"] = offset2;
  json_doc["offset3"] = offset3;
  // Explicit logical-channel calibration is also published for diagnostics.
  json_doc["dischargeOffset"] = discharge_temp_offset;
  json_doc["supplyOffset"] = supply_temp_offset;
  json_doc["returnOffset"] = return_air_temp_offset;
  json_doc["network"] = activeNetworkLabel();

  char buffer[768];
  const size_t n = serializeJson(json_doc, buffer, sizeof(buffer));
  const String topic = device_topic_p + "/temperature_config_DXM";
  const bool published = mqttPublish(topic, buffer, true);
  Serial.printf("[MQTT] Temperature JSON %s | bytes=%u | topic=%s\n",
                published ? (activeNetwork == NetworkTransport::ETHERNET ? "QUEUED" : "PUBLISHED") : "FAILED",
                static_cast<unsigned>(n),
                topic.c_str());
}

void Extract_temp_config(const String& incoming_message) {
  received_doc.clear();
  const DeserializationError error = deserializeJson(received_doc, incoming_message);
  if (error) {
    Serial.print("[MQTT] Temperature JSON deserialization failed: ");
    Serial.println(error.c_str());
    return;
  }

  refreshTemperatureDeviceList();
  const int count = constrain(numberOfDevices, 0, MAX_SENSORS);

  // Apply assignments first, then offsets. This lets one packet both assign a
  // physical probe and calibrate it.
  for (int i = 0; i < count; i++) {
    if (addressIsZero(tempSensorAddresses[i])) continue;
    const String addressString = getAddressString(tempSensorAddresses[i]);
    if (received_doc.containsKey(addressString)) {
      const int sensor_selected = received_doc[addressString].as<int>();
      if (sensor_selected >= 0 && sensor_selected <= 3) {
        Serial.printf("[TEMP] %s -> logical channel %d\n",
                      addressString.c_str(), sensor_selected);
        assignSensor(sensor_selected, tempSensorAddresses[i]);
      }
    }
  }

  preferences.begin("values", false);
  for (int i = 0; i < count; i++) {
    if (addressIsZero(tempSensorAddresses[i])) continue;
    const String addressString = getAddressString(tempSensorAddresses[i]);
    const String key_offset = "offset" + addressString;
    if (received_doc.containsKey(key_offset)) {
      const int16_t receivedOffset = received_doc[key_offset].as<int16_t>();
      setoffset(tempSensorAddresses[i], receivedOffset);
    }
  }
  preferences.end();
}

void update_values_from_json(const char* key, int& value_variable) {
  if (!received_doc.containsKey(key)) return;
  const int incoming = received_doc[key].as<int>();
  if (incoming != value_variable) {
    value_variable = incoming;
    preferences.putInt(key, value_variable);
  }
}

void Extract_by_json(const String& incomingMessage) {
  received_doc.clear();
  const DeserializationError error = deserializeJson(received_doc, incomingMessage);
  if (error) {
    Serial.print("[MQTT] Runtime JSON deserialization failed: ");
    Serial.println(error.c_str());
    return;
  }

  Serial.print("[MQTT] RX: ");
  Serial.println(incomingMessage);

  preferences.begin("values", false);
  if (received_doc.containsKey("dischargeSp")) {
    int incoming = received_doc["dischargeSp"].as<int>();
    if (incoming >= 0 && incoming <= 200 && incoming != dischargeSp) {
      dischargeSp = incoming; preferences.putInt("dischargeSp", incoming);
    }
  }
  if (received_doc.containsKey("returnSp")) {
    int incoming = received_doc["returnSp"].as<int>();
    if (incoming >= 0 && incoming <= 100 && incoming != ReturnSp) {
      ReturnSp = incoming; preferences.putInt("returnSp", incoming);
    }
  }

  const int previousMode = MODE_SWITCH;
  update_values_from_json("modeSw", MODE_SWITCH);
  MODE_SWITCH = MODE_SWITCH ? 1 : 0;

  // Relay commands are manual commands. AUTO mode owns all three relays and
  // therefore ignores r1Sw/r2Sw/r3Sw coming from the cloud.
  if (MODE_SWITCH == 0 && previousMode == MODE_SWITCH) {
    update_values_from_json("r1Sw", EVAP_COOL_SYSTEM_SWITCH);
    update_values_from_json("r2Sw", AUTO_WASH_SYSTEM_SWITCH);
    update_values_from_json("r3Sw", UNIT_COMMAND_SWITCH);
    EVAP_COOL_SYSTEM_SWITCH = EVAP_COOL_SYSTEM_SWITCH ? 1 : 0;
    AUTO_WASH_SYSTEM_SWITCH = AUTO_WASH_SYSTEM_SWITCH ? 1 : 0;
    UNIT_COMMAND_SWITCH = UNIT_COMMAND_SWITCH ? 1 : 0;
    if (AUTO_WASH_SYSTEM_SWITCH || AUTO_WASH_SYSTEM_STATUS) {
      EVAP_COOL_SYSTEM_SWITCH = 0;
      UNIT_COMMAND_SWITCH = 0;
    }
    preferences.putInt("r1Sw", EVAP_COOL_SYSTEM_SWITCH);
    preferences.putInt("r2Sw", AUTO_WASH_SYSTEM_SWITCH);
    preferences.putInt("r3Sw", UNIT_COMMAND_SWITCH);
  }

  // Entering MANUAL always starts from a known-safe all-OFF state. The next
  // manual command may then turn an output on through the normal 5 s delay.
  if (previousMode != MODE_SWITCH && MODE_SWITCH == 0) {
    EVAP_COOL_SYSTEM_SWITCH = 0;
    AUTO_WASH_SYSTEM_SWITCH = 0;
    UNIT_COMMAND_SWITCH = 0;
    EVAP_COOL_SYSTEM_STATUS = false;
    AUTO_WASH_SYSTEM_STATUS = false;
    UNIT_COMMAND_STATUS = false;
    EVAP_COOL_SYSTEM_PENDING = -1;
    AUTO_WASH_SYSTEM_PENDING = -1;
    UNIT_COMMAND_PENDING = -1;
    writeRelay(EVAP_COOL_SYSTEM, false);
    writeRelay(AUTO_WASH_SYSTEM, false);
    writeRelay(UNIT_COMMAND, false);
    preferences.putInt("r1Sw", 0);
    preferences.putInt("r2Sw", 0);
    preferences.putInt("r3Sw", 0);
  }

  update_values_from_json("faultSw", FAULT_SWITCH);

  if (received_doc.containsKey("powerState")) {
    const bool newPowerState = received_doc["powerState"].as<int>() != 0;
    if (newPowerState != PowerState) {
      PowerState = newPowerState;
      preferences.putBool("PowerState", PowerState);
    }
  }

  // Power OFF is an immediate safety action and cancels delayed transitions.
  if (!PowerState) {
    EVAP_COOL_SYSTEM_SWITCH = 0;
    AUTO_WASH_SYSTEM_SWITCH = 0;
    UNIT_COMMAND_SWITCH = 0;
    EVAP_COOL_SYSTEM_STATUS = false;
    AUTO_WASH_SYSTEM_STATUS = false;
    UNIT_COMMAND_STATUS = false;
    EVAP_COOL_SYSTEM_PENDING = -1;
    AUTO_WASH_SYSTEM_PENDING = -1;
    UNIT_COMMAND_PENDING = -1;
    writeRelay(EVAP_COOL_SYSTEM, false);
    writeRelay(AUTO_WASH_SYSTEM, false);
    writeRelay(UNIT_COMMAND, false);
    preferences.putInt("r1Sw", 0);
    preferences.putInt("r2Sw", 0);
    preferences.putInt("r3Sw", 0);
  }
  preferences.end();

  preferences.begin("timeenable", false);
  if (received_doc.containsKey("timeschen")) {
    const int newEnable = received_doc["timeschen"].as<int>() ? 1 : 0;
    if (newEnable != timeschen) {
      timeschen = newEnable;
      preferences.putInt("timeschen", timeschen);
    }
  }

  if (received_doc.containsKey("timesch")) {
    const String incomingSchedule = received_doc["timesch"].as<String>();
    if (incomingSchedule.length() && incomingSchedule != timesch) {
      timesch = incomingSchedule;
      preferences.putString("timesch", timesch);
      parse_schedule(timesch);
      Serial.print("[SCHED] Updated: ");
      Serial.println(timesch);
    }
  }
  preferences.end();

  if (AUTO_WASH_SYSTEM_SWITCH || AUTO_WASH_SYSTEM_STATUS) {
    EVAP_COOL_SYSTEM_SWITCH = UNIT_COMMAND_SWITCH = 0;
    if (writeRelay(EVAP_COOL_SYSTEM, false)) EVAP_COOL_SYSTEM_STATUS = false;
    if (writeRelay(UNIT_COMMAND, false)) UNIT_COMMAND_STATUS = false;
    EVAP_COOL_SYSTEM_PENDING = UNIT_COMMAND_PENDING = -1;
  }
  updateDisplay();
}

void DEVICE_INIT() {
  Serial.println("[INIT] Loading saved DX-MINI settings");

  preferences.begin("values", false);
  PowerState = preferences.getBool("PowerState", true);
  dischargeSp = constrain(preferences.getInt("dischargeSp", 0), 0, 200);
  ReturnSp = constrain(preferences.getInt("returnSp", 0), 0, 100);

  EVAP_COOL_SYSTEM_SWITCH = preferences.getInt("r1Sw", 0) ? 1 : 0;
  AUTO_WASH_SYSTEM_SWITCH = preferences.getInt("r2Sw", 0) ? 1 : 0;
  UNIT_COMMAND_SWITCH = preferences.getInt("r3Sw", 0) ? 1 : 0;
  MODE_SWITCH = preferences.getInt("modeSw", 0) ? 1 : 0;
  FAULT_SWITCH = preferences.getInt("faultSw", 0);

  const bool savedTemp1Assigned = preferences.getBool("temp1_assign", false);
  size_t len1 = 0;
  if (savedTemp1Assigned && preferences.isKey("temp1Address")) {
    len1 = preferences.getBytes("temp1Address", temp1Address, sizeof(DeviceAddress));
  }
  temp1Assigned = savedTemp1Assigned && len1 == sizeof(DeviceAddress) && !addressIsZero(temp1Address);
  if (!temp1Assigned) memset(temp1Address, 0, sizeof(DeviceAddress));

  const bool savedTemp2Assigned = preferences.getBool("temp2_assign", false);
  size_t len2 = 0;
  if (savedTemp2Assigned && preferences.isKey("temp2Address")) {
    len2 = preferences.getBytes("temp2Address", temp2Address, sizeof(DeviceAddress));
  }
  temp2Assigned = savedTemp2Assigned && len2 == sizeof(DeviceAddress) && !addressIsZero(temp2Address);
  if (!temp2Assigned) memset(temp2Address, 0, sizeof(DeviceAddress));

  const bool savedTemp3Assigned = preferences.getBool("temp3_assign", false);
  size_t len3 = 0;
  if (savedTemp3Assigned && preferences.isKey("temp3Address")) {
    len3 = preferences.getBytes("temp3Address", temp3Address, sizeof(DeviceAddress));
  }
  temp3Assigned = savedTemp3Assigned && len3 == sizeof(DeviceAddress) && !addressIsZero(temp3Address);
  if (!temp3Assigned) memset(temp3Address, 0, sizeof(DeviceAddress));

  offset1 = preferences.getInt("offset1", 0);
  offset2 = preferences.getInt("offset2", 0);
  offset3 = preferences.getInt("offset3", 0);

  if (!PowerState) {
    EVAP_COOL_SYSTEM_SWITCH = 0;
    AUTO_WASH_SYSTEM_SWITCH = 0;
    UNIT_COMMAND_SWITCH = 0;
  }
  preferences.end();

  // DS18B20 discovery order determines legacy offset1/2/3. Derive the logical
  // control calibration from the restored ROM assignments.
  refreshTemperatureDeviceList();
  refreshLogicalOffsetsFromAssignments();

  preferences.begin("timeenable", false);
  timesch = preferences.getString("timesch", "hoursch=24|daysch=7");
  timeschen = preferences.getInt("timeschen", 0) ? 1 : 0;
  preferences.end();

  parse_schedule(timesch);
  Serial.printf("[INIT] power=%d mode=%s schedule=%d %s\n",
                PowerState ? 1 : 0,
                MODE_SWITCH ? "AUTO" : "MANUAL",
                timeschen,
                timesch.c_str());
}

void callback(char* topic, byte* message, unsigned int length) {
  if (activeNetwork != NetworkTransport::WIFI) return;
  String messageTemp;
  messageTemp.reserve(length + 1);
  for (unsigned int i = 0; i < length; i++) {
    messageTemp += static_cast<char>(message[i]);
  }

  const String topicString(topic);
  if (topicString == device_topic_s_1) {
    message_received = true;
    Extract_by_json(messageTemp);
  } else if (topicString == device_topic_s_2) {
    message_received_config = true;
    Extract_temp_config(messageTemp);
  }
}

void reconnect() {
  if (wifiMqttClient.connected() && wifi_mqtt_subscribed) return;
  if (WiFi.status() != WL_CONNECTED) return;
  Serial.printf("[WIFI-MQTT] Connecting %s over WiFi...\n", devicename.c_str());
  const String clientId = devicename + "-wifi";
  if (wifiMqttClient.connected() || wifiMqttClient.connect(clientId.c_str())) {
    wifi_mqtt_subscribed = wifiMqttClient.subscribe(device_topic_s_m.c_str());
    if (!wifi_mqtt_subscribed) {
      Serial.println("[WIFI-MQTT] subscription failed; reconnecting later");
      wifiMqttClient.disconnect();
    }
  } else {
    Serial.printf("[WIFI-MQTT] reconnect failed rc=%d\n", wifiMqttClient.state());
  }
}
// Messages from Ethernet ESP32 use the same app topic parser as Wi-Fi MQTT.
void bridgeOnMqttMessage(const String& topic, const String& json) {
  if (topic == device_topic_s_1) {
    message_received = true;
    Extract_by_json(json);
  } else if (topic == device_topic_s_2) {
    message_received_config = true;
    Extract_temp_config(json);
  }
}
