#pragma once

#include <sys/time.h>
#include <time.h>

// MQTT callback/reconnect are defined in MQTT.h, which is included before this
// file in main.cpp.
void reconnect();

void notFound(AsyncWebServerRequest* request) {
  request->send(404, "application/json", "{\"status\":\"error\",\"message\":\"Not found\"}");
}

void saveCredentials(const String& newSsid, const String& newPassword) {
  preferences.begin("wifi-creds", false);
  preferences.putString("ssid", newSsid);
  preferences.putString("password", newPassword);
  preferences.end();
}

bool loadCredentials(String& outSsid, String& outPassword) {
  preferences.begin("wifi-creds", true);
  outSsid = preferences.getString("ssid", "");
  outPassword = preferences.getString("password", "");
  preferences.end();
  return outSsid.length() > 0 && outPassword.length() > 0;
}

void startAccessPoint() {
  // Keep AP + STA together. This lets the configuration AP stay reachable while
  // Wi-Fi remains ready as Ethernet's instant fallback.
  WiFi.mode(WIFI_AP_STA);
  const uint8_t channel = WiFi.status() == WL_CONNECTED ? WiFi.channel() : 1;
  WiFi.softAPdisconnect(false);
  delay(20);
  WiFi.softAP(devicename.c_str(), "bitahomes", channel, 1);
  wifi_ap_mode = true;
  wifi_setting_time = millis();

  Serial.print("[WIFI] Provisioning AP: ");
  Serial.print(devicename);
  Serial.print(" | IP: ");
  Serial.println(WiFi.softAPIP());
}

void connectToWiFi(const String& targetSsid, const String& targetPassword) {
  WiFi.mode(WIFI_AP_STA);
  WiFi.config(INADDR_NONE, INADDR_NONE, INADDR_NONE, INADDR_NONE);
  WiFi.setHostname(hostname.c_str());
  WiFi.setAutoReconnect(true);
  WiFi.setSleep(false);

  Serial.print("[WIFI] Connecting to: ");
  Serial.println(targetSsid);
  WiFi.begin(targetSsid.c_str(), targetPassword.c_str());

  const unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < 8000UL) {
    delay(50);
  }

  if (WiFi.status() == WL_CONNECTED) {
    is_wifi_connected = true;
    wifi_channel = WiFi.channel();
    Serial.print("[WIFI] Connected | IP: ");
    Serial.println(WiFi.localIP());
    // Keep the DX-MINI AP available on the same RF channel as the STA link.
    WiFi.softAPdisconnect(false);
    delay(20);
    WiFi.softAP(devicename.c_str(), "bitahomes", wifi_channel, 1);
    wifi_ap_mode = true;
  } else {
    is_wifi_connected = false;
    Serial.println("[WIFI] Connection timeout; AP remains available");
    startAccessPoint();
  }
}

// Test new credentials without destroying the last known-good fallback.
bool wifi_check(const String& candidateSsid, const String& candidatePassword) {
  const String oldSsid = ssid;
  const String oldPassword = password;

  WiFi.mode(WIFI_AP_STA);
  WiFi.disconnect(false, false);
  delay(50);
  WiFi.begin(candidateSsid.c_str(), candidatePassword.c_str());

  Serial.print("[WIFI] Testing credentials for: ");
  Serial.println(candidateSsid);

  const unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < 8000UL) {
    delay(25);
  }

  if (WiFi.status() == WL_CONNECTED) {
    ssid = candidateSsid;
    password = candidatePassword;
    saveCredentials(ssid, password);
    is_wifi_connected = true;
    wifi_channel = WiFi.channel();
    WiFi.softAPdisconnect(false);
    delay(20);
    WiFi.softAP(devicename.c_str(), "bitahomes", wifi_channel, 1);
    wifi_ap_mode = true;
    Serial.print("[WIFI] Credentials verified | IP: ");
    Serial.println(WiFi.localIP());
    return true;
  }

  Serial.println("[WIFI] New credentials failed; keeping previous saved credentials");
  is_wifi_connected = false;

  // Restore the known-good station connection when one existed.
  if (oldSsid.length() && oldPassword.length()) {
    ssid = oldSsid;
    password = oldPassword;
    WiFi.begin(ssid.c_str(), password.c_str());
  }
  startAccessPoint();
  return false;
}

void server_setup() {
  // ESPAsyncWebServer can split a JSON body across multiple callback frames.
  // Keep a small per-request accumulator so Wi-Fi provisioning remains reliable
  // even when the app/phone fragments the POST body.
  static String wifiConfigBody;
  static AsyncWebServerRequest* wifiConfigRequest = nullptr;
  static uint32_t wifiConfigStartedMs = 0;

  server.on("/wifi_param_by_app", HTTP_OPTIONS, [](AsyncWebServerRequest* request) {
    AsyncWebServerResponse* response = request->beginResponse(200);
    response->addHeader("Access-Control-Allow-Origin", "*");
    response->addHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    response->addHeader("Access-Control-Allow-Headers", "Content-Type");
    request->send(response);
  });

  server.on(
      "/wifi_param_by_app", HTTP_POST,
      [](AsyncWebServerRequest* request) {}, nullptr,
      [](AsyncWebServerRequest* request, uint8_t* data, size_t len, size_t index, size_t total) {
        if (total == 0 || total > 512) {
          if (index == 0) {
            request->send(413, "application/json",
                          "{\"status\":\"error\",\"message\":\"JSON body too large\"}");
          }
          return;
        }

        if (index == 0) {
          if (wifiConfigRequest && wifiConfigRequest != request &&
              millis() - wifiConfigStartedMs < 5000UL) {
            request->send(409, "application/json",
                          "{\"status\":\"error\",\"message\":\"Another WiFi request is in progress\"}");
            return;
          }
          wifiConfigRequest = request;
          wifiConfigStartedMs = millis();
          wifiConfigBody = "";
          wifiConfigBody.reserve(total + 1);
        }

        if (wifiConfigRequest != request) return;
        wifiConfigBody.concat(reinterpret_cast<const char*>(data), len);
        if (index + len < total) return;

        StaticJsonDocument<384> doc;
        const DeserializationError error = deserializeJson(doc, wifiConfigBody);
        if (error) {
          wifiConfigBody = "";
          wifiConfigRequest = nullptr;
          request->send(400, "application/json",
                        "{\"status\":\"error\",\"message\":\"Invalid JSON\"}");
          return;
        }

        const String candidateSsid = doc["ssid"] | "";
        const String candidatePassword = doc["password"] | "";
        if (candidateSsid.isEmpty() || candidatePassword.isEmpty()) {
          wifiConfigBody = "";
          wifiConfigRequest = nullptr;
          request->send(400, "application/json",
                        "{\"status\":\"error\",\"message\":\"SSID or password missing\"}");
          return;
        }

        const bool connected = wifi_check(candidateSsid, candidatePassword);

        StaticJsonDocument<384> responseDoc;
        responseDoc["status"] = connected ? "success" : "error";
        responseDoc["message"] = connected ? "WiFi credentials verified and saved"
                                            : "WiFi connection failed; previous credentials kept";
        responseDoc["wifi_status"] = connected ? 1 : 0;
        responseDoc["active_network"] = activeNetworkLabel();
        responseDoc["ethernet_status"] = eth_connected ? 1 : 0;

        String responseBody;
        serializeJson(responseDoc, responseBody);
        AsyncWebServerResponse* response = request->beginResponse(200, "application/json", responseBody);
        response->addHeader("Access-Control-Allow-Origin", "*");
        wifiConfigBody = "";
        wifiConfigRequest = nullptr;
        request->send(response);
      });

  server.on("/network_status", HTTP_GET, [](AsyncWebServerRequest* request) {
    StaticJsonDocument<768> doc;
    doc["device"] = devicename;
    doc["active_network"] = activeNetworkLabel();
    doc["active_ip"] = myIP;
    doc["mqtt_status"] = mqttConnected() ? 1 : 0;
    doc["wifi_connected"] = WiFi.status() == WL_CONNECTED ? 1 : 0;
    doc["wifi_ssid"] = WiFi.status() == WL_CONNECTED ? WiFi.SSID() : String("");
    doc["wifi_ip"] = WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("");
    doc["w5500_detected"] = w5500_detected ? 1 : 0;
    doc["ethernet_link"] = ethernetLinkPresent ? 1 : 0;
    doc["ethernet_connected"] = eth_connected ? 1 : 0;
    doc["ethernet_ip"] = ethernetIpAddress;
    doc["ethernet_mac"] = ethernetMacAddress;
    doc["ethernet_addressing"] = eth_connected ? (ethernet_using_dhcp ? "DHCP" : "STATIC") : "OFF";

    String body;
    serializeJson(doc, body);
    AsyncWebServerResponse* response = request->beginResponse(200, "application/json", body);
    response->addHeader("Access-Control-Allow-Origin", "*");
    request->send(response);
  });

  server.onNotFound(notFound);
  server.begin();
  Serial.println("[HTTP] Configuration server started");
}

// No local W5500 SPI/SSL on the JC2432W328. All Ethernet messages arrive
// through BridgeUart.h. On link/MQTT failure WiFi MQTT becomes active.
void networkSetup() {
  wifiClient.setCACert(root_ca);
  wifiClient.setCertificate(client_cert);
  wifiClient.setPrivateKey(client_key);
  wifiClient.setTimeout(4000);
  wifiMqttClient.setServer(mqtt_server, mqtt_port);
  wifiMqttClient.setCallback(callback);
  wifiMqttClient.setBufferSize(2048);
  wifiMqttClient.setKeepAlive(15);
  wifiMqttClient.setSocketTimeout(3);
  configTime(0, 0, "pool.ntp.org", "time.google.com"); // async SNTP, no blocking wait
}

void networkService() {
  static uint32_t lastWifiRetry = 0;
  static uint32_t lastMqttRetry = 0;
  static bool publishFreshSnapshot = true;
  const uint32_t now = millis();

  if (ssid.length() && password.length() && WiFi.status() != WL_CONNECTED &&
      now - lastWifiRetry >= 15000UL) {
    lastWifiRetry = now;
    WiFi.begin(ssid.c_str(), password.c_str());
  }

  // Wi-Fi MQTT is connected even while Ethernet owns publishing. Standby Wi-Fi
  // uses a separate AWS client ID and handles incoming app commands ONLY when
  // active. This reduces switchover latency to a few loop iterations.
  const bool wifiLink = WiFi.status() == WL_CONNECTED;
  if (!wifiLink) {
    wifi_mqtt_subscribed = false;
    if (wifiMqttClient.connected()) wifiMqttClient.disconnect();
  } else if (wifiMqttClient.connected()) {
    if (!wifiMqttClient.loop()) wifi_mqtt_subscribed = false;
  }
  const uint32_t retryInterval = activeNetwork == NetworkTransport::ETHERNET ? 30000UL : 5000UL;
  if (wifiLink && (!wifiMqttClient.connected() || !wifi_mqtt_subscribed) &&
      now - lastMqttRetry >= retryInterval &&
      !(MODE_SWITCH == 0 && (EVAP_COOL_SYSTEM_PENDING != -1 ||
          AUTO_WASH_SYSTEM_PENDING != -1 || UNIT_COMMAND_PENDING != -1))) {
    lastMqttRetry = now;
    reconnect();
  }

  // Ethernet must have acknowledged UART heartbeats and an AUTHENTICATED,
  // SUBSCRIBED MQTT connection; Wi-Fi must also have an active MQTT session.
  // Short guard prevents flapping; failures fail over as soon as detected.
  const bool ethReady = bridgeMqttReady();
  const bool wifiReady = wifiLink && wifiMqttClient.connected() && wifi_mqtt_subscribed;
  const NetworkTransport wanted = networkPriority.select(ethReady, wifiReady, millis());
  eth_connected = wanted == NetworkTransport::ETHERNET;
  if (wanted != activeNetwork) {
    const NetworkTransport was = activeNetwork;
    activeNetwork = wanted;
    myIP = wanted == NetworkTransport::ETHERNET ? ethernetIpAddress
         : wanted == NetworkTransport::WIFI ? WiFi.localIP().toString() : String("");
    publishFreshSnapshot = true;
    Serial.printf("[NET] %d -> %d (%s) | eth=%d wifiMQTT=%d\n",
                  int(was), int(wanted), myIP.c_str(), ethReady, wifiReady);
    updateDisplay();
  }

  // Retained snapshots refresh the cloud on every transport change, even if
  // the last scheduled report was lost while an interface went offline.
  if (publishFreshSnapshot && mqttConnected()) {
    publishFreshSnapshot = false;
    publishJson();
  }
}
