#pragma once

#include <math.h>

bool compareAddresses(const DeviceAddress a, const DeviceAddress b) {
  for (uint8_t i = 0; i < 8; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}

bool addressIsZero(const DeviceAddress address) {
  for (uint8_t i = 0; i < 8; ++i) {
    if (address[i] != 0) return false;
  }
  return true;
}

void printAddress(const DeviceAddress deviceAddress) {
  for (uint8_t i = 0; i < 8; i++) {
    if (deviceAddress[i] < 16) Serial.print('0');
    Serial.print(deviceAddress[i], HEX);
  }
  Serial.println();
}

String getAddressString(const DeviceAddress deviceAddress) {
  String address;
  address.reserve(16);
  for (uint8_t i = 0; i < 8; i++) {
    if (deviceAddress[i] < 16) address += '0';
    address += String(deviceAddress[i], HEX);
  }
  address.toLowerCase();
  return address;
}

bool validDs18b20Temperature(float value) {
  if (!isfinite(value)) return false;
  if (value == DEVICE_DISCONNECTED_C) return false;
  // DS18B20 specified operating range.
  return value >= -55.0f && value <= 125.0f;
}

// Rebuild the local list without ever writing past tempSensorAddresses[3].
// If more than three physical sensors are present, the first three valid ROMs
// are exposed because DX-MINI has exactly three logical temperature channels.
int refreshTemperatureDeviceList() {
  const int physicalCount = sensors.getDeviceCount();
  int stored = 0;

  for (int physicalIndex = 0;
       physicalIndex < physicalCount && stored < MAX_SENSORS;
       ++physicalIndex) {
    DeviceAddress address;
    if (!sensors.getAddress(address, physicalIndex)) continue;
    memcpy(tempSensorAddresses[stored], address, sizeof(DeviceAddress));
    ++stored;
  }

  for (int i = stored; i < MAX_SENSORS; ++i) {
    memset(tempSensorAddresses[i], 0, sizeof(DeviceAddress));
  }

  numberOfDevices = stored;
  return numberOfDevices;
}

int16_t physicalOffsetByIndex(int index) {
  if (index == 0) return offset1;
  if (index == 1) return offset2;
  if (index == 2) return offset3;
  return 0;
}

int physicalIndexForAddress(const DeviceAddress address) {
  if (addressIsZero(address)) return -1;
  for (int i = 0; i < numberOfDevices && i < MAX_SENSORS; ++i) {
    if (!addressIsZero(tempSensorAddresses[i]) && compareAddresses(address, tempSensorAddresses[i])) {
      return i;
    }
  }
  return -1;
}

void refreshLogicalOffsetsFromAssignments() {
  const int i1 = temp1Assigned ? physicalIndexForAddress(temp1Address) : -1;
  const int i2 = temp2Assigned ? physicalIndexForAddress(temp2Address) : -1;
  const int i3 = temp3Assigned ? physicalIndexForAddress(temp3Address) : -1;
  discharge_temp_offset = physicalOffsetByIndex(i1);
  supply_temp_offset = physicalOffsetByIndex(i2);
  return_air_temp_offset = physicalOffsetByIndex(i3);
}

void clearLogicalAssignment(uint8_t logicalIndex) {
  if (logicalIndex == 1) {
    temp1Assigned = false;
    memset(temp1Address, 0, sizeof(DeviceAddress));
    preferences.putBool("temp1_assign", false);
    preferences.putBytes("temp1Address", temp1Address, sizeof(DeviceAddress));
  } else if (logicalIndex == 2) {
    temp2Assigned = false;
    memset(temp2Address, 0, sizeof(DeviceAddress));
    preferences.putBool("temp2_assign", false);
    preferences.putBytes("temp2Address", temp2Address, sizeof(DeviceAddress));
  } else if (logicalIndex == 3) {
    temp3Assigned = false;
    memset(temp3Address, 0, sizeof(DeviceAddress));
    preferences.putBool("temp3_assign", false);
    preferences.putBytes("temp3Address", temp3Address, sizeof(DeviceAddress));
  }
}

void assignSensor(int sensor_sel, const DeviceAddress sensorAddress) {
  if (sensor_sel < 0 || sensor_sel > 3 || addressIsZero(sensorAddress)) return;

  preferences.begin("values", false);
  Serial.print("[TEMP] Sensor ROM: ");
  printAddress(sensorAddress);

  if (sensor_sel == 0) {
    if (temp1Assigned && compareAddresses(sensorAddress, temp1Address)) clearLogicalAssignment(1);
    if (temp2Assigned && compareAddresses(sensorAddress, temp2Address)) clearLogicalAssignment(2);
    if (temp3Assigned && compareAddresses(sensorAddress, temp3Address)) clearLogicalAssignment(3);
    refreshLogicalOffsetsFromAssignments();
    preferences.end();
    return;
  }

  // A physical probe may belong to only one logical channel. Clear it from any
  // previous channel before applying the new assignment.
  if (sensor_sel != 1 && temp1Assigned && compareAddresses(sensorAddress, temp1Address)) {
    clearLogicalAssignment(1);
  }
  if (sensor_sel != 2 && temp2Assigned && compareAddresses(sensorAddress, temp2Address)) {
    clearLogicalAssignment(2);
  }
  if (sensor_sel != 3 && temp3Assigned && compareAddresses(sensorAddress, temp3Address)) {
    clearLogicalAssignment(3);
  }

  if (sensor_sel == 1) {
    memcpy(temp1Address, sensorAddress, sizeof(DeviceAddress));
    temp1Assigned = true;
    preferences.putBool("temp1_assign", true);
    preferences.putBytes("temp1Address", temp1Address, sizeof(DeviceAddress));
  } else if (sensor_sel == 2) {
    memcpy(temp2Address, sensorAddress, sizeof(DeviceAddress));
    temp2Assigned = true;
    preferences.putBool("temp2_assign", true);
    preferences.putBytes("temp2Address", temp2Address, sizeof(DeviceAddress));
  } else if (sensor_sel == 3) {
    memcpy(temp3Address, sensorAddress, sizeof(DeviceAddress));
    temp3Assigned = true;
    preferences.putBool("temp3_assign", true);
    preferences.putBytes("temp3Address", temp3Address, sizeof(DeviceAddress));
  }

  refreshLogicalOffsetsFromAssignments();
  preferences.end();
}

// Preserve the original app contract: offset1/2/3 belong to address1/2/3
// (physical discovery slots). The control offsets are then derived from the
// currently assigned Discharge/Supply/Return sensor ROM, so reassigning a
// probe cannot apply another probe's calibration.
void setoffset(const DeviceAddress sensorAddress, int16_t offset_received) {
  const int index = physicalIndexForAddress(sensorAddress);
  if (index == 0) {
    offset1 = offset_received;
    preferences.putInt("offset1", offset1);
  } else if (index == 1) {
    offset2 = offset_received;
    preferences.putInt("offset2", offset2);
  } else if (index == 2) {
    offset3 = offset_received;
    preferences.putInt("offset3", offset3);
  } else {
    return;
  }
  refreshLogicalOffsetsFromAssignments();
}

// Read the most recently completed conversion. Conversion requests are handled
// by the non-blocking sensor service in main.cpp, so MQTT publication never
// stalls for a 750 ms DS18B20 conversion.
void read_temp(float& temp, const DeviceAddress deviceaddress) {
  if (addressIsZero(deviceaddress)) {
    temp = SENSOR_DISCONNECTED;
    return;
  }
  const float raw = sensors.getTempC(deviceaddress);
  temp = validDs18b20Temperature(raw) ? raw : (float)SENSOR_DISCONNECTED;
}
