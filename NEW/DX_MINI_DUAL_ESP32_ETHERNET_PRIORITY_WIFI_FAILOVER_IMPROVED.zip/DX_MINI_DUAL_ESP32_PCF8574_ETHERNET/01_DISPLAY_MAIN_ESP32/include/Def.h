#pragma once

bool dischargeTempAlarm = false;
bool returnTempAlarm = false;

//////////////////// Scheduler ///////////////////
bool schedulerEnabled = false;
bool PowerState = true;

#define SENSOR_DISCONNECTED 888
#define SENSOR_NOT_SELECTED 999
#define MQTT_INTERVAL 2500UL
#define SENSOR_READ_INTERVAL 1000UL

// Relay switching confirmation delay.
#define RELAY_SWITCH_DELAY 5000UL

// Hysteresis deadband (degrees C).
#define TEMP_HYSTERESIS 0.5f

//////////////////// Temperature Sensor DS18B20 ///////////////////
#define DS18B20_PIN 4
///////////////////////////////////////////////////////////////////

// These are PCF8574 BIT NUMBERS, NOT ESP32 GPIOs.
// PCF8574 I2C SDA=GPIO21 SCL=GPIO22, address=0x20 (A0=A1=A2=GND).
#define EVAP_COOL_SYSTEM 0  // P0 / Relay 1
#define AUTO_WASH_SYSTEM 1  // P1 / Relay 2
#define UNIT_COMMAND 2      // P2 / Relay 3

// PCF8574 P0/P1/P2 drive ACTIVE-LOW relay inputs on this installation.
// A physical relay is ON when its corresponding PCF output is LOW (0),
// and OFF when the PCF output is HIGH (1).
// Keep this true for the relay board that exhibited reversed physical/UI state.
// If you change the relay driver hardware, verify the polarity on a bench first.
#define RELAY_ACTIVE_LOW true

inline uint8_t relayLevel(bool on) {
  return RELAY_ACTIVE_LOW ? (on ? LOW : HIGH) : (on ? HIGH : LOW);
}
// Returns PCF8574 I2C ACK status, not proof of physical relay contact.
inline bool writeRelay(uint8_t index, bool on) {
  return pcfRelayWrite(index, relayLevel(on) == HIGH);
}

// Buzzer pin. GPIO26 is free on this DX-MINI wiring.
#define BUZZER_PIN 26
#define BUZZER_FREQ 2000
#define BUZZER_DURATION 50

//////////////////// UART Ethernet bridge ///////////////////
#define BRIDGE_UART_RX 16
#define BRIDGE_UART_TX 17
#define BRIDGE_BAUD 230400
// The second ESP32 manages W5500, TLS, MQTT and Ethernet NTP.
// These are snapshots received from its UART status heartbeat.
String ethernetMacAddress = "";
String ethernetIpAddress = "";
bool ethernetLinkPresent = false;
bool w5500_detected = false;
bool ethernet_using_dhcp = false;
bool eth_connected = false;
bool bridge_mqtt_up = false;
bool wifi_mqtt_subscribed = false;
uint32_t bridge_last_status_ms = 0;

AsyncWebServer server(80);
Preferences preferences;
WiFiClientSecure wifiClient;
PubSubClient wifiMqttClient(wifiClient);

// Only the Wi-Fi MQTT client lives on the display ESP32.
// The bridge hosts its own Ethernet MQTT client on the second ESP32.
PubSubClient* activeMqttClient = &wifiMqttClient;
using NetworkTransport = DxTransport;
DxNetworkPriority networkPriority;
NetworkTransport activeNetwork = NetworkTransport::NONE;
inline const char* activeNetworkLabel() {
  switch (activeNetwork) {
    case NetworkTransport::ETHERNET: return "ETHERNET";
    case NetworkTransport::WIFI: return "WIFI";
    default: return "OFFLINE";
  }
}

OneWire oneWire(DS18B20_PIN);
DallasTemperature sensors(&oneWire);

String devicename = "DXM-AAA001";

String device_topic_s_m = "/test/" + devicename + "/#";
String device_topic_s_1 = "/test/" + devicename + "/1";
String device_topic_s_2 = "/test/" + devicename + "/2";
String device_topic_s_3 = "/test/" + devicename + "/3";
String device_topic_p = "/KRC/" + devicename;

String Name = "DX Master Mini";
String myID = "16092100096";
String substring1 = myID.substring(2, 6);
String substring2 = myID.substring(9, 11);
String hostname = Name + substring1 + substring2;

const char* mqtt_server = "a31qubhv0f0qec-ats.iot.eu-north-1.amazonaws.com";
const int mqtt_port = 8883;

#define MAX_SENSORS 3
DeviceAddress tempSensorAddresses[MAX_SENSORS];
int numberOfDevices = 0;
DeviceAddress temp1Address = {0};
DeviceAddress temp2Address = {0};
DeviceAddress temp3Address = {0};
bool temp1Assigned = false;
bool temp2Assigned = false;
bool temp3Assigned = false;
int16_t discharge_temp_offset = 0;
int16_t offset = 0;
int16_t offset1 = 0;
int16_t suction_temp_offset = 0;
int16_t offset2 = 0;
int16_t return_air_temp_offset = 0;
int16_t offset3 = 0;
int16_t supply_temp_offset = 0;
int16_t offset4 = 0;

String ssid = "";
String password = "";
String macaddress = "";
String myIP = "";

bool message_received = false;
bool message_received_config = false;
bool message_received_pressure_config = false;
StaticJsonDocument<1536> received_doc;
bool wifi_ap_mode = false;
unsigned long wifi_setting_time = 0;
int wifi_channel = 0;
bool is_wifi_connected = false;

const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 18000;
const int daylightOffset_sec = 0;

unsigned long wait_update_time = 0;
unsigned long wait_time = 0;
unsigned long time3 = 0;
unsigned long pmillis = 0;

uint8_t weekDay = 255;
uint8_t current_hour = 255;
bool days_in_num[7] = {false};
bool hours_num[24] = {false};

String timenow = "0101200000";
String timesch = "hoursch=24|daysch=7";
int timeschen = 0;
int tmatched = 0;

int SYSTEM_STATUS = 0;
bool EVAP_COOL_SYSTEM_STATUS = false;
bool AUTO_WASH_SYSTEM_STATUS = false;
bool UNIT_COMMAND_STATUS = false;

// Relay delay tracking. -1 means no pending state transition.
int EVAP_COOL_SYSTEM_PENDING = -1;
int AUTO_WASH_SYSTEM_PENDING = -1;
int UNIT_COMMAND_PENDING = -1;
unsigned long evapCoolPendingTime = 0;
unsigned long autoWashPendingTime = 0;
unsigned long unitCmdPendingTime = 0;

float SupplyTemp = SENSOR_DISCONNECTED;
float ReturnTemp = SENSOR_DISCONNECTED;
float dischargeTemp = SENSOR_DISCONNECTED;

int dischargeSp = 0;
int ReturnSp = 0;
int EVAP_COOL_SYSTEM_SWITCH = 0;
int AUTO_WASH_SYSTEM_SWITCH = 0;
int UNIT_COMMAND_SWITCH = 1;
int FAULT_SWITCH = 0;
int MODE_SWITCH = 0;
bool R_A_TEMP_Alarm = false;
