#pragma once
#include <Arduino.h>

// Independent ESP32 I2C controller #1. Touchscreen uses controller #0.
static constexpr uint8_t PCF8574_ADDRESS = 0x20;
static constexpr uint8_t PCF8574_SDA = 21;
static constexpr uint8_t PCF8574_SCL = 22;

bool pcfRelayBegin();
bool pcfRelayWrite(uint8_t index, bool high);
void pcfRelayService();
bool pcfRelayReady();
void pcfRelayAllOff();
