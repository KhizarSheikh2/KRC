#pragma once
#include <stdint.h>

// Transport selection is based on an authenticated, subscribed MQTT connection
// on each interface, NEVER simply the presence of Ethernet carrier/DHCP or Wi-Fi.
// Ethernet needs to remain healthy for the short takeover guard; loss fails
// over immediately on the next service pass. Wrap-safe millis arithmetic.
enum class DxTransport : uint8_t { NONE=0, WIFI=1, ETHERNET=2 };

class DxNetworkPriority {
public:
  static constexpr uint32_t ETHERNET_RECOVERY_GUARD_MS = 1500;

  DxTransport select(bool ethernetMqttReady, bool wifiMqttReady, uint32_t now) {
    if (!ethernetMqttReady) {
      seenEthernetHealthy_ = false;
    } else if (!seenEthernetHealthy_) {
      seenEthernetHealthy_ = true;
      ethernetHealthySince_ = now;
    }

    // Once Ethernet is primary, don't demote it unless unhealthy. This prevents
    // switching during an ordinary healthy Ethernet status heartbeat.
    if (ethernetMqttReady &&
        (current_ == DxTransport::ETHERNET ||
         now - ethernetHealthySince_ >= ETHERNET_RECOVERY_GUARD_MS)) {
      current_ = DxTransport::ETHERNET;
    } else {
      current_ = wifiMqttReady ? DxTransport::WIFI : DxTransport::NONE;
    }
    return current_;
  }

  DxTransport active() const { return current_; }

private:
  DxTransport current_ = DxTransport::NONE;
  bool seenEthernetHealthy_ = false;
  uint32_t ethernetHealthySince_ = 0;
};
