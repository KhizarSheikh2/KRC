#include <Arduino.h>
#include <SPI.h>
#include <EthernetLarge.h>
#include <SSLClient.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <time.h>
#include <sys/time.h>
#include "esp_task_wdt.h"
#include "EthernetCertificates.h"
#include "BridgeProtocol.h"

// ESP32 #2, W5500 SPI bus. GPIO22 reserved optionally for hardware RESET.
#define W5500_SCK  18
#define W5500_MISO 19
#define W5500_MOSI 23
#define W5500_CS   5
#define W5500_RESET 22 // optional: change to -1 when RST is wired to module reset circuit
#define ENTROPY_ADC 34  // use actual analog noise source, not a constant pin
#define BRIDGE_RX 16
#define BRIDGE_TX 17
#define BRIDGE_BAUD 230400

// Configure the bridge with THE SAME AWS Thing / device as the display MCU.
const char *DEVICE_NAME = "DXM-AAA001";
const char *MQTT_HOST = "a31qubhv0f0qec-ats.iot.eu-north-1.amazonaws.com";
constexpr uint16_t MQTT_PORT = 8883;

// Default DHCP only: using a guessed static address may silently isolate the
// Ethernet interface or conflict with another LAN device.
uint8_t ethMac[6] = {0};
bool w5500Found = false;
bool ethLink = false;
bool ethNetwork = false;
bool dhcpActive = false;
bool mqttSubscribed = false;
uint32_t lastDhcpMaintain = 0;
uint32_t lastDhcpAttempt = 0;
uint32_t lastChipProbe = 0;
uint32_t lastMqttAttempt = 0;
uint32_t lastStatusSent = 0;
uint32_t previousPublishId = 0;
bool previousPublishAccepted = false;
String macString;

EthernetClient tcpClient;
SSLClient tls(tcpClient, TAs, (size_t)TAs_NUM, ENTROPY_ADC);
PubSubClient mqtt(tls);
EthernetUDP udp;
DxLink::Parser parser;

bool usableIp() {
  const IPAddress ip = Ethernet.localIP();
  return ip[0] != 0 && ip[0] != 255;
}

void setupMac() {
  const uint64_t id = ESP.getEfuseMac();
  ethMac[0] = 0x02;
  for (int i=1; i<6; ++i) ethMac[i] = (id >> (i * 8 - 8)) & 0xff;
  char text[20];
  snprintf(text, sizeof(text), "%02X:%02X:%02X:%02X:%02X:%02X",
           ethMac[0], ethMac[1], ethMac[2], ethMac[3], ethMac[4], ethMac[5]);
  macString = text;
}

// W5500 hardware probes are retried, including after power-on without cable.
bool detectChip() {
  SPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));
  digitalWrite(W5500_CS, LOW);
  SPI.transfer(0x00); SPI.transfer(0x39); SPI.transfer(0x00);
  const uint8_t version = SPI.transfer(0x00);
  digitalWrite(W5500_CS, HIGH);
  SPI.endTransaction();
  if (version == 0x04) {
    Ethernet.init(W5500_CS);
    // Initializes the chip without waiting for DHCP, enabling linkStatus().
    Ethernet.begin(ethMac, IPAddress(0,0,0,0));
    return true;
  }
  return false;
}

bool acquireDhcp() {
  if (!w5500Found || Ethernet.linkStatus() != LinkON) return false;
  const int ok = Ethernet.begin(ethMac, 4500UL, 1200UL);
  dhcpActive = ok == 1 && usableIp();
  Serial.printf("[ETH] DHCP=%d IP=%s\n", dhcpActive, Ethernet.localIP().toString().c_str());
  return dhcpActive;
}

bool ethernetNtp() {
  if (!ethNetwork) return false;
  const IPAddress server(162,159,200,1); // time.cloudflare.com, hard-coded bootstrap
  uint8_t packet[48] = {0}; packet[0] = 0x1b;
  if (!udp.begin(2390)) return false;
  if (!udp.beginPacket(server, 123)) {udp.stop(); return false;}
  udp.write(packet, sizeof(packet)); udp.endPacket();
  const uint32_t started = millis();
  while (millis()-started < 1000) {
    if (udp.parsePacket() >= 48) {
      udp.read(packet, sizeof(packet)); udp.stop();
      const uint32_t secs1900 = ((uint32_t)packet[40]<<24)|((uint32_t)packet[41]<<16)|
                                ((uint32_t)packet[42]<<8)|packet[43];
      if (secs1900 < 2208988800UL) return false;
      struct timeval tv { static_cast<time_t>(secs1900 - 2208988800UL), 0 };
      settimeofday(&tv, nullptr);
      return true;
    }
    delay(1);
  }
  udp.stop();
  return false;
}

void statusHeartbeat() {
  StaticJsonDocument<320> j;
  j["mqtt"] = mqtt.connected() && mqttSubscribed;
  j["time"] = static_cast<uint32_t>(time(nullptr));
  j["network"] = ethNetwork;
  j["link"] = ethLink;
  j["chip"] = w5500Found;
  j["dhcp"] = dhcpActive;
  j["ip"] = ethNetwork ? Ethernet.localIP().toString() : String("");
  j["mac"] = macString;
  String body; serializeJson(j, body);
  DxLink::send(Serial2, 'B', body);
  lastStatusSent = millis();
}

void mqttCallback(char *topic, uint8_t *payload, unsigned int length) {
  if (length > 2048) return;
  String body; body.reserve(length);
  for (unsigned int i=0; i<length; ++i) body += static_cast<char>(payload[i]);
  DynamicJsonDocument parsed(2304);
  if (deserializeJson(parsed, body)) {
    Serial.println("[BRIDGE] MQTT message is not valid JSON; ignoring");
    return;
  }
  String compact;
  serializeJson(parsed, compact);
  const String packed = String(topic) + '\t' + compact;
  // Push app instructions to DISPLAY, the sole owner of control logic.
  DxLink::send(Serial2, 'M', packed);
}

void mqttConnect() {
  if (!ethNetwork || mqtt.connected() || time(nullptr) <= 1609459200) return;
  const String clientId = String(DEVICE_NAME) + "-eth";
  if (mqtt.connect(clientId.c_str())) {
    const String topic = String("/test/") + DEVICE_NAME + "/#";
    mqttSubscribed = mqtt.subscribe(topic.c_str());
    Serial.printf("[MQTT] Ethernet TLS connected; subscribed=%d\n", mqttSubscribed);
    statusHeartbeat();
  } else {
    mqttSubscribed = false;
    Serial.printf("[MQTT] Ethernet TLS connect rc=%d\n", mqtt.state());
  }
}

void setup() {
  // A blocked SSLClient/Ethernet socket call must not permanently prevent
  // Ethernet recovery. This watchdog resets ONLY the secondary ESP32.
  esp_task_wdt_init(45, true);
  esp_task_wdt_add(nullptr);
  Serial.begin(115200);
  Serial2.setRxBufferSize(4096);
  Serial2.setTxBufferSize(4096);
  Serial2.begin(BRIDGE_BAUD, SERIAL_8N1, BRIDGE_RX, BRIDGE_TX);
  setupMac();
  if (W5500_RESET >= 0) {
    pinMode(W5500_RESET, OUTPUT);
    digitalWrite(W5500_RESET, LOW);
  }
  pinMode(W5500_CS, OUTPUT);
  digitalWrite(W5500_CS, HIGH);
  delay(50);
  if (W5500_RESET >= 0) digitalWrite(W5500_RESET, HIGH);
  delay(150);
  SPI.begin(W5500_SCK, W5500_MISO, W5500_MOSI, W5500_CS);
  w5500Found = detectChip();
  // Use full client certificate + private key from supplied working DX-MINI.
  static SSLClientParameters clientParams = SSLClientParameters::fromPEM(
       clientCert, sizeof(clientCert), clientKey, sizeof(clientKey));
  tls.setMutualAuthParams(clientParams);
  tls.setTimeout(8000);
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
  mqtt.setBufferSize(2048);
  mqtt.setKeepAlive(15);
  mqtt.setSocketTimeout(3);
  Serial.printf("[BRIDGE] chip=%u, UART RX16 TX17, W5500 CS5\n", w5500Found);
  statusHeartbeat();
}

void loop() {
  esp_task_wdt_reset();
  // Inbound UART publication frames get processed even if Ethernet goes down.
  parser.poll(Serial2, [](char type, const String& payload) {
    if (type == 'Q') { DxLink::send(Serial2, 'A', payload); return; }
    if (type == 'T') {
      const time_t fromMain = static_cast<time_t>(strtoul(payload.c_str(), nullptr, 10));
      const time_t local = time(nullptr);
      if (fromMain > 1609459200 && (local <= 1609459200 ||
          labs(static_cast<long>(local - fromMain)) > 30)) {
        struct timeval tv{fromMain, 0};
        settimeofday(&tv, nullptr);
        Serial.println("[ETH] RTC synchronized from main ESP32");
      }
      return;
    }
    if (type != 'P') return;
    const int idEnd = payload.indexOf('|');
    if (idEnd <= 0 || idEnd > 10) return;
    for (int i = 0; i < idEnd; ++i)
      if (payload[i] < '0' || payload[i] > '9') return;
    const uint32_t id = static_cast<uint32_t>(strtoul(payload.c_str(), nullptr, 10));
    const int cut = payload.indexOf('\t', idEnd + 1);
    if (!id || cut < idEnd + 2 || cut > idEnd + 180) return;
    if (id == previousPublishId && previousPublishAccepted) {
      DxLink::send(Serial2, 'R', String(id) + "|1");
      return; // duplicate UART retry; avoid publishing twice
    }
    const String topic = payload.substring(idEnd + 1, cut);
    const String json = payload.substring(cut + 1);
    // Publish only when this exact Ethernet MQTT session is fully ready.
    const bool ok = ethNetwork && mqtt.connected() && mqttSubscribed &&
                    mqtt.publish(topic.c_str(), json.c_str(), true);
    if (ok) {
      previousPublishId = id;
      previousPublishAccepted = true;
    }
    DxLink::send(Serial2, 'R', String(id) + (ok ? "|1" : "|0"));
    if (!ok) Serial.printf("[BRIDGE] publish failed seq=%lu rc=%d\n",
                           (unsigned long)id, mqtt.state());
  });

  const uint32_t now = millis();
  if (!w5500Found && now - lastChipProbe > 3000UL) {
    lastChipProbe = now;
    w5500Found = detectChip();
  }
  const bool linkNow = w5500Found && Ethernet.linkStatus() == LinkON;
  if (!linkNow && (ethNetwork || ethLink)) {
    mqtt.disconnect(); tls.stop();
    ethNetwork = false; dhcpActive = false;
    mqttSubscribed = false;
  }
  ethLink = linkNow;

  if (ethLink && !ethNetwork && now - lastDhcpAttempt >= 5000UL) {
    lastDhcpAttempt = now;
    ethNetwork = acquireDhcp();
    if (ethNetwork) {
      ethernetNtp();
      lastMqttAttempt = 0;
    }
  }
  if (ethNetwork && dhcpActive && now - lastDhcpMaintain >= 60000UL) {
    lastDhcpMaintain = now;
    const int maintainResult = Ethernet.maintain();
    if (maintainResult == 1 || maintainResult == 3 || !usableIp()) {
      mqtt.disconnect();
      mqttSubscribed = false;
      ethNetwork = false;
    }
  }

  if (ethNetwork && !mqtt.connected() && now - lastMqttAttempt >= 5000UL) {
    lastMqttAttempt = now;
    if (time(nullptr) <= 1609459200) ethernetNtp();
    mqttConnect();
  }
  if (mqtt.connected()) {
    if (!mqtt.loop()) mqttSubscribed = false;
    if (!mqttSubscribed && now - lastMqttAttempt >= 5000UL) {
      lastMqttAttempt = now;
      const String topic = String("/test/") + DEVICE_NAME + "/#";
      mqttSubscribed = mqtt.subscribe(topic.c_str());
    }
  } else mqttSubscribed = false;

  if (now - lastStatusSent >= 1000UL) statusHeartbeat();
  delay(1);
}
