# Ethernet / Wi-Fi Failover Hardware Acceptance Tests

Both MCUs must be flashed with this SAME package version and wired with UART crossover, common ground and 3.3 V I/O. Configure working Wi-Fi credentials. Verify that both AWS IoT MQTT client IDs are allowed by the IoT policy.

Serial monitors: **115200** on each board. Display: `[NET] 0=NONE 1=WIFI 2=ETHERNET`, `[MQTT] Main JSON QUEUED/PUBLISHED`; Ethernet: `[MQTT] Ethernet TLS connected; subscribed=1`, `[BRIDGE]` publish results. AWS IoT MQTT test client: subscribe to `/KRC/DXM-AAA001/#` and verify `network` and `ip_address` fields.

1. **Ethernet cable OUT, Wi-Fi connected to internet.** Expect active = WIFI, MQTT status 1, JSON `/KRC/DXM-AAA001` + `/KRC/DXM-AAA001/temperature_config_DXM` publish and commands `/test/DXM-AAA001/1` or `/2` received. Relays still obey PCF polarity/interlock.
2. **Ethernet cable IN, internet healthy.** W5500 must obtain DHCP, NTP/time bootstrap, AWS TLS and subscribe. After ~1.5 s of bridge health confirmation, expect active = ETHERNET, same JSON topics with `network=ETHERNET`, valid `ethernet_ip`, and Ethernet publish ACK logs.
3. **Cable IN, Ethernet router WAN DISCONNECTED (Wi-Fi internet remains healthy through another path).** Remove only Ethernet-side internet, not the shared router providing Wi-Fi. Wait for MQTT keepalive detection; expect display to return to WIFI, with new JSON snapshot. Link and DHCP may remain true: neither alone should hold the priority.
4. **Restore Ethernet WAN while cable remains IN.** Without reboot, Ethernet bridge automatically reconnects TLS, reaches subscribed MQTT; after stabilization active returns ETHERNET and retained JSON updates.
5. **Remove Ethernet cable.** Active becomes WIFI without reboot once link is detected and status arrives; if the bridge is unplugged, UART-heartbeat timeout also triggers fallback.
6. **Wi-Fi disconnected, Ethernet internet working.** Must remain active ETHERNET, keep publishing and processing MQTT app commands.
7. **Both Internet paths disconnected.** Active OFFLINE, MQTT status 0; relay and touch operation remain independently functional. Neither link should be labelled ONLINE simply because it has an IP.
8. **Restore only Wi-Fi internet, then only Ethernet.** Validate priority recovery, no forced manual mode changes and no repeated short oscillation.
9. **Reset only ESP32 #2 while main stays online.** Main must fall back to Wi-Fi; after bridge reconnection it must reselect Ethernet. Capture logs if it fails.
10. **Check publish under UART corruption / disconnect.** Main should retry up to 2 times, then degrade Ethernet temporarily; see `[BRIDGE] publish not confirmed` logs. Failed sends are refreshed via retained snapshots on route change.
11. **Power cycle both boards** and repeat 1–4. Check clock synchronization: with Wi-Fi available the main SNTP time can initialize the bridge; with Wi-Fi off Ethernet-side NTP must be reachable for TLS.
12. **Cloud policy check** if Wi-Fi or Ethernet never comes ONLINE: verify matching endpoint, active client certificate/private key, two client-ID permissions, and publish/subscribe topic permissions on AWS.

Important: Keep GPIO, relay driver and load wiring as documented in `WIRING_AND_SAFETY.md`; perform the first test with contactor loads isolated. The Ethernet return-to-service latency depends on DHCP, TLS, AWS and the WAN and is NOT guaranteed instantaneous. Expect a keepalive detection interval for silent WAN failures. UART CRC/ACK does not provide AWS MQTT PUBACK because this firmware uses QoS 0.
