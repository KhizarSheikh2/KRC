# Connection matrix and hardware warnings

## ESP32 #1 (JC2432W328 / XH-32S)

| Component | JC2432W328 connection |
|---|---|
| PCF8574 SDA | GPIO21, 3.3 V I2C level |
| PCF8574 SCL | GPIO22, 3.3 V I2C level |
| PCF8574 VCC | 3.3 V (or use I2C level shifter if powered at 5 V) |
| PCF8574 GND | Common GND |
| PCF8574 A0/A1/A2 | GND -> address `0x20`; update `PCFRelays.h` if address differs |
| PCF8574 P0 | Evap Cooling relay driver input |
| PCF8574 P1 | Auto Wash relay driver input |
| PCF8574 P2 | Unit Command relay driver input |
| DS18B20 OneWire | GPIO4, 4.7 kOhm pull-up to 3.3 V; pin shared with onboard red LED on some board revisions |
| Built-in CST820 touch | GPIO33 SDA, GPIO32 SCL, GPIO25 reset; uses separate controller `Wire` |
| Display backlight | GPIO27, unchanged |
| Display UART to ESP32 #2 | GPIO17 TX -> ESP32 #2 GPIO16 RX |
| Display UART from ESP32 #2 | GPIO16 RX <- ESP32 #2 GPIO17 TX |
| Buzzer | GPIO26, unchanged |

## ESP32 #2 (W5500 Ethernet bridge)

| Component | ESP32 #2 connection |
|---|---|
| W5500 SCK | GPIO18 |
| W5500 MISO | GPIO19 |
| W5500 MOSI | GPIO23 |
| W5500 CS | GPIO5 |
| W5500 RESET | GPIO22 **optional**; use `#define W5500_RESET -1` if module reset is independently handled |
| ESP32 #2 RX2 | GPIO16 <- JC2432W328 GPIO17 TX |
| ESP32 #2 TX2 | GPIO17 -> JC2432W328 GPIO16 RX |
| All grounds | Shared GND across PCF8574, both ESP32s and W5500 |

Both UART signal levels must be 3.3 V. Do not tie the two ESP32 power outputs together. Use adequately sized power supplies and an Ethernet module with a confirmed 3.3 V logic interface. Keep signal wiring short and ground referenced.

## CRITICAL PCF8574 relay polarity and safety

**This revision fixes inverted physical/UI relay states for an ACTIVE-LOW relay input board.**
PCF8574 P0/P1/P2 now use the following electrical truth table:

| Display commanded/output status | P0/P1/P2 electrical output | Physical relay input | Expected relay contact state |
|---|---|---|---|
| OFF | HIGH (1) | inactive | OFF |
| ON (after 5 s) | LOW (0) | active | ON |

`RELAY_ACTIVE_LOW=true` in `include/Def.h` and the PCF shadow/all-off/recovery value
`0xFF` in `src/PCFRelays.cpp` **must agree**. The PCF8574 powers up HIGH (0xFF),
which is inactive for an active-low input. At power-off or I2C reconnect the
firmware writes `0xFF`, not `0xF8` (which would turn on all three active-low relays).

**Important:** this is a firmware-to-driver polarity assumption, *not* a measurement
of the relay contact. The display reports last acknowledged output command, not
contact feedback. A relay connected to the NO versus NC contact will reverse
what the external load does. Check NO/COM/NC wiring with equipment disconnected.

**Electrical warning:** the PCF8574 has quasi-bidirectional outputs and can sink
more current than it can source. Confirm that your relay input current is within
the PCF8574's specified limits and that powering a 5 V relay module cannot put
5 V onto a 3.3 V-powered PCF8574 or ESP32 I2C pins. Prefer optocoupled driver/
logic-buffer stages with appropriate isolation and hardware safety interlocks.
ESP32 firmware cannot guarantee load isolation during wiring faults or power loss.

GPIO16 and GPIO17 are connected to onboard RGB LEDs on some JC2432W328 variants. Check the real board schematic; those LED circuits may load UART and affect signal integrity. GPIO4 may also be loaded by the onboard RGB LED and can interfere with DS18B20 OneWire. If needed, physically isolate LED circuits or reassign the sensor/UART to suitable pins.

PCF8574 I2C address `0x20` assumes a PCF8574, NOT a PCF8574A (different base address). Use 3.3 V pull-ups and never expose the ESP32 I2C pins to 5 V.

The UART bridge reports packet CRC and MQTT connectivity; it is **not** a redundant relay controller. A lost I2C bus or power rail can leave physical relay contacts unverified. For compressors, pumps and wash equipment, add independent hardware interlocks, contactor feedback and suitable safety cutoff circuits.
