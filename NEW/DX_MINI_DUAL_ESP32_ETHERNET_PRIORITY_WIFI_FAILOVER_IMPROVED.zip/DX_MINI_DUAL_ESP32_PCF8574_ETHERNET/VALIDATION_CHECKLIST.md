# DX-MINI bring-up and validation checklist

1. On BENCH ONLY, disconnect the equipment loads; verify 3.3 V grounds, separate supplies, and PCF8574 I2C address 0x20 with an I2C scanner.
2. With equipment loads disconnected, power-cycle PCF8574 and confirm P0/P1/P2 are HIGH (inactive on an ACTIVE-LOW relay module) at power-up. Test relay-module polarity separately with safe driver circuitry. If a relay unexpectedly energizes, correct hardware BEFORE testing firmware.
3. Flash `01_DISPLAY_MAIN_ESP32`. Serial should display `[PCF] ... ACK=1`; verify full TFT/touch after startup and correct temperature values on GPIO4.
4. Test P0/P1/P2 one at a time in manual mode with loads disconnected: when the display says OFF, confirm the corresponding PCF output is HIGH and the relay is de-energized; when the display says ON (after ~5 seconds), confirm PCF output LOW and relay energized. Check both LED/coil and NO/COM contact continuity; display statuses are commanded/ACKed states, not physical-contact feedback.
5. Turn UNIT+EVAP ON; request WASH ON. Both must go OFF BEFORE wash energizes; wash ON should occur after confirmation delay. During WASH ON, attempt EVAP/UNIT ON using touch and MQTT; both must remain OFF.
6. Request WASH OFF. During the 5 s OFF confirmation, UNIT/EVAP remain OFF; after wash physical output turns OFF, they can resume only through normal control and confirmation.
7. Enable AUTO schedule and temperature control; check wash interlock on schedule start/end, then verify scheduler ignores invalid NTP time.
8. Flash `02_W5500_ETHERNET_ESP32`; ensure W5500 chip detection, DHCP, Ethernet NTP, AWS TLS certificate authentication and MQTT SUBSCRIBE succeeds. Verify MQTT policy permits client IDs suffixed `-eth` and `-wifi`.
9. Cross-wire UART **TX17 -> RX16** in BOTH directions, common GND. Check ESP32 #2 heartbeat is received and active network changes to ETHERNET only once MQTT is connected.
10. Publish the original app commands to `/test/DXM-AAA001/1` and temperature setup to `/test/DXM-AAA001/2`. Verify all original runtime and config JSON fields on `/KRC/DXM-AAA001` and `/temperature_config_DXM`.
11. Remove Ethernet cable: after heartbeat timeout and Wi-Fi MQTT reconnect, observe network change without MCU reset. Restore Ethernet and verify automatic promotion. Also test broker unreachable with cable connected, reboot second ESP32, corrupt UART frame, and disconnect UART.
12. Disconnect PCF8574 SDA/SCL, or remove PCF power on bench: firmware must inhibit new ON commands and report an I2C fault; physical failsafe depends on external driver disable hardware.
13. Reboot both ESP32s at least 20 times with the relay drivers safely disconnected. Check LVGL touch coordinate alignment, startup timing, and no brownouts/watchdog resets.
14. PlatformIO clean builds for BOTH projects, and long-running bench soak test (at least one full scheduling cycle) are mandatory before using with live loads.

This checklist describes tests **to perform**, not tests already passed. No physical bench test or PlatformIO compile was run while preparing the ZIP.


## Ethernet/Wi-Fi upgrade test
See `ETHERNET_FAILOVER_TEST_PLAN.md`. Verify BOTH ESP32 projects are flashed to this same revision. Ethernet publish frames now include sequence IDs and ACKs; old Ethernet firmware must not be paired with new display firmware.
