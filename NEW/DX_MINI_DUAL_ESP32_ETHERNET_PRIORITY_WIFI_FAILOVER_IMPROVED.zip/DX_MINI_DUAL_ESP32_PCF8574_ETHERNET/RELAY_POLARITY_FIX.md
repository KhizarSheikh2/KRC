# DX-MINI PCF8574 relay polarity correction — 2026-10-14

## Root cause
The earlier firmware configured `RELAY_ACTIVE_LOW=false`, meaning the main controller assumed a PCF8574 pin HIGH would turn a relay ON. The observed physical state was the opposite: the connected relay inputs behave as **active LOW**.

## Correction (main display ESP32 only)
- `01_DISPLAY_MAIN_ESP32/include/Def.h`: `RELAY_ACTIVE_LOW=true`; `writeRelay(channel, on)` now maps logical ON to PCF pin LOW.
- `01_DISPLAY_MAIN_ESP32/src/PCFRelays.cpp`: startup, default shadow, `pcfRelayAllOff()`, and I2C reconnection initialize all PCF ports to HIGH (0xFF) so relay 1/2/3 remain OFF.
- `01_DISPLAY_MAIN_ESP32/src/main.cpp`: update startup safety and serial log annotations.
- Existing relay state machine and LVGL command/actual UI logic are unchanged. The screen shows ON only after a successful PCF write and the five-second delay (unless safety wash interlock requires immediate OFF).
- The Ethernet firmware, UART bridge, MQTT topics, DS18B20 logic and touch UI layout remain unchanged.

## Expected PCF port bytes
| Energized relays | PCF8574 output byte (hex) | Explanation |
|---|---|---|
| None | FF | P0/1/2 HIGH=OFF |
| P0 Evap only | FE | P0 LOW=ON |
| P1 Wash only | FD | P1 LOW=ON |
| P2 Unit only | FB | P2 LOW=ON |
| P0 + P2 | FA | P0 and P2 LOW=ON; only outside wash |

**Electrical note:** If PCF LOW turns the relay coil OFF (contrary to your observed inversion), stop, do not operate loads, and validate the actual driver polarity. Physical relay feedback (auxiliary contacts) is not implemented; UI 'actual' indicates the last acknowledged I2C command, not measured contacts. NO/NC contact selection can also reverse load behavior. Isolate external equipment during testing.
