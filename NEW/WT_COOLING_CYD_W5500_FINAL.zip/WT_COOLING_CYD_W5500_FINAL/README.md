# WT_COOLING_CYD - JC2432W328 + W5500 Final

This project preserves the existing Water Tank Cooling controller logic and JC2432W328 LVGL user interface while adding/finalizing W5500 Ethernet support.

## Network behavior

- W5500 Ethernet has priority whenever the Ethernet cable is connected and the controller has a valid Ethernet IP.
- WiFi is the automatic fallback transport.
- If the controller boots without an Ethernet cable, WiFi operates normally and Ethernet can be connected later without rebooting.
- When Ethernet becomes available, MQTT is moved to Ethernet and NTP is resynchronized.
- If Ethernet is removed, MQTT falls back to WiFi.
- DHCP is attempted first. If DHCP is unavailable, the controller uses the static fallback `192.168.0.117`.

## W5500 pins

- SCK: GPIO18
- MISO: GPIO19
- MOSI: GPIO23
- CS: GPIO5
- RESET: GPIO17

The TFT uses HSPI and the W5500 uses the other SPI bus, so their SPI pin sets do not overlap.

## Relay polarity

The project is configured for the user's active-high relay boards:

```cpp
#define RELAY_ACTIVE_LOW false
```

With this setting, `HIGH = relay ON` and `LOW = relay OFF`.

See `PIN_MAP.txt` for the complete hardware map.
