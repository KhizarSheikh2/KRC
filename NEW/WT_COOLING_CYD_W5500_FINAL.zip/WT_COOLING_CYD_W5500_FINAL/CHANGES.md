UI changes in this revision:
- Header title changed to Water Tank / Cooling System
- Cleaner card titles and spacing
- Reduced unnecessary helper text
- Better alignment of setpoint buttons
- Simplified scheduler wording
- Fan/Pump mode hints shortened
- Included missing original project headers in /include

Final W5500 / relay update:
- W5500 pins confirmed: SCK=18, MISO=19, MOSI=23, CS=5, RESET=17.
- GPIO4 remains dedicated to the Pump relay; it is NOT used for W5500 reset.
- Added explicit `#define RELAY_ACTIVE_LOW false` for the active-high fan/pump relay boards.
- Centralized relay polarity conversion so logical ON/OFF state is not changed.
- Ethernet remains higher priority than WiFi.
- Added Ethernet cable hot-plug recovery: a cable connected after boot can acquire an IP and take priority without rebooting.
- DHCP is attempted first with a bounded timeout; known static fallback remains 192.168.0.117.
- DHCP maintenance runs only when the active Ethernet address came from DHCP.
